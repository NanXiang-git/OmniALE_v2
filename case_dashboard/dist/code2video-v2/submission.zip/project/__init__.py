"""Editable, procedural ident reconstruction."""
