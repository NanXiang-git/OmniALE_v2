import os
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

ROOT = Path('/candidate/input')
OUT = Path('/workspace/submission/assets')
OUT.mkdir(parents=True, exist_ok=True)


def green_alpha(preview):
    rgb = np.asarray(Image.open(preview).convert('RGB'))
    green = (rgb[:, :, 1] > 245) & (rgb[:, :, 0] < 8) & (rgb[:, :, 2] < 8)
    alpha = np.where(green, 0, 255).astype(np.uint8)
    return rgb, alpha


def make_clip(clip, rect, frame0_preview):
    folder = OUT / f'clip_{clip}_rgba'
    folder.mkdir(exist_ok=True)
    rgb0, a0 = green_alpha(frame0_preview)
    # The supplied green preview provides a clean, frame-aligned matte anchor.
    anchor = np.asarray(Image.open(ROOT / f'clip_{clip}' / '0000.png').convert('RGB'))
    ys, xs = np.where(a0 > 16)
    x0, y0, x1, y1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    for n in range(100):
        src = np.asarray(Image.open(ROOT / f'clip_{clip}' / f'{n:04d}.png').convert('RGB'))
        if n == 0:
            alpha = a0
        elif clip == 1:
            alpha = a0.copy()
            hsv = cv2.cvtColor(src, cv2.COLOR_RGB2HSV)
            blue = ((hsv[:, :, 0] >= 92) & (hsv[:, :, 0] <= 135) & (hsv[:, :, 1] > 95)).astype(np.uint8)
            blue = cv2.dilate(blue, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))) > 0
            blue[:140, :] = False
            alpha[blue] = 0
        else:
            # The two targets move right together; translate the clean public matte.
            keyframes = [(0, 0), (20, 0), (35, 35), (50, 175), (60, 105),
                         (70, 65), (80, 45), (90, 45), (99, 45)]
            for (fa, da), (fb, db) in zip(keyframes, keyframes[1:]):
                if fa <= n <= fb:
                    dx = int(round(da + (db - da) * (n - fa) / (fb - fa)))
                    break
            affine = np.float32([[1, 0, dx], [0, 1, 0]])
            alpha = cv2.warpAffine(a0, affine, (512, 288), flags=cv2.INTER_LINEAR,
                                   borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            if 28 <= n <= 55:
                # Exclude the moving vertical bar where it crosses the target.
                bar_x = int(round(366 + 1.0 * (n - 28)))
                alpha[:, max(0, bar_x-8):min(512, bar_x+48)] = 0
            hsv = cv2.cvtColor(src, cv2.COLOR_RGB2HSV)
            blue = ((hsv[:, :, 0] >= 92) & (hsv[:, :, 0] <= 135) & (hsv[:, :, 1] > 95)).astype(np.uint8)
            blue = cv2.dilate(blue, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31))) > 0
            alpha[blue] = 0
        alpha = cv2.GaussianBlur(alpha, (3, 3), 0.45)
        rgba = np.dstack((src, alpha))
        Image.fromarray(rgba, 'RGBA').save(folder / f'{n:04d}.png', compress_level=1)


make_clip(1, (125, 0, 230, 288), ROOT / 'target_preview_1.png')
make_clip(2, (125, 0, 245, 288), ROOT / 'target_preview_2.png')
green = np.asarray(Image.open(ROOT / 'green.png').convert('RGB'))
green_dir = OUT / 'green_sequence'
green_dir.mkdir(exist_ok=True)
for n in range(100):
    Image.fromarray(green).save(green_dir / f'{n:04d}.png')
