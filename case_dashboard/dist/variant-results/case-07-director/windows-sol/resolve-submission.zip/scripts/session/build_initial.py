import sys,json,pathlib,time
sys.path.insert(0,'/runtime')
from resolve_rpc import resolve_call
root=pathlib.Path('/workspace/submission')
log=root/'evidence/build_receipts.jsonl'
def call(op,**args):
 r=resolve_call(op,**args)
 with log.open('a') as f:f.write(json.dumps({'operation':op,'args':args,'receipt':r})+'\n')
 print(op,json.dumps(r)[:300],flush=True)
 if not r.get('ok'):raise RuntimeError(r)
 return r['result']
settings={'colorScienceMode':'davinciYRGBColorManagedv2','separateColorSpaceAndGamma':'0','colorSpaceTimeline':'ACEScg','colorSpaceInput':'sRGB','colorSpaceOutput':'sRGB','imageResizingGamma':'Linear'}
call('project_settings',settings=settings)
state={'settings':settings,'media':{},'timelines':[]}
for label,path in [('green','green'),('foreground_1','foreground_1'),('foreground_2','foreground_2')]:
 while not (root/'assets'/path/'0099.png').exists():time.sleep(1)
 result=call('import_media',path=str(root/'assets'/path/'%04d.png'),start_index=0,end_index=99)
 state['media'][label]=result
 print('MEDIA FULL',json.dumps(result),flush=True)
 (root/'evidence/build_state.json').write_text(json.dumps(state,indent=2))
