import sys,json,pathlib
sys.path.insert(0,'/runtime')
from resolve_rpc import resolve_call
p=pathlib.Path('/workspace/submission');s=json.loads((p/'evidence/build_state.json').read_text())
def call(op,**args):
 r=resolve_call(op,**args)
 with (p/'evidence/build_receipts.jsonl').open('a') as f:f.write(json.dumps({'operation':op,'args':args,'receipt':r})+'\n')
 print(op,json.dumps(r)[:300],flush=True)
 if not r.get('ok'):raise RuntimeError(r)
 return r['result']
s['delivery_timelines']=[]
for c,side in [(1,'Right'),(2,'Left')]:
 name=f'DELIVERY_{c}_Keep_{side}'
 call('create_timeline',name=name,video_tracks=2)
 for track,label in [(1,'green'),(2,f'foreground_{c}')]:
  r=call('append',timeline=name,media_id=s['media'][label+'_prores'][0]['id'],start_frame=0,end_frame=100,record_frame=0,track_index=track)
  assert r[0].get('duration')==100,r
 call('item_properties',timeline=name,track=2,index=1,properties={'CompositeMode':0,'Opacity':100,'ZoomX':1,'ZoomY':1,'Pan':0,'Tilt':0})
 s['delivery_timelines'].append(name)
(p/'evidence/build_state.json').write_text(json.dumps(s,indent=2))
r=call('inspect');(p/'evidence/delivery_inspection.json').write_text(json.dumps(r,indent=2))
r=call('render',timeline=s['delivery_timelines'][0],output='/workspace/submission/check_delivery.mp4',mark_in=0,mark_out=99);s['check_delivery']=r
(p/'evidence/build_state.json').write_text(json.dumps(s,indent=2))
