import sys,json,pathlib,time
sys.path.insert(0,'/runtime')
from resolve_rpc import resolve_call
p=pathlib.Path('/workspace/submission');s=json.loads((p/'evidence/build_state.json').read_text())
def call(op,**args):
 r=resolve_call(op,**args)
 with (p/'evidence/build_receipts.jsonl').open('a') as f:f.write(json.dumps({'operation':op,'args':args,'receipt':r})+'\n')
 print(op,json.dumps(r)[:400],flush=True)
 if not r.get('ok'):raise RuntimeError(r)
 return r['result']
for label in ['foreground_1','foreground_2','green']:
 path=p/'assets'/f'{label}_prores.mov'
 while not path.exists():time.sleep(1)
 r=call('import_media',path=str(path));s['media'][label+'_prores']=r
 print('MEDIA',label,{k:r[0]['properties'].get(k) for k in ['FPS','Frames','Video Codec','Alpha mode','Bit Depth']},flush=True)
 props={'Data Level':'Video','Input Color Space':'sRGB'}
 if label!='green':props['Alpha mode']='Straight'
 call('media_properties',media_id=r[0]['id'],properties=props)
(p/'evidence/build_state.json').write_text(json.dumps(s,indent=2))
# Native AppendToTimeline at the same record position performs an overwrite edit.
for c,side in [(1,'Right'),(2,'Left')]:
 for track,label in [(1,'green'),(2,f'foreground_{c}')]:
  call('append',timeline=f'Clip_{c}_Keep_{side}',media_id=s['media'][label+'_prores'][0]['id'],start_frame=0,end_frame=100,record_frame=0,track_index=track)
r=call('inspect');(p/'evidence/prores_inspection.json').write_text(json.dumps(r,indent=2))
r=call('render',timeline='Clip_1_Keep_Right',output='/workspace/submission/check_prores.mp4',mark_in=0,mark_out=99);s['check_prores']=r
(p/'evidence/build_state.json').write_text(json.dumps(s,indent=2))
