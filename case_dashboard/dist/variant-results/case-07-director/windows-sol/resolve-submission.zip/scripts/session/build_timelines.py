import sys,json,pathlib
sys.path.insert(0,'/runtime')
from resolve_rpc import resolve_call
p=pathlib.Path('/workspace/submission');state=json.loads((p/'evidence/build_state.json').read_text())
def call(op,**args):
 r=resolve_call(op,**args)
 with (p/'evidence/build_receipts.jsonl').open('a') as f:f.write(json.dumps({'operation':op,'args':args,'receipt':r})+'\n')
 print(op,json.dumps(r)[:500],flush=True)
 if not r.get('ok'):raise RuntimeError(r)
 return r['result']
for label in ['green','foreground_1','foreground_2']:
 media=state['media'][label+'_mov']['result'][0]['id']
 props={'Data Level':'Full','Input Color Space':'sRGB','Input Gamma':'sRGB'}
 if label!='green':props['Alpha mode']='Straight'
 call('media_properties',media_id=media,properties=props)
for c,side in [(1,'Right'),(2,'Left')]:
 name=f'Clip_{c}_Keep_{side}'
 result=call('create_timeline',name=name,video_tracks=2)
 state['timelines'].append({'name':name,'creation':result})
 (p/'evidence/build_state.json').write_text(json.dumps(state,indent=2))
 for track,label in [(1,'green'),(2,f'foreground_{c}')]:
  media=state['media'][label+'_mov']['result'][0]['id']
  call('append',timeline=name,media_id=media,start_frame=0,end_frame=100,record_frame=0,track_index=track)
 call('item_properties',timeline=name,track=2,index=1,properties={'Opacity':100,'ZoomX':1,'ZoomY':1,'Pan':0,'Tilt':0})
call('inspect')
r=call('render',timeline='Clip_1_Keep_Right',output='/workspace/submission/check_1.mp4',mark_in=0,mark_out=99)
state['check_render']=r
(p/'evidence/build_state.json').write_text(json.dumps(state,indent=2))
