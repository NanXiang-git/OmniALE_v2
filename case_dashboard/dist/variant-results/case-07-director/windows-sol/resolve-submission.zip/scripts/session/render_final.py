import sys,json,pathlib,time
sys.path.insert(0,'/runtime')
from resolve_rpc import resolve_call
p=pathlib.Path('/workspace/submission');s=json.loads((p/'evidence/build_state.json').read_text())
def call(op,**args):
 r=resolve_call(op,**args)
 with (p/'evidence/final_receipts.jsonl').open('a') as f:f.write(json.dumps({'operation':op,'args':args,'receipt':r})+'\n')
 print(op,json.dumps(r)[:700],flush=True)
 if not r.get('ok'):raise RuntimeError(r)
 return r['result']
s['final_jobs']=[]
for c,name in enumerate(s['delivery_timelines'],1):
 r=call('render',timeline=name,output=str(p/f'output_{c}.mp4'),mark_in=0,mark_out=99)
 job=r['job_id'];s['final_jobs'].append({'clip_id':f'clip_{c}','timeline_name':name,'render_job_id':job,'output':f'output_{c}.mp4'})
 (p/'evidence/build_state.json').write_text(json.dumps(s,indent=2))
 for _ in range(180):
  status=call('render_status',job_id=job)
  if status.get('JobStatus')=='Complete':break
  if status.get('JobStatus') in ['Failed','Cancelled','Canceled']:raise RuntimeError(status)
  time.sleep(3)
 else:raise RuntimeError('render not complete')
call('export_project',path=str(p/'project.drp'))
r=call('inspect');(p/'evidence/final_inspection.json').write_text(json.dumps(r,indent=2))
