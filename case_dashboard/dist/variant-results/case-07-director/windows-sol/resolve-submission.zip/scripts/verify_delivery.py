"""Read-only contract, decode, frame timing, identity exclusion and alignment checks."""
import argparse,json,hashlib,subprocess,zipfile
from pathlib import Path
import cv2,numpy as np,jsonschema
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('/workspace/submission'));p.add_argument('--input',type=Path,default=Path('/candidate/input'));a=p.parse_args();root=a.root
result={'checks':{},'clips':[],'independent_drp_reimport_rerender':'Not performed: frozen bridge exposes export but no import/reopen operation. Evaluator handoff required.'}
for name in ['submission','report']:
 data=json.loads((root/f'{name}.json').read_text());schema=json.loads((root/f'{name}.schema.json').read_text());jsonschema.Draft202012Validator(schema).validate(data);result['checks'][name+'_schema']=True
jsonschema.Draft202012Validator(json.loads((root/'cue_decisions.schema.json').read_text())).validate(json.loads((root/'cue_decisions.json').read_text()));result['checks']['cue_schema']=True
for c in [1,2]:
 file=root/f'output_{c}.mp4'
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-show_frames','-of','json',str(file)]))
 (root/'evidence'/f'ffprobe_output_{c}.json').write_text(json.dumps(probe,indent=2)+'\n')
 streams=probe['streams'];video=[s for s in streams if s['codec_type']=='video'];assert len(video)==1
 v=video[0];assert v['codec_name']=='h264' and (v['width'],v['height'])==(512,288)
 assert v['avg_frame_rate']=='25/1' and v['r_frame_rate']=='25/1' and int(v['nb_read_frames'])==100
 assert all(s['codec_type']=='video' or (s['codec_type']=='data' and s.get('codec_tag_string')=='tmcd') for s in streams)
 frames=[f for f in probe['frames'] if f['media_type']=='video'];pts=np.array([float(f['best_effort_timestamp_time']) for f in frames]);assert len(pts)==100 and abs(pts[0])<1e-6 and np.max(abs(np.diff(pts)-.04))<1e-6
 assert abs(float(v['duration'])-4)<=.04
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(file),'-map','0:v:0','-pix_fmt','bgr24','-f','rawvideo','-'])
 images=np.frombuffer(raw,np.uint8).reshape(-1,288,512,3);assert len(images)==100
 source=np.stack([cv2.imread(str(a.input/f'clip_{c}'/f'{n:04d}.png')) for n in range(100)]).astype(float)
 alpha=np.stack([cv2.imread(str(root/'assets'/f'foreground_{c}'/f'{n:04d}.png'),-1)[:,:,3] for n in range(100)])/65535
 masks=np.stack([cv2.erode(np.uint8(m>.999),np.ones((5,5),np.uint8)).astype(bool) for m in alpha])
 costs={}
 for lag in [-2,-1,0,1,2]:
  ids=np.arange(max(0,-lag),min(100,100-lag));costs[str(lag)]=float(np.mean([np.mean(abs(images[n].astype(float)-source[n+lag])[masks[n]]) for n in ids]))
 assert min(costs,key=costs.get)=='0',costs
 # Distant distractor regions are fully green in every decoded frame.
 excluded=images[:,:,:280,:] if c==1 else images[:,:,280:,:]
 assert int(np.max(excluded[:,:,:,[0,2]]))<5 and int(np.min(excluded[:,:,:,1]))>245
 bg=images[alpha==0];err=abs(bg.astype(float)-np.array([0,255,0]))
 metrics={'clip_id':f'clip_{c}','decoded_frames':len(images),'resolution':[512,288],'frame_rate':'25/1','duration_seconds':float(v['duration']),'streams':[{'type':s['codec_type'],'codec':s.get('codec_name',s.get('codec_tag_string'))} for s in streams],'frame_interval_seconds':.04,'alignment_mean_absolute_error_8bit_BGR_by_source_lag':costs,'distractor_region_max_red_blue':int(np.max(excluded[:,:,:,[0,2]])),'distractor_region_min_green':int(np.min(excluded[:,:,:,1])),'background_mean_absolute_error_8bit_BGR':err.mean(0).tolist(),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
 result['clips'].append(metrics)
 # Endpoints and gestures for visual verification; review sheets are outside submission.
 for n in [0,20,40,60,80,99]:cv2.imwrite(f'/workspace/scratch/final_{c}_{n:04d}.png',images[n])
with zipfile.ZipFile(root/'project.drp') as z:
 assert z.testzip() is None
 entries=z.namelist();contents=b'\n'.join(z.read(n) for n in entries)
 for name in ['DELIVERY_1_Keep_Right','DELIVERY_2_Keep_Left']:
  assert name.encode() in contents or name.encode('utf-16-le') in contents,name
 result['checks']['drp_zip_crc']=True;result['drp_entries']=entries
result['checks']['drp_nonempty']=(root/'project.drp').stat().st_size>0
result['checks']['readme_nonempty']=(root/'README.md').stat().st_size>0
result['checks']['complete']=True
(root/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
