"""Encode only intermediate alpha/background media. Final MP4s must be rendered in Resolve."""
import argparse,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--assets',type=Path,default=Path('/workspace/submission/assets'));p.add_argument('--ffmpeg',default='ffmpeg');p.add_argument('--include-legacy',action='store_true');a=p.parse_args()
for label in ['foreground_1','foreground_2','green']:
 base=[a.ffmpeg,'-hide_banner','-loglevel','error','-framerate','25','-i',str(a.assets/label/'%04d.png'),'-frames:v','100']
 foreground=label!='green'
 codec=['-vf','scale=in_range=full:out_range=tv:out_color_matrix=bt709','-c:v','prores_ks','-profile:v','4' if foreground else '3','-pix_fmt','yuva444p10le' if foreground else 'yuv422p10le']
 if foreground:codec+=['-alpha_bits','16']
 codec+=['-vendor','apl0','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','iec61966-2-1','-threads','2']
 subprocess.run(base+codec+[str(a.assets/f'{label}_prores.mov')],check=True)
 if a.include_legacy:
  subprocess.run(base+['-c:v','png','-pix_fmt','rgba64be' if foreground else 'rgb24','-threads','2',str(a.assets/f'{label}.mov')],check=True)
