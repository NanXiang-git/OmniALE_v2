import cv2,numpy as np
import scipy.ndimage as ndi
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from pathlib import Path
INPUT=Path("/candidate/input")

def linear(a):return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def srgb(a):return np.where(a<=.0031308,a*12.92,1.055*np.maximum(a,0)**(1/2.4)-.055)

def bg_estimate():
 a=cv2.imread(str(INPUT/'clip_1'/'0000.png')).astype(float)/255
 h,w=a.shape[:2];y,x=np.mgrid[:h,:w]
 mask=((x<60)|((x>245)&(x<320))|(x>445)|(y<20)|(y>277))
 X=np.zeros((w,3));Y=np.zeros((h,3))
 for _ in range(50):
  X=np.sum((a-Y[:,None,:])*mask[:,:,None],axis=0)/mask.sum(0)[:,None]
  Y=np.sum((a-X[None,:,:])*mask[:,:,None],axis=1)/mask.sum(1)[:,None]
 return X[None]+Y[:,None]

def closed_matte(image, fg, bg, unknown):
 h,w=fg.shape
 # All local 3x3 windows touching unknown pixels.
 windows=ndi.binary_dilation(unknown,iterations=1);windows[[0,-1]]=False;windows[:,[0,-1]]=False
 ys,xs=np.where(windows)
 dy,dx=np.mgrid[-1:2,-1:2];off=(dy*w+dx).ravel()
 ids=(ys*w+xs)[:,None]+off
 colors=image.reshape(-1,3)[ids]
 mean=colors.mean(1); centered=colors-mean[:,None,:]
 cov=np.einsum('nki,nkj->nij',centered,centered)/9
 inv=np.linalg.inv(cov+np.eye(3)[None]*1e-7/9)
 values=np.eye(9)[None]-(1+np.einsum('nki,nij,nlj->nkl',centered,inv,centered))/9
 rows=np.broadcast_to(ids[:,:,None],values.shape).ravel()
 cols=np.broadcast_to(ids[:,None,:],values.shape).ravel()
 L=coo_matrix((values.ravel(),(rows,cols)),shape=(h*w,h*w)).tocsr()
 u=np.flatnonzero(unknown.ravel()); f=np.flatnonzero(fg.ravel())
 rhs=-np.asarray(L[u][:,f].sum(1)).ravel()
 A=L[u][:,u]
 alpha=fg.astype(float).ravel();alpha[u]=spsolve(A,rhs)
 return np.clip(alpha.reshape(h,w),0,1)

def process(c,n,bg):
 image=cv2.imread(str(INPUT/f'clip_{c}'/f'{n:04d}.png')).astype(float)/255
 h,w=image.shape[:2];xx=np.arange(w)[None,:]
 roi=np.broadcast_to((xx>310)&(xx<445) if c==1 else (xx>55)&(xx<245),(h,w))
 diff=np.max(abs(image-bg),2)*255
 mask=(diff>3)&roi
 # Do not fill hand/finger holes, preserve connected fine foreground.
 fg=ndi.binary_erosion(mask,iterations=2)
 support=ndi.binary_dilation(mask,iterations=2)&roi
 unknown=support&~fg
 alpha=closed_matte(linear(image),fg,~support,unknown)
 # Remove quantization noise where the observed pixel agrees with the plate.
 alpha[diff<1.35]=0
 I=linear(image);B=linear(bg)
 # Physical minimum alpha required for in-gamut foreground color.
 amin=np.maximum(np.max((B-I)/np.maximum(B,1e-6),2),np.max((I-B)/np.maximum(1-B,1e-6),2))
 alpha=np.where(support,np.maximum(alpha,amin),0)
 alpha=np.clip(alpha,0,1)
 F=np.clip((I-(1-alpha[:,:,None])*B)/np.maximum(alpha[:,:,None],1e-6),0,1)
 F[alpha<1/65535]=0
 rgba=np.dstack([srgb(F),alpha])
 preview=srgb(alpha[:,:,None]*F+(1-alpha[:,:,None])*np.array([0,1,0])[None,None,:])
 return rgba,preview

if __name__ == '__main__':
 import argparse
 parser=argparse.ArgumentParser(description='Offline clean-plate assisted closed-form matting, no learned models.')
 parser.add_argument('--input',type=Path,default=Path('/candidate/input'))
 parser.add_argument('--assets',type=Path,default=Path('/workspace/submission/assets'))
 args=parser.parse_args();INPUT=args.input
 args.assets.mkdir(parents=True,exist_ok=True)
 bg=bg_estimate()
 for c in (1,2):
  d=args.assets/f'foreground_{c}';d.mkdir(exist_ok=True)
  for n in range(100):
   rgba,_=process(c,n,bg)
   cv2.imwrite(str(d/f'{n:04d}.png'),np.uint16(np.clip(rgba*65535+.5,0,65535)))
   if n%10==0:print(c,n,flush=True)
 d=args.assets/'green';d.mkdir(exist_ok=True)
 green=cv2.imread(str(INPUT/'green.png'))
 for n in range(100):cv2.imwrite(str(d/f'{n:04d}.png'),green)
