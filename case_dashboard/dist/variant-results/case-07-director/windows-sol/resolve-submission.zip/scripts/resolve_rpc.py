import json,urllib.request
def resolve_call(op, **args):
    data=json.dumps({'op':op,'args':args},allow_nan=False).encode()
    req=urllib.request.Request('http://127.0.0.1:8765/resolve',data=data,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=600) as response:return json.load(response)
