"""Rebuild the two delivery timelines in a fresh assigned native Resolve project.
Requires the supplied /runtime/resolve_rpc.py bridge. Never run in the delivered project.
No final-file encoding outside Resolve.
"""
import argparse,json,sys,time
from pathlib import Path
sys.path.insert(0,'/runtime')
from resolve_rpc import resolve_call
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('/workspace/submission'));a=p.parse_args();root=a.root
log=root/'rebuild_receipts.jsonl'
def call(op,**args):
 r=resolve_call(op,**args)
 with log.open('a') as f:f.write(json.dumps({'operation':op,'args':args,'receipt':r})+'\n')
 if not r.get('ok'):raise RuntimeError(r)
 return r['result']
for name in ['project.drp','output_1.mp4','output_2.mp4']:
 if (root/name).exists():raise RuntimeError(f'{name} exists; use a fresh output directory with assets copied in')
project=call('new_project')
settings={'colorScienceMode':'davinciYRGBColorManagedv2','separateColorSpaceAndGamma':'0','colorSpaceTimeline':'ACEScg','colorSpaceInput':'sRGB','colorSpaceOutput':'sRGB','imageResizingGamma':'Linear'}
r=call('project_settings',settings=settings)
assert all(r['applied'].values()),r
media={}
for label in ['green','foreground_1','foreground_2']:
 media[label]=call('import_media',path=str(root/'assets'/f'{label}_prores.mov'))[0]['id']
 props={'Data Level':'Video','Input Color Space':'sRGB'}
 if label!='green':props['Alpha mode']='Straight'
 r=call('media_properties',media_id=media[label],properties=props)
 assert all(r['applied'].values()),r
clips=[]
for c,side in [(1,'Right'),(2,'Left')]:
 name=f'DELIVERY_{c}_Keep_{side}'
 call('create_timeline',name=name,video_tracks=2)
 for track,label in [(1,'green'),(2,f'foreground_{c}')]:
  r=call('append',timeline=name,media_id=media[label],start_frame=0,end_frame=100,record_frame=0,track_index=track)
  assert r[0].get('duration')==100,r
 call('item_properties',timeline=name,track=2,index=1,properties={'CompositeMode':0,'Opacity':100,'ZoomX':1,'ZoomY':1,'Pan':0,'Tilt':0})
 job=call('render',timeline=name,output=str(root/f'output_{c}.mp4'),mark_in=0,mark_out=99)['job_id']
 while True:
  state=call('render_status',job_id=job)
  if state.get('JobStatus')=='Complete':break
  if state.get('JobStatus') in ('Failed','Cancelled','Canceled'):raise RuntimeError(state)
  time.sleep(3)
 clips.append({'clip_id':f'clip_{c}','output':f'output_{c}.mp4','timeline_name':name,'render_job_id':job,'frame_map':{'start':0,'end_exclusive':100,'step':1,'mode':'identity'}})
call('export_project',path=str(root/'project.drp'))
(root/'rebuilt_submission.json').write_text(json.dumps({'version':'case3-resolve-green-v3.1-draft','source_case_id':'07','resolve_project':project['name'],'clips':clips,'project_file':'project.drp','readme':'README.md'},indent=2)+'\n')
