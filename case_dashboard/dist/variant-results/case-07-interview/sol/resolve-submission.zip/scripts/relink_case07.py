from pathlib import Path
import sys

import DaVinciResolveScript as resolve_script


ASSET_PATHS = {
    'green.mov': 'assets/Green.mov',
    'person_a_straight.mov': 'assets/Person_A_Straight.mov',
    'voice_a.wav': 'voice_A.wav',
}


def media_items(folder):
    yield from folder.GetClipList() or []
    for subfolder in folder.GetSubFolderList() or []:
        yield from media_items(subfolder)


def main():
    root = Path(__file__).resolve().parents[1] if len(sys.argv) < 2 else Path(sys.argv[1]).resolve()
    resolve = resolve_script.scriptapp('Resolve')
    if not resolve:
        raise RuntimeError('Start DaVinci Resolve before running this script.')
    manager = resolve.GetProjectManager()
    project = manager.GetCurrentProject()
    if not project:
        raise RuntimeError('Import and open project.drp in Resolve first.')
    if not any(project.GetTimelineByIndex(index).GetName() == 'Case07 - Person A'
               for index in range(1, project.GetTimelineCount() + 1)):
        raise RuntimeError('Open the imported Case07 project first.')
    paths = {name: root / relative_path for name, relative_path in ASSET_PATHS.items()}
    for path in paths.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    media_pool = project.GetMediaPool()
    selected = {}
    for clip in media_items(media_pool.GetRootFolder()):
        properties = clip.GetClipProperty()
        name = (properties.get('File Name') or clip.GetName()).casefold()
        if name in paths:
            selected[name] = clip
    if selected.keys() != paths.keys():
        raise RuntimeError(f'Media Pool items missing: {sorted(paths.keys() - selected.keys())}')
    for name, path in paths.items():
        clip = selected[name]
        if not clip.ReplaceClip(str(path)):
            raise RuntimeError(f'Resolve could not relink {path}')
        if name == 'person_a_straight.mov':
            clip.SetClipProperty('Alpha mode', 'Straight')
            if clip.GetClipProperty('Alpha mode') != 'Straight':
                raise RuntimeError('Resolve did not apply straight alpha.')
        print(path)
    if not manager.SaveProject():
        raise RuntimeError('Resolve could not save the relinked project.')


if __name__ == '__main__':
    main()
