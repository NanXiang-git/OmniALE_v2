import argparse
import json
from pathlib import Path
import sys
import time

sys.path.insert(0, '/runtime')
from resolve_rpc import resolve_call

ROOT = Path(__file__).resolve().parents[1]
TIMELINE = 'Case07 - Person A'
TRACK_MEDIA = (
    ('video', 1, ROOT / 'assets' / 'Green.mov'),
    ('video', 2, ROOT / 'assets' / 'Person_A_Straight.mov'),
    ('audio', 1, ROOT / 'voice_A.wav'),
)


def native(operation, **kwargs):
    result = resolve_call(operation, **kwargs)
    if not result.get('ok'):
        raise RuntimeError(f'{operation}: {result.get("error", result)}')
    return result['result']


def import_layers():
    current = native('inspect')
    existing = {item['name']: item['id'] for item in current['media']}
    timeline = next(item for item in current['timelines'] if item['name'] == TIMELINE)
    for media_type, track, path in TRACK_MEDIA:
        if not path.is_file():
            raise FileNotFoundError(path)
        if path.name in existing:
            media_id = existing[path.name]
        else:
            media_id = native('import_media', path=str(path))[0]['id']
        if track == 2:
            properties = native('media_properties', media_id=media_id, properties={'Alpha mode': 'Straight'})
            if properties['current'].get('Alpha mode') != 'Straight':
                raise RuntimeError(f'Unexpected foreground alpha mode: {properties}')
        if media_type == 'video' and timeline['tracks'][track - 1]:
            if any(item['name'] == path.name for item in timeline['tracks'][track - 1]):
                continue
            raise RuntimeError(f'Video track {track} is occupied')
        added = native('append', timeline=TIMELINE, media_id=media_id, media_type=media_type,
                       start_frame=0, end_frame=300, record_frame=0, track_index=track)[0]
        if added['start'] != 0 or added['end_frame'] != 300 or added['duration'] != 300:
            raise RuntimeError(f'Unexpected edit range: {added}')
        print(added, flush=True)


def render(output):
    if output.exists():
        raise FileExistsError(output)
    queued = native('render', timeline=TIMELINE, output=str(output), mark_in=0, mark_out=299, audio=True)
    job_id = queued['job_id']
    print(queued, flush=True)
    last_state = None
    while True:
        state = native('render_status', job_id=job_id)
        if state != last_state:
            print(state, flush=True)
            last_state = state
        normalized = json.dumps(state).lower()
        if 'complete' in normalized and output.is_file() and output.stat().st_size:
            return job_id
        if any(failure in normalized for failure in ('failed', 'cancelled', 'canceled', 'error')):
            raise RuntimeError(state)
        time.sleep(2)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--attach', action='store_true')
    parser.add_argument('--output', type=Path, default=ROOT / 'finished.mp4')
    parser.add_argument('--deliver', action='store_true')
    args = parser.parse_args()
    if args.build:
        project = native('new_project')
        if project['fps'] != 25 or str(project['width']) != '512' or str(project['height']) != '288':
            raise RuntimeError(project)
        native('project_settings', settings={'colorScienceMode': 'davinciYRGB',
               'colorSpaceTimeline': 'Rec.709 Gamma 2.4', 'colorSpaceOutput': 'Rec.709 Gamma 2.4'})
        native('create_timeline', name=TIMELINE, video_tracks=2)
    if args.build or args.attach:
        import_layers()
    project = native('inspect')
    print(json.dumps(project, ensure_ascii=False), flush=True)
    job_id = render(args.output.resolve())
    if args.deliver:
        print(native('export_project', path=str(ROOT / 'project.drp')), flush=True)
        manifest = {'project_name': project['name'], 'timeline': TIMELINE, 'render_job_id': job_id}
        (ROOT / 'submission.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
