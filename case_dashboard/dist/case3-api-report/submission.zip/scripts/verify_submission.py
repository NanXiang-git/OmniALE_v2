import ast,cv2,json,hashlib,numpy as np,subprocess,zipfile
from pathlib import Path
from jsonschema import Draft202012Validator
SUB=Path(__file__).resolve().parent.parent

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def probe(p,frames=False):
 args=['ffprobe','-v','error','-count_frames','-show_streams','-show_format']
 if frames:args+=['-show_frames']
 return json.loads(subprocess.check_output(args+['-of','json',str(p)],text=True))

def decode(p):
 v=cv2.VideoCapture(str(p));out=[]
 while True:
  ok,a=v.read()
  if not ok:break
  out.append(a)
 v.release();return out

result={'checks_are_solver_diagnostics':True,'formal_score':None,'accepted':None,'independent_reopen_rerender_audit':None,'schemas':{},'videos':{},'intermediates':{},'project':{}}
for name in ['submission','report']:
 data=json.loads((SUB/f'{name}.json').read_text());schema=json.loads((SUB/f'{name}.schema.json').read_text());Draft202012Validator(schema).validate(data);result['schemas'][name]='valid'
sub=json.loads((SUB/'submission.json').read_text());jobs=json.loads((SUB/'scripts/final_jobs.json').read_text())
for c in [1,2]:
 path=SUB/f'output_{c}.mp4';pr=probe(path,True);streams=pr['streams'];vs=[s for s in streams if s['codec_type']=='video'];assert len(vs)==1;v=vs[0]
 assert v['codec_name']=='h264' and (v['width'],v['height'])==(512,288)
 assert v['r_frame_rate']==v['avg_frame_rate']=='25/1' and int(v['nb_read_frames'])==100
 assert abs(float(pr['format']['duration'])-4)<.040001
 assert all(s['codec_type']=='video' or(s['codec_type']=='data' and s['codec_tag_string']=='tmcd') for s in streams)
 pts=np.array([float(f['best_effort_timestamp_time']) for f in pr['frames'] if f.get('media_type')=='video']);assert len(pts)==100 and np.max(abs(pts-np.arange(100)/25))<1e-6
 frames=decode(path);assert len(frames)==100
 maes=[];bgerrors=[];temporal=[]
 for f,out in enumerate(frames):
  inp=cv2.imread(f'/candidate/input/clip_{c}/{f:04d}.png')
  alpha=cv2.imread(str(SUB/f'assets/alpha_{c}/{f:04d}.png'),0)
  mask=cv2.erode(np.uint8(alpha==255),np.ones((5,5),np.uint8))>0
  if mask.any():
   maes.append(float(np.abs(out.astype(float)-inp.astype(float))[mask].mean()))
   choices=[]
   for k in range(max(0,f-2),min(100,f+3)):
    cand=cv2.imread(f'/candidate/input/clip_{c}/{k:04d}.png')
    choices.append((float(np.abs(out.astype(float)-cand.astype(float))[mask].mean()),k))
   own=[e for e,k in choices if k==f][0];best=min(e for e,k in choices);temporal.append(own-best)
  bg=cv2.erode(np.uint8(alpha==0),np.ones((9,9),np.uint8))>0
  if bg.any():bgerrors.extend(np.max(abs(out.astype(int)-np.array([0,255,0])),axis=2)[bg].tolist())
 p0=cv2.imread(f'/candidate/input/target_preview_{c}.png');e=cv2.Canny(cv2.cvtColor(p0,cv2.COLOR_BGR2GRAY),80,160)>0;z=cv2.Canny(cv2.cvtColor(frames[0],cv2.COLOR_BGR2GRAY),80,160)>0
 result['videos'][f'clip_{c}']={'file':path.name,'sha256':sha(path),'decoded_frames':len(frames),'width':v['width'],'height':v['height'],'frame_rate':v['avg_frame_rate'],'duration':pr['format']['duration'],'pts_max_error_seconds':float(np.max(abs(pts-np.arange(100)/25))),'codec':v['codec_name'],'pixel_format':v['pix_fmt'],'streams':[{'type':s['codec_type'],'tag':s.get('codec_tag_string')} for s in streams],'color_tags':{k:v.get(k) for k in ['color_range','color_space','color_transfer','color_primaries']},'opaque_source_mean_absolute_error_RGB_8bit':float(np.mean(maes)),'mean_own_frame_error_minus_best_nearby_frame_error':float(np.mean(temporal)),'confident_green_error_mean_maxchannel_8bit':float(np.mean(bgerrors)),'confident_green_error_p95_maxchannel_8bit':float(np.percentile(bgerrors,95)),'public_frame_zero_only_canny_iou':float(np.count_nonzero(e&z)/np.count_nonzero(e|z)),'render_job_id':jobs[f'clip_{c}']}
 # Exact decoder check for every lossless RGBA movie frame.
 movie=SUB/f'assets/foreground_{c}.mov';raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(movie),'-f','rawvideo','-pix_fmt','bgra','-an','pipe:1'])
 rgba=np.frombuffer(raw,np.uint8).reshape(-1,288,512,4);assert len(rgba)==100
 maxerr=0
 for f in range(100):
  png=cv2.imread(str(SUB/f'assets/foreground_{c}_final/{f:04d}.png'),-1);assert png.shape==(288,512,4)
  maxerr=max(maxerr,int(np.max(abs(png.astype(int)-rgba[f].astype(int)))))
  alpha=cv2.imread(str(SUB/f'assets/alpha_{c}/{f:04d}.png'),0);assert np.array_equal(png[:,:,3],alpha)
 assert maxerr==0
 mp=probe(movie)['streams'][0];assert mp['avg_frame_rate']=='25/1' and mp['codec_name']=='qtrle'
 result['intermediates'][f'clip_{c}']={'file':str(movie.relative_to(SUB)),'sha256':sha(movie),'decoded_frames':100,'frame_rate':mp['avg_frame_rate'],'codec':mp['codec_name'],'RGBA_max_difference_from_PNGs':maxerr,'alpha_PNGs_match':True}
 print('verified',c,flush=True)
# Native operation provenance and completion-before-export ordering.
records=[json.loads(s) for s in (SUB/'scripts/native_receipts.jsonl').read_text().splitlines()]
export=[r for r in records if r['operation']=='export_project'][-1];assert export['receipt']['ok'] and export['receipt']['result']['exported']
for c in [1,2]:
 render=[r for r in records if r['operation']=='render' and r['arguments']['output']==str(SUB/f'output_{c}.mp4')][-1]
 assert render['receipt']['result']['job_id']==jobs[f'clip_{c}']==sub['clips'][c-1]['render_job_id']
 statuses=[r for r in records if r['operation']=='render_status' and r['arguments']['job_id']==jobs[f'clip_{c}'] and r['receipt']['result'].get('JobStatus')=='Complete']
 assert statuses and statuses[-1]['receipt']['sequence']<export['receipt']['sequence']
drp=SUB/'project.drp';assert drp.is_file() and drp.stat().st_size>0
result['project']={'file':'project.drp','bytes':drp.stat().st_size,'sha256':sha(drp),'native_export_receipt_success':True,'both_native_renders_complete_before_export':True,'zip_container':zipfile.is_zipfile(drp),'independent_import_not_available':True}
if zipfile.is_zipfile(drp):
 with zipfile.ZipFile(drp) as z:assert z.testzip() is None;result['project']['container_members']=z.namelist()
inspect=json.loads((SUB/'scripts/native_final_inspection.json').read_text());tls={t['name']:t for t in inspect['timelines']}
for name in ['Delivery_1_Woman','Delivery_2_Adult_Child']:
 t=tls[name];assert len(t['tracks'])==2
 fg=t['tracks'][1][0];assert fg['start']==0 and fg['duration']==100
 for key in ['Pan','Tilt']:assert fg['properties'][key]==0
 for key in ['ZoomX','ZoomY']:assert fg['properties'][key]==1
result['project']['timeline_names']=list(tls);result['project']['two_delivery_foregrounds_have_100_frames']=True
# Syntax-check delivered Python without generating cache files.
for p in (SUB/'scripts').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
result['python_scripts_parse']=True
(SUB/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
with (SUB/'checksums.sha256').open('w') as f:
 for p in sorted(SUB.rglob('*')):
  if p.is_file() and p.name!='checksums.sha256' and '__pycache__' not in p.parts:f.write(f'{sha(p)}  {p.relative_to(SUB)}\n')
print(json.dumps({'schemas':result['schemas'],'videos':{k:{kk:vv for kk,vv in v.items() if kk in ['decoded_frames','duration','frame_rate','opaque_source_mean_absolute_error_RGB_8bit','mean_own_frame_error_minus_best_nearby_frame_error']} for k,v in result['videos'].items()},'project':result['project']},indent=2))
