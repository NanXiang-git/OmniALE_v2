"""Run only once both native delivery renders have completed."""
import json
from pathlib import Path
from resolve_project import call,SUB
jobs=json.loads((SUB/'scripts/final_jobs.json').read_text())
for job in jobs.values():
 status=call('render_status',job_id=job)
 if status.get('JobStatus')!='Complete' or status.get('CompletionPercentage')!=100:
  raise RuntimeError('Native render not complete; project export deferred')
settings=call('project_settings',settings={})
(SUB/'scripts/native_color_settings.json').write_text(json.dumps(settings,indent=2))
r=call('export_project',path=str(SUB/'project.drp'))
(SUB/'scripts/project_export_receipt.json').write_text(json.dumps(r,indent=2))
