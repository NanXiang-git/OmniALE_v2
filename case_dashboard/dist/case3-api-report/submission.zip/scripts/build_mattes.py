"""Reproduce the chosen foreground pipeline from public RGB/preview inputs.
All scratch products go to /workspace/scratch. Existing final assets are replaced.
"""
from pathlib import Path
import subprocess,sys,numpy as np
HERE=Path(__file__).resolve().parent
for script in ['affine1.py','refine1.py','landmark_interp.py']:
 subprocess.run([sys.executable,str(HERE/script)],check=True)
np.savez_compressed(HERE.parent/'assets/contour_guides.npz',clip_1=np.load('/workspace/scratch/refine1.npy'),clip_2=np.load('/workspace/scratch/landmarkcut2.npy'))
for script in ['finalize_mattes.py','encode_foregrounds.py']:
 subprocess.run([sys.executable,str(HERE/script)],check=True)
