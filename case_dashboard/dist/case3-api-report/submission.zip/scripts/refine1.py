import sys,cv2,numpy as np
sys.path.insert(0,'/workspace/submission/scripts');from matte import *
preds=np.load(TMP/'affine1.npy');out=[]
for f in range(100):
 a=read(1,f);p=preds[f];oc=occ(f)
 # +/- 9px unknown contour
 dil=cv2.dilate(p,np.ones((19,19),np.uint8));ero=cv2.erode(p,np.ones((19,19),np.uint8))
 lab=np.zeros((H,W),np.uint8);lab[dil>0]=2;lab[p>0]=3;lab[ero>0]=1
 lab[oc>0]=0
 bg=np.zeros((1,65),np.float64);fg=bg.copy();cv2.grabCut(a,lab,None,bg,fg,4,cv2.GC_INIT_WITH_MASK)
 mask=np.uint8((lab==1)|(lab==3));out.append(mask)
np.save(TMP/'refine1.npy',out)
from PIL import Image,ImageDraw
im=Image.new('RGB',(5*512,2*312),'#555');dr=ImageDraw.Draw(im)
for k,f in enumerate([0,10,20,30,40,50,60,70,80,99]):
 a=read(1,f);a[out[f]==0]=[0,255,0];x=k%5*512;y=k//5*312;im.paste(Image.fromarray(a[:,:,::-1]),(x,y+24));dr.text((x,y),str(f))
im.save(TMP/'refine1.jpg')
