"""Lossless, 25 fps, straight-alpha intermediates. No green compositing here."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent.parent
for c in (1,2):
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','25','-i',str(ROOT/f'assets/foreground_{c}_final/%04d.png'),'-c:v','qtrle','-pix_fmt','argb','-r','25','-an',str(ROOT/f'assets/foreground_{c}.mov')],check=True)
