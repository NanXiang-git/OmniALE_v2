import os,cv2,numpy as np,json
from pathlib import Path
cv2.setNumThreads(4)
ROOT=Path('/candidate/input');TMP=Path('/workspace/scratch');ASSET=Path('/workspace/submission/assets')
H,W=288,512
Y,X=np.mgrid[:H,:W].astype(np.float32)
def read(c,f): return cv2.imread(str(ROOT/f'clip_{c}'/f'{f:04d}.png'))
def preview(c):return cv2.imread(str(ROOT/f'target_preview_{c}.png'))
def occ(f):
 a,b=read(1,f),read(2,f); diff=np.max(abs(a.astype(np.int16)-b.astype(np.int16)),axis=2)
 mask=np.uint8(diff<=2)
 # All common overlay components, discard chance small matches.
 n,lab,st,ct=cv2.connectedComponentsWithStats(mask,8)
 out=np.zeros((H,W),np.uint8)
 for k in range(1,n):
  if st[k,4]>25:out[lab==k]=1
 out=cv2.morphologyEx(out,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
 return out

def initialize(c):
 p=preview(c).astype(float)/255; g=np.array([0,1,0]);d=np.linalg.norm(p-g,axis=2)
 return (d>.015).astype(np.uint8)

def flow_track(c):
 """Propagate preview support using classical dense DIS and bounded GrabCut."""
 ims=[read(c,f) for f in range(100)]
 gr=[cv2.cvtColor(a,cv2.COLOR_BGR2GRAY) for a in ims]
 dis=cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
 dis.setFinestScale(0);dis.setGradientDescentIterations(25);dis.setVariationalRefinementIterations(5)
 mask=initialize(c);out=[mask]; prevoc=occ(0); lastmove=np.zeros(2,np.float32)
 for f in range(1,100):
  flow=dis.calc(gr[f],gr[f-1],None)
  oc=occ(f)
  occnear=cv2.dilate(oc,np.ones((31,31),np.uint8))
  prevnear=cv2.dilate(prevoc,np.ones((31,31),np.uint8))
  sampled=cv2.remap(prevnear,X+flow[:,:,0],Y+flow[:,:,1],cv2.INTER_NEAREST)
  bad=(occnear>0)|(sampled>0)
  # Median backward target flow away from occluders predicts hidden support.
  safe=(cv2.erode(mask,np.ones((11,11),np.uint8))>0)&(~bad)
  vals=flow[safe]
  move=np.median(vals,axis=0) if len(vals)>80 else lastmove
  if np.linalg.norm(move)>10:move=lastmove
  flow[bad]=move
  lastmove=move
  prior=cv2.remap(mask.astype(np.float32),X+flow[:,:,0],Y+flow[:,:,1],cv2.INTER_LINEAR)
  pred=(prior>.5).astype(np.uint8)
  # Keep a modest unknown contour to allow flow corrections.
  dil=cv2.dilate(pred,np.ones((9,9),np.uint8));ero=cv2.erode(pred,np.ones((7,7),np.uint8))
  labels=np.where(dil,cv2.GC_PR_BGD,cv2.GC_BGD).astype(np.uint8)
  labels[pred>0]=cv2.GC_PR_FGD;labels[ero>0]=cv2.GC_FGD
  oc=occ(f);labels[oc>0]=cv2.GC_BGD
  bg=np.zeros((1,65),np.float64);fg=np.zeros((1,65),np.float64)
  cv2.grabCut(ims[f],labels,None,bg,fg,2,cv2.GC_INIT_WITH_MASK)
  mask=np.uint8((labels==1)|(labels==3))
  # For tracking only, fill occlusion intersection with predicted support.
  near=cv2.dilate(oc,np.ones((5,5),np.uint8))
  mask[near>0]=pred[near>0]
  prevoc=oc
  np.save(TMP/f'track{c}.npy',np.stack(out+[mask.copy()]))
  out.append(mask.copy())
  if f%10==0: print('track',c,f,int(mask.sum()),flush=True)
 np.save(TMP/f'track{c}.npy',np.stack(out))
 if True:
  from PIL import Image,ImageDraw
  sheet=Image.new('RGB',(5*512,2*312),(50,50,50));d=ImageDraw.Draw(sheet)
  for k,f in enumerate([0,10,20,30,40,50,60,70,80,99]):
   m=out[f]*(1-occ(f));a=ims[f].copy();a[m==0]=[0,255,0]
   x=k%5*512;y=k//5*312;sheet.paste(Image.fromarray(cv2.cvtColor(a,cv2.COLOR_BGR2RGB)),(x,y+24));d.text((x,y+4),str(f))
  sheet.save(TMP/f'track_sheet{c}.jpg')
if __name__=='__main__':
 import sys
 for c in map(int,sys.argv[1:] or [1,2]):flow_track(c)
