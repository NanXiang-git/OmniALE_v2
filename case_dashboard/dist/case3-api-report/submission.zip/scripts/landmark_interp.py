from contour_setup import *
AD={10:[0,25,31,33,35,40],20:[0,26,32,37,43,48],30:[0,26,32,35,39,45],40:[0,25,31,37,42,49],50:[0,25,30,36,41,47],60:[0,26,32,38,43,49],70:[0,26,32,38,43,49],80:[0,26,32,38,43,49],90:[0,26,32,38,43,49],99:[0,26,32,38,43,49]}
CH={10:[0,6,12,16,19,23,28,34,40,42,45,51],20:[0,6,14,22,26,30,35,41,47,50,56,63],30:[0,6,16,20,23,28,34,39,45,48,57,65],40:[0,6,15,19,23,28,32,37,42,46,51,55],50:[0,6,12,16,19,24,30,36,42,47,52,55],60:[0,6,12,16,19,23,29,35,41,46,49,53],70:[0,6,11,15,18,22,28,34,40,44,47,51],80:[0,6,11,15,18,22,28,34,40,44,48,52],90:[0,6,12,15,19,24,29,35,41,44,51,56],99:[0,6,14,18,22,26,32,38,44,47,56,63]}
AD[0]=AD[10];CH[0]=CH[10]
def segmented(p,idx,n=25):
 idx=idx+[len(p)];p=np.vstack([p,p[0]]);out=[]
 for a,b in zip(idx[:-1],idx[1:]):
  z=p[a:b+1];d=np.r_[0,np.cumsum(np.linalg.norm(np.diff(z,axis=0),axis=1))];ss=np.linspace(0,d[-1],n,endpoint=False)
  out.append(np.stack([np.interp(ss,d,z[:,0]),np.interp(ss,d,z[:,1])],1))
 return np.concatenate(out)
normalized={k:[segmented(p,(AD if o==0 else CH)[k])-centers[k][o] for o,p in enumerate(pp)] for k,pp in pol.items()}
normalized[50][0]=(normalized[40][0]+normalized[60][0])/2
priors=[];outs=[]
for f in range(100):
 lo=max(k for k in keys if k<=f);hi=min(k for k in keys if k>=f);t=0 if lo==hi else (f-lo)/(hi-lo)
 p=np.zeros((H,W),np.uint8)
 for o in range(2):
  points=normalized[lo][o]*(1-t)+normalized[hi][o]*t+splines[o](f);cv2.fillPoly(p,[np.int32(np.round(points))],1)
 priors.append(p)
 if f==0:m=initialize(2)*(1-occ(f))
 else:m=cut(read(2,f),p,occ(f))
 outs.append(m)
 if f%10==0:print('landmark local cut',f,flush=True)
np.save(TMP/'landmarkpriors2.npy',priors);np.save(TMP/'landmarkcut2.npy',outs)
from PIL import Image,ImageDraw
for typ,fs in [('keys',[0,10,20,30,40,50,60,70,80,99]),('middle',[5,15,25,35,45,55,65,75,85,95])]:
 sh=Image.new('RGB',(5*512,2*312),'#555');d=ImageDraw.Draw(sh)
 for k,f in enumerate(fs):
  a=read(2,f);a[outs[f]==0]=[0,255,0];x=k%5*512;y=k//5*312;sh.paste(Image.fromarray(a[:,:,::-1]),(x,y+24));d.text((x,y),str(f))
 sh.save(TMP/f'landmark_{typ}.jpg')
