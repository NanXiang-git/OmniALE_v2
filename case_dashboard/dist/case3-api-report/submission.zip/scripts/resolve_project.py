"""All native project editing, rendering and export use the supplied typed RPC API."""
import sys,json,time
from pathlib import Path
sys.path.insert(0,'/runtime')
from resolve_rpc import resolve_call
SUB=Path('/workspace/submission');LOG=SUB/'scripts'/'native_receipts.jsonl'
def call(op,**kw):
 r=resolve_call(op,**kw)
 with LOG.open('a') as f:f.write(json.dumps({'operation':op,'arguments':kw,'receipt':r})+'\n')
 print(op,json.dumps(r)[:1400],flush=True)
 if not r.get('ok'):raise RuntimeError(r)
 return r.get('result')
if __name__=='__main__':
 task=sys.argv[1]
 if task=='setup':
  settings=call('project_settings',settings={'colorScienceMode':'davinciYRGB','separateColorSpaceAndGamma':'0','colorSpaceTimeline':'sRGB','colorSpaceOutput':'sRGB'})
  green=call('import_media',path='/candidate/input/green.png')
  (SUB/'scripts'/'green_import.json').write_text(json.dumps(green,indent=2))
 elif task=='import1':
  r=call('import_media',path='/workspace/submission/assets/foreground_1/%04d.png',start_index=0,end_index=99)
  (SUB/'scripts'/'foreground1_import.json').write_text(json.dumps(r,indent=2))
 elif task=='inspect':call('inspect')
