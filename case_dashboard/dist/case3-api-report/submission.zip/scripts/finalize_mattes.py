"""Create editable straight-alpha foregrounds, never a finished green-background movie."""
import sys,cv2,numpy as np
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from matte import read,occ,initialize,ROOT,TMP,ASSET,H,W,Y,X
from matting import matte,recover_foreground,kernel
from scipy.interpolate import CubicSpline
cv2.setNumThreads(4)
PHONES={0:[(263,15),(271,13),(282,32),(274,36)],10:[(263,14),(273,12),(281,26),(275,31)],20:[(275,14),(285,12),(293,28),(284,33)],30:[(324,16),(333,15),(341,32),(331,36)],40:[(408,16),(416,14),(428,31),(418,35)],50:[(449,15),(457,14),(469,31),(460,35)],60:[(394,18),(402,16),(413,33),(404,37)],70:[(314,19),(322,17),(332,33),(323,38)],80:[(269,18),(278,17),(288,32),(279,37)],90:[(264,18),(274,17),(284,33),(275,38)],99:[(264,18),(274,17),(284,33),(275,38)]}
phone_interp=CubicSpline(list(PHONES),np.array(list(PHONES.values())),axis=0,bc_type='natural')
def fill_small_holes(m,limit=8):
 n,l,st,_=cv2.connectedComponentsWithStats(1-m,8)
 for k in range(1,n):
  if st[k,4]<=limit and st[k,0]>0 and st[k,1]>0 and st[k,0]+st[k,2]<W and st[k,1]+st[k,3]<H:m[l==k]=1
 return m

def build(c):
 masks=np.load(ASSET/'contour_guides.npz')[f'clip_{c}']
 dest=ASSET/f'foreground_{c}_final';ald=ASSET/f'alpha_{c}';dest.mkdir(exist_ok=True);ald.mkdir(exist_ok=True)
 result=[]
 for f,m in enumerate(masks):
  im=read(c,f);m=m.copy();oc=occ(f);hardocc=cv2.dilate(oc,kernel(1))
  if c==2:
   B,G,R=[im[:,:,i].astype(float) for i in range(3)]
   ph=np.zeros((H,W),np.uint8);cv2.fillPoly(ph,[np.int32(phone_interp(f))],1)
   # Restore the held phone only where the source's blue-gray device is visible.
   m|=np.uint8((ph>0)&(B>R+8)&(B>G+2))
   reject=((G>R+12)&(G>B+8))|((B>R+23)&(B>G+5)&(Y>45)&(ph==0))|((Y>215)&(R<55)&(B<70))
   m[reject]=0
   m=fill_small_holes(m)
  else:
   # Most reliable foreground support is the original public frame-zero preview.
   if f==0:m=initialize(1)
  m[hardocc>0]=0
  n,lab,st,_=cv2.connectedComponentsWithStats(m,8)
  for k in range(1,n):
   if st[k,4]<3:m[lab==k]=0
  a=matte(im,m,hardocc,r=2,skeleton=False)
  # Constrain obvious removed occluders, and remove negligible alpha dust.
  a[hardocc>0]=0;a[a<.015]=0;a[a>.985]=1
  F=recover_foreground(im,a)
  rgba=np.dstack([F,np.uint8(a*255+.5)])
  cv2.imwrite(str(dest/f'{f:04d}.png'),rgba)
  cv2.imwrite(str(ald/f'{f:04d}.png'),rgba[:,:,3])
  result.append(a)
  if f%20==0:print('alpha',c,f,flush=True)
 np.save(TMP/f'finalalpha{c}.npy',result)
if __name__=='__main__':
 for c in map(int,sys.argv[1:] or [1,2]):build(c)
