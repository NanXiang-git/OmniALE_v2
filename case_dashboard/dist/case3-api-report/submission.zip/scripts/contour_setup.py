import sys,cv2,numpy as np
from scipy.interpolate import CubicSpline
sys.path.insert(0,'/workspace/submission/scripts');from matte import *;from anchors import POLYS
from localcut import cut
cv2.setNumThreads(4)
centers={0:[(226,24),(187,100)],10:[(225,23),(190,96)],20:[(238,25),(204,98)],30:[(295,25),(260,100)],40:[(387,24),(359,109)],50:[(430,22),(411,107)],60:[(374,20),(358,108)],70:[(288,20),(267,107)],80:[(245,20),(222,100)],90:[(237,19),(209,94)],99:[(234,19),(209,93)]}
# Frame-zero guide shapes are the first nearby contours displaced to the frame-zero head locations.
pol={f:[np.array(p,float) for p in pp] for f,pp in POLYS.items()}
pol[0]=[p+np.array(centers[0][o])-np.array(centers[10][o]) for o,p in enumerate(pol[10])]
# Derive adult frame-50 guide from its two surrounding poses rather than the heavily occluded view.
def resample(p,n=300):
 p=np.vstack([p,p[0]]);d=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))];s=np.linspace(0,d[-1],n,endpoint=False)
 return np.stack([np.interp(s,d,p[:,0]),np.interp(s,d,p[:,1])],1)
keys=sorted(pol);splines=[CubicSpline(keys,np.array([centers[k][o] for k in keys]),axis=0,bc_type='natural') for o in range(2)]
normalized={k:[resample(p)-centers[k][o] for o,p in enumerate(pp)] for k,pp in pol.items()}
normalized[50][0]=(normalized[40][0]+normalized[60][0])/2
