import sys,cv2,numpy as np
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import maximum_flow,breadth_first_order
sys.path.insert(0,'/workspace/submission/scripts');from matte import *;from anchors import POLYS
cv2.setNumThreads(4)
ker=lambda r:cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*r+1,2*r+1))
def cut(im,p,oc,c=2):
 h,w=p.shape
 dt=cv2.distanceTransform(p,cv2.DIST_L2,5)-cv2.distanceTransform(1-p,cv2.DIST_L2,5)
 fg=dt>5;bg=dt< -6
 # Unknown includes all thin limbs; global original-F samples support their colors.
 fg[oc>0]=False;bg[oc>0]=True
 # Reject dubious foreground cores using only public preview color examples.
 lab0=cv2.cvtColor(read(c,0),cv2.COLOR_BGR2LAB).astype(float)/8
 om0=cv2.erode(initialize(c),ker(3))>0
 tree0=cKDTree(lab0[om0])
 laball=cv2.cvtColor(im,cv2.COLOR_BGR2LAB).astype(float)/8
 dist0,_=tree0.query(laball.reshape(-1,3),k=1)
 fg &= (dist0.reshape(h,w)<2.0)
 unknown=~(fg|bg);yy,xx=np.where(unknown);n=len(xx);idx=np.full((h,w),-1,np.int32);idx[unknown]=np.arange(n)
 lab=cv2.cvtColor(im,cv2.COLOR_BGR2LAB).astype(float)
 feat=np.dstack([lab/8,X/12,Y/12])
 # use local confident foreground; append global public preview foreground color samples at a spatial penalty.
 ft=cKDTree(feat[fg]);bt=cKDTree(feat[bg])
 df,_=ft.query(feat[unknown],k=1);db,_=bt.query(feat[unknown],k=1)
 orig=read(c,0);om=initialize(c);ol=cv2.cvtColor(orig,cv2.COLOR_BGR2LAB).astype(float)
 oft=cKDTree((ol/8)[cv2.erode(om,ker(3))>0]);df0,_=oft.query((lab/8)[unknown],k=1)
 df=np.minimum(df,np.sqrt(df0**2+1.5**2))
 # Confidence normalized local appearance, with weak signed-distance shape preference.
 Dfg=np.clip(df**2,0,30)+np.clip(-dt[unknown],0,10)*.35
 Dbg=np.clip(db**2,0,30)+np.clip(dt[unknown],0,10)*.35
 rows=[np.full(n,n),np.arange(n)];cols=[np.arange(n),np.full(n,n+1)];vals=[Dbg,Dfg]
 for dy,dx in [(0,1),(1,0),(1,1),(1,-1)]:
  ny=yy+dy;nx=xx+dx;valid=(ny>=0)&(ny<h)&(nx>=0)&(nx<w)
  aa=np.where(valid)[0];ny=ny[valid];nx=nx[valid];jj=idx[ny,nx]
  diff=np.sum((lab[yy[aa],xx[aa]]-lab[ny,nx])**2,axis=1)
  weights=(3*np.exp(-diff/(2*20**2))+.04)/(2**.5 if dy and dx else 1)
  var=jj>=0
  rows.extend([aa[var],jj[var]]);cols.extend([jj[var],aa[var]]);vals.extend([weights[var],weights[var]])
  # Fixed neighbor's label imposes pairwise unary.
  fix=~var
  a=aa[fix];bfg=fg[ny[fix],nx[fix]];wei=weights[fix]
  rows.extend([np.full(np.count_nonzero(bfg),n),a[~bfg]])
  cols.extend([a[bfg],np.full(np.count_nonzero(~bfg),n+1)])
  vals.extend([wei[bfg],wei[~bfg]])
 rows=np.concatenate(rows);cols=np.concatenate(cols);vals=np.maximum(np.concatenate(vals)*100,0).astype(np.int64)
 graph=coo_matrix((vals,(rows,cols)),shape=(n+2,n+2)).tocsr()
 fl=maximum_flow(graph,n,n+1,method='dinic');res=graph-fl.flow
 reached=breadth_first_order(res,n,directed=True,return_predecessors=False)
 out=fg.copy();reached=reached[reached<n];out[yy[reached],xx[reached]]=True
 return out.astype(np.uint8)
if __name__=='__main__':
 from PIL import Image,ImageDraw
 out=[]
 for f in [0,10,20,30,40,50,60,70,80,90,99]:
  p=np.zeros((H,W),np.uint8)
  if f==0:p=initialize(2)
  else:
   for poly in POLYS[f]:cv2.fillPoly(p,[np.array(poly,np.int32)],1)
  m=cut(read(2,f),p,occ(f));np.save(TMP/f'localcut2_{f}.npy',m);out.append((f,m))
 im=Image.new('RGB',(4*512,3*312),'#555');d=ImageDraw.Draw(im)
 for k,(f,m) in enumerate(out):
  a=read(2,f);a[m==0]=[0,255,0];x=k%4*512;y=k//4*312;im.paste(Image.fromarray(a[:,:,::-1]),(x,y+24));d.text((x,y),str(f))
 im.save(TMP/'localcut.jpg')
