import sys,cv2,numpy as np,json
sys.path.insert(0,'/workspace/submission/scripts');from matte import *
b=read(1,0);m=initialize(1);g=cv2.cvtColor(b,cv2.COLOR_BGR2GRAY)
orb=cv2.ORB_create(nfeatures=3000,edgeThreshold=5,fastThreshold=7)
k0,d0=orb.detectAndCompute(g,cv2.erode(m,np.ones((9,9),np.uint8)))
outs=[];trans=[]
for f in range(100):
 a=read(1,f);k,d=orb.detectAndCompute(a,None);matches=cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(d0,d,k=2);good=[i for i,j in matches if i.distance<.72*j.distance]
 p=np.float32([k0[i.queryIdx].pt for i in good]);q=np.float32([k[i.trainIdx].pt for i in good]);M,inside=cv2.estimateAffinePartial2D(p,q,method=cv2.RANSAC,ransacReprojThreshold=1.5)
 if M is None:M=trans[-1]
 trans.append(M)
 pred=cv2.warpAffine(m,M,(W,H))
 outs.append(pred)
np.save(TMP/'affine1.npy',np.stack(outs));np.save(TMP/'trans1.npy',trans)
from PIL import Image,ImageDraw
im=Image.new('RGB',(5*512,2*312),'#555');dr=ImageDraw.Draw(im)
for k,f in enumerate([0,10,20,30,40,50,60,70,80,99]):
 a=read(1,f);co=cv2.findContours(outs[f],cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)[0];cv2.drawContours(a,co,-1,(0,0,255),1);x=k%5*512;y=k//5*312;im.paste(Image.fromarray(a[:,:,::-1]),(x,y+24));dr.text((x,y),str(f))
im.save(TMP/'affine1.jpg')
print(np.array(trans)[::10])
