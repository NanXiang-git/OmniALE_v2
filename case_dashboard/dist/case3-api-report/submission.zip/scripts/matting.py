"""Local closed-form color-line matting; no pretrained model.
Uses scipy only for a sparse linear system, OpenCV/NumPy for image operations.
"""
import cv2,numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve
from scipy.ndimage import distance_transform_edt

def linear(x):
 x=np.asarray(x,np.float64)/255
 return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
def srgb(x):
 x=np.clip(x,0,1)
 return np.where(x<=.0031308,12.92*x,1.055*x**(1/2.4)-.055)
def kernel(r):return cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*r+1,2*r+1))
def matte(im,m,occ=None,r=4,skeleton=True):
 h,w=m.shape
 fg=cv2.erode(m,kernel(r))>0;bg=cv2.dilate(m,kernel(3))==0
 if skeleton:
  dt=cv2.distanceTransform(m,cv2.DIST_L2,5)
  ridge=(dt>=1.9)&(dt==cv2.dilate(dt,np.ones((3,3),np.uint8)))&(dt<=r+1)
  fg|=ridge
 # Occluders belong to background in the visible alpha.
 if occ is not None:
  bg|=(occ>0);fg[occ>0]=False
 known=fg|bg;unknown=~known
 inds=np.full((h,w),-1,np.int32);inds[unknown]=np.arange(unknown.sum())
 n=unknown.sum()
 if n==0:return fg.astype(np.float64)
 c=linear(im)
 centers=cv2.dilate(unknown.astype(np.uint8),np.ones((3,3),np.uint8))>0;centers[[0,-1],:]=False;centers[:,[0,-1]]=False
 yy,xx=np.where(centers)
 offs=np.array([(dy,dx) for dy in [-1,0,1] for dx in [-1,0,1]])
 wy=yy[:,None]+offs[None,:,0];wx=xx[:,None]+offs[None,:,1]
 pixels=c[wy,wx];mu=pixels.mean(1,keepdims=True);dev=pixels-mu
 cov=np.einsum('nki,nkj->nij',dev,dev)/9+np.eye(3)[None]*1e-6/9
 inv=np.linalg.inv(cov)
 L=-(1+np.einsum('nki,nij,nlj->nkl',dev,inv,dev))/9
 L+=np.eye(9)[None]
 ui=inds[wy,wx];alpha_known=fg[wy,wx].astype(float)
 rows=np.broadcast_to(ui[:,:,None],L.shape).ravel();cols=np.broadcast_to(ui[:,None,:],L.shape).ravel();vals=L.ravel()
 va=(rows>=0)&(cols>=0)
 mat=sparse.coo_matrix((vals[va],(rows[va],cols[va])),shape=(n,n)).tocsr()
 # All known foreground contributes to the right-hand side.
 rhs_local=-(L*alpha_known[:,None,:]).sum(2)
 valid=ui>=0;rhs=np.bincount(ui[valid],weights=rhs_local[valid],minlength=n)
 mat=mat+sparse.eye(n)*1e-7
 alpha=fg.astype(np.float64);alpha[unknown]=np.clip(spsolve(mat,rhs),0,1)
 return alpha

def recover_foreground(im,alpha):
 """Recover straight F near transparent edges using nearest clean BG samples."""
 c=linear(im);bg=alpha<.015;fg=alpha>.985
 if not bg.any() or not fg.any():return im
 _,bi=distance_transform_edt(~bg,return_indices=True)
 _,fi=distance_transform_edt(~fg,return_indices=True)
 B=c[bi[0],bi[1]];Fnear=c[fi[0],fi[1]]
 a=alpha[:,:,None]
 F=(c-(1-a)*B)/np.maximum(a,.08)
 # Stable spatial foreground prior at low coverage.
 weight=np.clip((a-.05)/.6,0,1)
 F=F*weight+Fnear*(1-weight)
 F=np.where(a>.99,c,F)
 return np.uint8(np.clip(srgb(F)*255+.5,0,255))
if __name__=='__main__':
 import sys,time
 sys.path.insert(0,'/workspace/submission/scripts');from matte import read,occ
 c=int(sys.argv[1]);f=int(sys.argv[2]);m=np.load('/workspace/scratch/'+('refine1.npy' if c==1 else 'refine2b.npy'))[f]
 t=time.time();a=matte(read(c,f),m,occ(f),r=5);F=recover_foreground(read(c,f),a);np.save(f'/workspace/scratch/alpha{c}_{f}.npy',a)
 out=linear(F)*a[:,:,None]+np.array([0,1,0])*(1-a[:,:,None]);out=np.uint8(srgb(out)*255+.5)
 cv2.imwrite(f'/workspace/scratch/matted{c}_{f}.png',cv2.resize(out,None,fx=3,fy=3));print('seconds',time.time()-t)
