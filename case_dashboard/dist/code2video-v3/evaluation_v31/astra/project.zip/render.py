#!/usr/bin/env python3
"""Shared offline renderer for the frozen reconstruction and audio-driven revision."""
import argparse,csv,json,subprocess,time
from pathlib import Path
import numpy as np
from project.timeline import Project

class Diagnostics:
 def __init__(self,folder,width,height,fps):
  self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True)
  self.width=width;self.height=height;self.rows=[];self.procs={}
  yy,xx=np.mgrid[:height,:width]
  self.checker=np.repeat(np.where((xx//24+yy//24)%2,174,225)[...,None],3,axis=2).astype(np.float32)
  for name in ['portrait_alpha','portrait_checker','head_overflow']:
   fmt='rgb24' if name=='portrait_checker' else 'gray'
   self.procs[name]=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt',fmt,'-s',f'{width}x{height}','-r',str(fps),'-i','-','-an','-c:v','libx264','-threads','2','-preset','fast','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(self.folder/(name+'.mp4'))],stdin=subprocess.PIPE)
 def write(self,project):
  person=project.portrait.last_person
  if person is None:
   alpha=np.zeros((self.height,self.width),np.uint8);overflow=alpha
   checker=self.checker.astype(np.uint8)
  else:
   alpha=person[...,3];overflow=project.portrait.last_overflow
   a=alpha[...,None].astype(np.float32)/255
   checker=np.uint8(person[...,:3]*a+self.checker*(1-a))
  self.procs['portrait_alpha'].stdin.write(np.ascontiguousarray(alpha).tobytes())
  self.procs['portrait_checker'].stdin.write(np.ascontiguousarray(checker).tobytes())
  self.procs['head_overflow'].stdin.write(np.ascontiguousarray(overflow).tobytes())
  self.rows.append(dict(project.last_signals))
 def close(self):
  for p in self.procs.values():p.stdin.close()
  for p in self.procs.values():
   if p.wait():raise RuntimeError('Diagnostic encoding failed')
  if self.rows:
   with (self.folder/'control_signals.csv').open('w',newline='') as fp:
    writer=csv.DictWriter(fp,fieldnames=list(self.rows[0]));writer.writeheader();writer.writerows(self.rows)

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--mode',required=True,choices=['reconstruction','revision'])
 ap.add_argument('--config',required=True);ap.add_argument('--output',required=True)
 ap.add_argument('--preview-frames',help='Comma-separated indices; --output is a PNG directory.')
 ap.add_argument('--no-diagnostics',action='store_true',help='Skip automatic diagnostic videos for a variant render.')
 args=ap.parse_args();cfg_path=Path(args.config).resolve();cfg=json.loads(cfg_path.read_text())
 project=Project(cfg,args.mode,cfg_path)
 out=Path(args.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
 if args.preview_frames is not None:
  out.mkdir(parents=True,exist_ok=True)
  for f in map(int,args.preview_frames.split(',')):
   project.render(f).save(out/f'{f:03d}.png');print(f'Preview {f}',flush=True)
  return
 if project.audio:
  (out.parent/'audio_events.json').write_text(json.dumps(project.audio.report(),indent=2)+'\n')
 cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f"{cfg['width']}x{cfg['height']}",'-r',str(cfg['fps']),'-i','-']
 if project.audio:cmd+=['-i',str(project.audio.path),'-map','0:v:0','-map','1:a:0','-c:a','aac','-b:a','320k','-ar','48000']
 else:cmd+=['-an']
 cmd+=['-vf','scale=out_color_matrix=bt709:out_range=tv','-c:v','libx264','-threads','4','-preset',cfg.get('render',{}).get('preset','medium'),'-crf',str(cfg.get('render',{}).get('crf',17)),'-pix_fmt','yuv420p','-r',str(cfg['fps']),'-frames:v',str(cfg['frames']),'-t',str(cfg['frames']/cfg['fps']),'-force_key_frames','expr:eq(n,226)','-movflags','+faststart','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',str(out)]
 diagnostics=Diagnostics(out.parent/'diagnostics',cfg['width'],cfg['height'],cfg['fps']) if project.audio and not args.no_diagnostics else None
 process=subprocess.Popen(cmd,stdin=subprocess.PIPE);start=time.time()
 try:
  for f in range(cfg['frames']):
   canvas=project.render(f);array=canvas.array()[...,:3]
   process.stdin.write(np.ascontiguousarray(array).tobytes())
   if diagnostics:diagnostics.write(project)
   if f%12==0:print(f'Frame {f:03d}/{cfg["frames"]} · {time.time()-start:.1f}s',flush=True)
 finally:
  process.stdin.close()
  if diagnostics:diagnostics.close()
 if process.wait():raise RuntimeError('FFmpeg encoding failed')
 print(f'Wrote {out}',flush=True)

if __name__=='__main__':main()
