The stage-two revision is `revision.mp4`: 1920×1080, 24 fps, 240 frames, 10 seconds. Its audio is the supplied `brand_B_10s.wav` at the original position, speed and gain, encoded as stereo AAC. `reconstruction.mp4` is the unchanged frozen stage-one movie; reconstruction mode remains available in the shared renderer.

Render either mode from this folder, using the installed offline dependencies:

```bash
/usr/bin/python3 render.py --mode reconstruction --config project/config.json --output reconstruction.mp4
/usr/bin/python3 render.py --mode revision --config project/revision.json --output revision.mp4
```

A copy of `project/` and `render.py` is sufficient. Both commands also work with absolute paths from another working directory. No network, original reference movie, ONNX runtime, or external model is needed. Dependencies and asset provenance are in `project/DEPENDENCIES.md`.

Every revision render analyzes its configured audio file. The measured energy peaks are **A 0.90 s**, **B 2.61 s**, and **C 4.30 s**. Source anchors `[0,1.25,3.50,5.50,6.25,8,10]` map piecewise linearly to `[0,A,B,C,6.25,8,10]`. The tube uses the specified 30 ms attack / 180 ms release low-band envelope, with up to 12% extra cross-section thickness. Its centerline and other UI objects do not use that envelope. The blue cursor has its own clock delayed by 0.25 output seconds, including its entry and exit.

`project/revision.json` contains the six requested controls: `path_text`, `ui_gradient`, `cursor_delay_s`, `audio_path`, `pulse_amount`, and `head_overflow_px`. Relative audio paths resolve against the configuration file's directory. Change `audio_path` to remeasure events and regenerate actual animation. Text replacement applies to both colored lettering and the later monochrome rings. Hand-authored additional glyphs are in `project/revision_glyphs.json`; other new characters fall back to editable font outlines. The original reconstruction glyphs are retained.

The portrait uses the original continuous source clock, with premultiplied interpolation between adjacent supplied matte frames. Only its sliced reveal mask is adjusted to finish at C. From C to C+0.50 s, a six-frame smooth rise and six-frame smooth fall expose up to 36 pixels above the back window. One portrait image is drawn; the body remains clipped, and the original foreground glass crosses its shoulder/chin. The person is never scaled by audio.

Revision rendering also writes `audio_events.json`, `diagnostics/control_signals.csv`, and these 1920×1080, 240-frame diagnostic videos beside the selected output:

- `diagnostics/portrait_alpha.mp4`: actual placed portrait alpha after reveal and window/overflow union, before foreground occlusion.
- `diagnostics/portrait_checker.mp4`: that same isolated portrait over a checkerboard, for edge inspection.
- `diagnostics/head_overflow.mp4`: only the extra portrait alpha admitted outside the original back window; black outside the half-second excursion.

The original unwindowed soft mattes remain independently editable in `project/assets/portrait/`. `project/EDITING.md` describes mask equations, layer order, and the control columns. `edit_map.json` includes object locations and the output-to-portrait sample mapping. `diagnostics/audio_analysis.png` and `.svg` show the measured signal; the signal table is supporting evidence, not a substitute for viewing the movie.

Selected-frame previews and vector exports are available without changing either delivered movie:

```bash
/usr/bin/python3 render.py --mode revision --config project/revision.json --output previews --preview-frames 22,39,45,63,99,103,109,150,192,210
/usr/bin/python3 project/scripts/export_vectors.py --mode revision
/usr/bin/python3 project/scripts/plot_audio.py
```

The reconstruction retains the stage-one authored approximations of the reference's hands, architecture, paper illustration and cyclists. The supplied portrait is real live action, with a soft recurrent matte; no segmentation ground truth is supplied. Audio was analyzed with the specified numerical method, without claiming an unavailable native listening interface. The second low-frequency rise during the fully visible UI is small under the mandated full-track normalization; no extra beats or gain changes were introduced to exaggerate it.

`diagnostics/causal/shifted/` and `diagnostics/causal/high/` contain complete independent test renders and their configurations/events. The first uses the supplied PCM delayed by 6000 samples (0.125 s), with zero padding and the same ten-second duration. The second adds only smooth 8 kHz transients. These are test movies, separate from the delivered original-audio revision. Reproduce them and the pixel/audio checks with:

```bash
/usr/bin/python3 render.py --mode revision --config diagnostics/causal/shifted/config.json --output diagnostics/causal/shifted/revision.mp4 --no-diagnostics
/usr/bin/python3 render.py --mode revision --config diagnostics/causal/high/config.json --output diagnostics/causal/high/revision.mp4 --no-diagnostics
/usr/bin/python3 project/scripts/verify_revision.py
```

`diagnostics/verification.json` reports measured audio alignment, decoded tube widths, parameter-image differences and causal-render comparisons. `diagnostics/reconstruction_compatibility.json` records raw-frame checks against the frozen engineering project and the unchanged movie hash.

Top-level `portrait_checker.mp4` and `head_overflow.mp4` are identical convenience copies of the diagnostic movies. The original 43-frame stage-one matte previews and validation records are retained under `diagnostics/stage1/`.
