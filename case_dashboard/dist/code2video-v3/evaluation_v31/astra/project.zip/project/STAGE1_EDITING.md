The project is an offline Python/Cairo scene graph. All coordinates are in the 1920×1080 output canvas. `timeline.py` establishes layer order; the frame number is the animation clock. The normal render regenerates every graphic surface from paths and numeric seeds.

- `config.json`: output specification, shared Bézier centerlines, portrait placement, and encoder settings. `disabled_objects` can hide top-level groups named in `timeline.py`.
- `objects.json`: individual illustration transforms and entry times, six independent color-slice tracks, garden board counts, and three cyclist motion tracks.
- `glyphs.json`: hand-authored letter outlines. `GraphicScenes.bubble_text` bends their contours along the specified centerline intervals. The small paper ribbon has its own pointed terminal; the upper large ribbon has a separate monochrome reverse.
- `scenes_graphic.py`: printed cards, halftone ink, registration targets, optical controls, individual illustration shapes and paper folds. Icon geometry can also be opened in the exported `vector_library/*.svg` files. Rendering uses the Python geometry; after changing it, run `python3 project/scripts/export_vectors.py` to refresh those SVG exports.
- `scenes_portrait.py`: stepped aperture, translucent swept rings, procedural satin, color slices, orbit paths, and shaded spectral torus. The moving person remains a separate true-alpha layer. Foreground blades and glass provide independent occlusion.
- `scenes_collage.py`: independently drawn hands, pens, boats, stone stair treads and risers, hiker, and landscape ridge. The water and galaxy are seeded procedural textures. They contain no reference imagery.
- `nature.py`: individual shaded leaves, flowers, wooden boards, cloud density fields and articulated cyclists. Each bicycle wheel, crank and limb is redrawn at its animated pose.

The only sequential raster layers are the supplied portrait and its 43 RGBA matte derivatives. `portrait_mapping.json` maps output frames 108–150 to consecutive source indices 24–66. Changing the portrait interval requires rebuilding both the derivatives and diagnostics with `scripts/matte_portrait.py`; ordinary rendering uses the included derivatives directly.

`../edit_map.json` lists object IDs, source functions, frame mapping and occlusion relationships. `scripts/validate_delivery.py` checks encoded media, continuous portrait mapping, alpha properties and the duplicate final frame.
