"""Procedural cut-paper/painted hands, architecture, marine collage, and miniature landscape."""
import math,functools
import cv2,numpy as np
from .drawing import *
from .nature import leaf,flower,cloud_sprite

class Collage:
 def __init__(self,cfg):
  self.cfg=cfg;self.big=sample_curve(cfg['curves']['large'][:-1]+[[1040,267,963,293,918,334]]);self.small=sample_curve(cfg['curves']['small']);self.cache={}
 def ocean(self):
  if 'ocean' in self.cache:return self.cache['ocean']
  rng=np.random.default_rng(605);h,w=720,1100;yy,xx=np.mgrid[:h,:w].astype(np.float32);noise=np.zeros((h,w),np.float32)
  for sz,amp in [(4,.48),(12,.26),(32,.16),(100,.08),(320,.04)]:noise+=cv2.resize(rng.random((sz,sz)).astype(np.float32),(w,h),interpolation=cv2.INTER_CUBIC)*amp
  noise=np.clip(noise,0,1);caust=np.sin(xx*.11+noise*29)*np.cos(yy*.15+noise*17);caust=np.maximum(0,caust-.54)**2*.80
  ripples=np.sin(yy*.7+noise*42+np.sin(xx*.13)*3)*np.sin(xx*.55+noise*31)
  detail=cv2.resize(rng.random((370,520)).astype(np.float32),(w,h),interpolation=cv2.INTER_CUBIC)-.5
  n=np.clip((noise-.30)*2.4,0,1)
  tex=np.stack([.008+n*.04+caust*.6+detail*.025,.09+n*.30+caust+detail*.045+np.maximum(ripples,0)*.02,.15+n*.31+caust+detail*.045],axis=-1)
  a=np.uint8(np.clip(tex*255,0,255));self.cache['ocean']=a;return a
 def water(self,f):
  c=Canvas();m=Canvas();m.ellipse(786,592,181,203,'#ffffff');m.ellipse(1090,550,137,137,'#ffffff');m.line([(773,579),(959,738)],'#ffffff',145)
  tex=np.zeros((H,W,3),np.uint8);tex[220:940,420:1520]=self.ocean()
  # Subtle caustic movement is a generated shader offset, independent of the floating boats.
  tex=np.roll(tex,int(3*math.sin(f*.13)),axis=1);c.image(mask_texture(m,tex))
  c.image(self.galaxy(),970,429)
  return c
 def galaxy(self):
  if 'galaxy' in self.cache:return self.cache['galaxy']
  size=238;yy,xx=np.mgrid[:size,:size].astype(np.float32);x=xx-119;y=yy-119;r=np.hypot(x,y);a=np.arctan2(y,x);rng=np.random.default_rng(81)
  noise=np.zeros((size,size),np.float32)
  for n,amp in [(4,.46),(11,.25),(32,.15),(94,.09),(238,.05)]:noise+=cv2.resize(rng.random((n,n)).astype(np.float32),(size,size),interpolation=cv2.INTER_CUBIC)*amp
  arms=(.5+.5*np.sin(a*2.3-r*.05+noise*9))**4;nebula=np.clip((noise-.25)*2,0,1)*(.18+.82*arms)
  color=np.stack([.010+nebula*.06,.022+nebula*.52,.039+nebula*.64],axis=-1)
  for i in range(1900):
   px=int(rng.integers(1,size-1));py=int(rng.integers(1,size-1));v=rng.uniform(.08,.95)**2
   color[py,px]+=np.array([.77,.89,1])*v
   if v>.70:
    for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:color[py+dy,px+dx]+=np.array([.7,.8,1])*v*.12
  self.cache['galaxy']=np.dstack([np.uint8(np.clip(color*255,0,255)),np.uint8(np.clip((116.5-r),0,1)*255)])
  return self.cache['galaxy']
 def rings(self,f):
  c=Canvas()
  # The architecture is inset into the same two curves used by the preceding treatments.
  c.c.set_line_cap(0)
  c.line(poly_segment(self.big,.49,1),'#4fd8cd',88,gradient=((920,270,1335,725),[(0,'#7060cb'),(.3,'#477ece'),(.6,'#29ded4'),(1,'#a6d8af')]))
  stops=[(0,'#ffe000'),(.24,'#ffad00'),(.38,'#ff3c00'),(.53,'#ea00cd'),(.72,'#d224fa'),(.87,'#8b6bf3'),(1,'#6bf58c')]
  for j in range(220):
   u=j/220*.90;v=(j+1.7)/220*.90;col=tuple(np.interp(u/.90,[a for a,b in stops],[rgb(b)[ch] for a,b in stops]) for ch in range(3))
   c.line(poly_segment(self.small,u,v),col,88)
  c.c.set_line_cap(1)
  q,d=curve_at(self.small,.9);n=np.array([-d[1],d[0]]);c.shape([tuple(q-n*44),tuple(q+n*44),(917,849),'z'],gradient=((775,778,917,849),[(0,'#9395ef'),(1,'#7bf28c')]))
  c.ellipse(1020,546,44,44,'#ffe000')
  return c
 def stairs(self):
  if 'stairs' in self.cache:return self.cache['stairs']
  c=Canvas();cx,cy=1088,543;outer,inner=235,118
  # Layered stone sidewalls, concentric with the radial staircase.
  # Stone follows a shallow perspective ellipse; the front risers carry real depth.
  def q(r,t):return (cx+r*math.cos(t),cy+r*math.sin(t)*(.91 if math.sin(t)<0 else 1))
  for r,w,col in [(246,17,'#a99d86'),(238,7,'#d2c6b1'),(229,6,'#a69e91')]:
   pp=[q(r,a) for a in np.linspace(-2.25,2.10,150)];c.line(pp,col,w)
  count=27
  for i in range(count):
   a=-2.25+i/count*4.35;b=-2.25+(i+1)/count*4.35-.006
   depth=18*max(0,math.sin((a+b)/2))
   if depth:
    qa,qb=q(outer,a),q(outer,b)
    c.shape([qa,qb,(qb[0],qb[1]+depth),(qa[0],qa[1]+depth),'z'],gradient=((*qa,qa[0],qa[1]+depth),[(0,'#747982'),(1,'#34384c')]))
   p=[q(inner,a),q(outer,a),q(outer,b),q(inner,b),'z']
   v=.73+.09*math.cos(a+2)
   col=tuple(np.clip(np.array([.83,.81,.79])*v,0,1));bright=tuple(np.clip(np.array(col)+.15,0,1))
   c.shape(p,stroke='#686875',sw=.65,gradient=((*q(190,a),*q(190,b)),[(0,tuple(np.array(col)*.72)),(.18,tuple(np.array(col)*.97)),(.47,tuple(np.array(col)+.09)),(.91,col),(1,tuple(np.array(col)*.87))]))
   c.line([q(inner,a+.006),q(outer,a+.006)],'#a9a6a7',.7)
  ar=c.array();inside=ar[...,3]>200;noise=np.random.default_rng(48).normal(0,1.2,ar.shape[:2])[...,None];ar[...,:3]=np.uint8(np.clip(ar[...,:3].astype(float)+noise,0,255));self.cache['stairs']=ar;return ar
 def bridge(self):
  c=Canvas();a=np.array([752,578]);b=np.array([942,758]);d=(b-a)/np.linalg.norm(b-a);n=np.array([-d[1],d[0]])
  rng=np.random.default_rng(6)
  for i in range(100):
   u=rng.random();q=a*(1-u)+b*u+n*rng.choice([-1,1])*rng.uniform(39,53);r=rng.uniform(3,9)
   c.shape([(q[0]+r*math.cos(k*math.pi/3),q[1]+r*.7*math.sin(k*math.pi/3)) for k in range(6)]+['z'],mixcol('#858475','#dfd8b8',rng.random()),'#686d66',.5)
  for i in range(38):
   t=i/37;q=a*(1-t)+b*t;wide=47*min(1,.5+i*.15)
   p=[tuple(q-d*3.5-n*wide),tuple(q+d*3.5-n*wide),tuple(q+d*3.5+n*wide),tuple(q-d*3.5+n*wide),'z']
   c.shape(p,gradient=((*tuple(q-n*wide),*tuple(q+n*wide)),[(0,'#f0e1bf'),(.4,'#c5bda6'),(1,'#aaa896')]),stroke='#686d65',sw=.8)
   c.line([tuple(q-d*1.2-n*(wide-2)),tuple(q-d*.5+n*(wide-2))],'#b9ae93',.55)
  return c
 def boat(self,c,x,y,s,rot,wood=False):
  c.c.save();c.c.translate(x,y);c.c.rotate(rot);c.c.scale(s,s)
  p=[(0,-82),(-25,-67,-35,-24,-32,37),(-31,58,-24,74,-19,78),(22,78),(34,58,34,8,29,-25),(24,-54,14,-78,0,-82),'z']
  c.shape(p,'#57c5cc','#c0e7e1',2)
  c.shape([(0,-72),(-24,-49,-27,2,-24,66),(23,66),(28,6,23,-50,0,-72),'z'],gradient=((-25,0,25,0),[(0,'#395f5b'),(.16,'#a36250' if wood else '#c7c0a3'),(.55,'#a67a61' if wood else '#d0c7a6'),(1,'#557a72')]))
  for xx in [-17,-6,6,17]:c.line([(xx,-45),(xx,65)],'#8b8973',1.3)
  for yy in [-32,9,49]:
   c.rect(-26,yy,52,9,'#52bac6','#3a7f80',1)
   c.line([(-23,yy+2),(23,yy+2)],'#a8dfda',1)
  c.line([(3,-58),(3,47)],'#b8a989',2);c.line([(10,-50),(10,55)],'#7c7054',1)
  for xx,yy in [(-13,-17),(12,31),(-8,59)]:c.ellipse(xx,yy,3,1,'#716e5b')
  c.c.restore()
 def hand_left(self):
  if 'hand_left' in self.cache:return self.cache['hand_left']
  c=Canvas()
  hand=[(805,344),(753,340,701,352,665,366),(627,375,602,380,576,385),(553,380,534,391,528,408),(507,431,487,455,469,479),(455,496,463,510,478,519),(492,531,503,539,511,553),(523,576,533,591,546,594),(564,599,575,578,585,569),(606,556,631,546,650,520),(683,503,706,477,733,451),(767,424,790,404,807,396),(822,384,830,355,805,344),'z']
  c.shape(hand,gradient=((493,520,770,345),[(0,'#6a4637'),(.23,'#9a6c51'),(.52,'#b78565'),(.8,'#a57056'),(1,'#c58a65')]))
  # Palm volumes and knuckle ridges lie inside the traced anatomical silhouette.
  c.shape([(533,410),(541,389,574,395,595,400),(602,423,573,450,552,465),(530,469,514,455,514,442),(516,429,523,420,533,410),'z'],gradient=((531,405,558,465),[(0,'#bb8869'),(.45,'#987054'),(1,'#684535')]))
  c.shape([(486,466),(503,449,520,449,533,462),(548,479,530,491,516,499),(507,504,508,520,520,539),(496,530,475,511,473,498),(469,486,477,474,486,466),'z'],gradient=((478,462,534,533),[(0,'#b07d60'),(.45,'#926149'),(1,'#63432f')]))
  c.shape([(530,483),(542,469,569,474,574,491),(578,512,560,522,553,534),(552,553,568,567,553,585),(541,598,531,570,523,554),(513,537,511,503,530,483),'z'],gradient=((520,484,558,580),[(0,'#a87558'),(.4,'#704a38'),(.8,'#ba8464'),(1,'#886048')]))
  # Pen passes behind the thumb and the index pad.
  c.line([(537,592),(665,342)],'#0b1b22',14);c.line([(540,584),(667,340)],'#273b43',3)
  c.shape([(531,603),(534,580),(545,585),'z'],'#cfb08b');c.shape([(531,603),(535,591),(539,596),'z'],'#242d30')
  thumb=[(730,391),(701,388,684,410,663,432),(639,450,610,476,593,499),(576,519,560,536,559,554),(556,568,563,580,578,576),(594,576,604,565,610,550),(627,533,645,525,665,513),(692,495,709,477,728,455),(746,435,750,407,730,391),'z']
  c.shape(thumb,gradient=((581,537,732,402),[(0,'#c99672'),(.2,'#b38162'),(.48,'#936344'),(.7,'#bb8665'),(1,'#be8968')]))
  c.shape([(564,554),(566,543,576,536,586,538),(598,540,597,549,589,559),(578,568,565,570,564,554),'z'],gradient=((565,540,589,566),[(0,'#cba387'),(1,'#b08368')]),stroke='#9d7256',sw=.7)
  for p in [[(488,486),(501,483),(513,487)],[(493,494),(508,496)],[(522,432),(538,431),(547,439)],[(532,462),(547,459),(556,467)],[(602,494),(618,499),(622,508)],[(669,424),(681,431),(687,444)],[(563,528),(572,533)],[(552,565),(556,575)]]:c.line(p,'#714b3c',1.1)
  # Fine neutral skin grain is attached to the hand, not the source footage.
  a=c.array();blur=cv2.GaussianBlur(a[...,:3],(0,0),2.5);inside=cv2.erode(a[...,3],np.ones((9,9),np.uint8))>245;a[inside,:3]=np.uint8(a[inside,:3]*.32+blur[inside]*.68);dist=cv2.distanceTransform(a[...,3],cv2.DIST_L2,3);shade=(.78+.22*np.sqrt(np.clip(dist/19,0,1)))[...,None];a[...,:3]=np.uint8(a[...,:3]*shade);rng=np.random.default_rng(73);noise=rng.normal(0,2.3,a.shape[:2])[...,None];a[...,:3]=np.uint8(np.clip(a[...,:3].astype(float)+noise,0,255));self.cache['hand_left']=a;return a
 def hand_right(self):
  if 'hand_right' in self.cache:return self.cache['hand_right']
  c=Canvas()
  p=[(875,744),(919,739,963,753,1010,753),(1089,752,1141,707,1175,680),(1202,660,1228,653,1249,644),(1265,630,1278,609,1290,612),(1305,611,1310,631,1301,650),(1331,617,1341,628,1337,650),(1339,677,1320,701,1318,729),(1315,768,1304,804,1283,830),(1274,845,1254,846,1244,842),(1168,848,1101,853,1032,845),(976,840,933,817,904,790),(890,775,882,760,875,744),'z']
  c.shape(p,gradient=((1015,829,1285,644),[(0,'#3f2725'),(.30,'#6c4540'),(.66,'#65443f'),(1,'#8e6251')]))
  c.shape([(984,801),(1050,814,1110,808,1152,781),(1198,746,1200,693,1248,665),(1268,656,1278,665,1267,682),(1233,733,1252,790,1219,815),(1160,843,1044,839,984,801),'z'],gradient=((1150,660,1120,835),[(0,'#8b5e4f'),(.5,'#78564e'),(1,'#3d2928')]))
  for i in range(3):
   xx=1276+i*15
   c.line([(xx-33,749+i*8),(xx-10,702),(xx+1,658+i*8)],['#785448','#855b4d','#79554d'][i],18-i*2)
   c.line([(xx-28,748+i*8),(xx-4,699),(xx+5,657+i*8)],'#a16f5c',2)
  for i in range(5):c.line([(1197+i*9,757-i*6),(1210+i*8,765-i*6),(1218+i*8,776-i*6)],'#4f3532',1)
  a=c.array();blur=cv2.GaussianBlur(a[...,:3],(0,0),2.5);inside=cv2.erode(a[...,3],np.ones((9,9),np.uint8))>245;a[inside,:3]=np.uint8(a[inside,:3]*.32+blur[inside]*.68);dist=cv2.distanceTransform(a[...,3],cv2.DIST_L2,3);shade=(.74+.26*np.sqrt(np.clip(dist/20,0,1)))[...,None];a[...,:3]=np.uint8(a[...,:3]*shade);noise=np.random.default_rng(9).normal(0,1.7,a.shape[:2])[...,None];a[...,:3]=np.uint8(np.clip(a[...,:3]+noise,0,255));self.cache['hand_right']=a;return a
 def pencil(self,c,f):
  a=np.array([1188,872]);b=np.array([1326,594]);d=(b-a)/np.linalg.norm(b-a);n=np.array([-d[1],d[0]])
  c.shape([tuple(a-n*6),tuple(a+n*6),tuple(b+n*5),tuple(b-n*5),'z'],gradient=((*tuple(a-n*6),*tuple(a+n*6)),[(0,'#967016'),(.3,'#f8c426'),(.6,'#e8a30c'),(1,'#8b6419')]))
  c.line([tuple(a-n*3),tuple(b-n*3)],'#ffdc62',2)
  tip=b+d*23;c.shape([tuple(b-n*5),tuple(b+n*5),tuple(tip),'z'],'#d9bd91');c.shape([tuple(tip-d*8-n*2),tuple(tip-d*8+n*2),tuple(tip),'z'],'#343c37')
  c.line([tuple(a-d*6),tuple(a+d*8)],'#bdae66',12);c.line([tuple(a-d*17),tuple(a-d*7)],'#e37aa6',12)
 def tentacle(self,c,f):
  p=[(740,457),(794,471,840,450,822,410),(812,388,791,359,807,343),(819,330,845,343,837,355),(831,366,816,356,822,350)]
  c.line(p,'#67202c',37);c.line(p,'#a04f58',28);c.line(p,'#c2737c',12)
  pts=sample_curve(p,180)
  for i in range(0,len(pts),7):
   q,d=curve_at(pts,i/(len(pts)-1));n=np.array([-d[1],d[0]])
   for side in [-1,1]:
    pos=q+n*side*9;r=4.3*(1-i/len(pts)*.6)
    c.ellipse(*pos,r,r,'#efb2ab','#8d404c',.8);c.ellipse(*pos,r*.45,r*.40,'#a7535c')
 def explorer(self,c,x=1262,y=225):
  c.c.save();c.c.translate(x,y)
  c.ellipse(19,-4,36,44,'#62544a','#342d2b',2,angle=-.15)
  for xx in [7,25]:c.line([(xx,-40),(xx+14,28)],'#332f2b',4)
  c.shape([(-7,-44),(11,-35),(18,-1),(3,20),(-18,8),(-25,-24),'z'],gradient=((-20,-40,20,10),[(0,'#9d4a4d'),(1,'#562b34')]))
  c.line([(-9,10),(-40,-4),(-76,-11)],'#243e3c',20);c.line([(-8,15),(-30,18),(-50,-7)],'#344542',17)
  c.line([(-76,-11),(-84,-20)],'#c1a26d',11);c.line([(-50,-7),(-60,-17)],'#b89c76',10)
  c.line([(-17,-31),(-28,-46),(-21,-74)],'#ae6849',11)
  c.line([(-17,-37),(-4,-47),(-13,-68)],'#bb7851',10)
  c.ellipse(-9,-67,14,17,'#956347',angle=-.15);c.ellipse(-7,-78,19,11,'#17323b',angle=-.1)
  c.rect(-31,-81,22,10,'#1c2226',r=2);c.line([(-27,-87),(-25,-74)],'#21282a',7);c.line([(-16,-87),(-14,-74)],'#202528',7)
  c.c.restore()
 def ridge(self,c,f):
  rng=np.random.default_rng(938)
  c.line([(1087+math.cos(a)*321,542+math.sin(a)*321) for a in np.linspace(-2.1,.24,150)],'#387c32',19)
  for i in range(540):
   a=rng.uniform(-2.1,.24);r=rng.uniform(309,335);x=1087+math.cos(a)*r;y=542+math.sin(a)*r
   leaf(c,x,y,rng.uniform(1.0,2.5),rng.uniform(3,8),a+math.pi/2+rng.uniform(-.3,.3),mixcol('#225c27','#a0cc3d',rng.random()))
  for i in range(100):
   a=rng.uniform(-1.9,.08);r=rng.uniform(329,349);x=1087+math.cos(a)*r;y=542+math.sin(a)*r
   length=rng.uniform(10,27);c.line([(x,y),(x+math.cos(a)*length,y+math.sin(a)*length)],'#829734',.8)
   flower(c,x+math.cos(a)*length,y+math.sin(a)*length,rng.uniform(2,5),rng.choice(['#f4c52c','#ffdf40','#c0dcfa','#b6bcf4']),rng.random()*6)
 def scene(self,f):
  c=Canvas()
  if not 144<=f<=200:return c
  # Cool atmospheric shadow links separately editable components without a rectangular image background.
  halo=Canvas();halo.ellipse(1030,560,450,320,'#b7d8e5');a=halo.array();a=cv2.GaussianBlur(a,(0,0),38);c.image(a,alpha=.08*(1-ease((f-187)/10)))
  body=Canvas();body.image(self.water(f));body.image(self.rings(f));body.image(self.hand_right());body.image(self.stairs());body.image(self.bridge())
  self.pencil(body,f)
  self.boat(body,858+3*math.sin(f*.13),514+2*math.cos(f*.09),.78,.78+.03*math.sin(f*.11),True)
  self.boat(body,919+2*math.cos(f*.12),575+4*math.sin(f*.1),.91,.09+.04*math.sin(f*.08))
  self.ridge(body,f);self.explorer(body)
  c.image(body,alpha=1-ease((f-188)/12))
  c.image(self.hand_left(),x=1.5*math.sin(f*.14),y=1.3*math.cos(f*.1),alpha=1-ease((f-181)/10))
  top=Canvas();self.tentacle(top,f);c.image(top,alpha=1-ease((f-180)/9))
  for i,(x,y,s) in enumerate([(718,39,1.0),(1128,410,.87),(516,674,.80),(689,722,.49)]):
   c.image(cloud_sprite(i),x+math.sin(f*.04+i)*12,y+math.cos(f*.05+i)*3,s,alpha=1-ease((f-184-i)/10))
  a=c.array()
  if f<161:
   yy,xx=np.mgrid[:H,:W];row=np.clip(((yy-132)//133).astype(int),0,7);offset=np.array([50,-30,0,60,-60,0,80,0])[row]
   # Spatially advancing reveal, synchronized with the departing portrait slices.
   edge=490+(f-146)*74+offset
   mask=np.clip((edge-xx)/6+.5,0,1)
   a[...,3]=np.uint8(a[...,3]*mask)
  return a
