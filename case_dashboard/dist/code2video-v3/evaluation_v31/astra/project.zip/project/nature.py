"""Editable plants, wooden paths, cloud volumes, and articulated bicycle actors."""
import math,functools
import cv2,numpy as np
from .drawing import *

def leaf(c,x,y,rx,ry,angle,col='#72d722',light=True):
 # A shaded succulent leaf with a narrow soft highlight along its upper-left ridge.
 if light:
  base=np.array(rgb(col));hi=np.clip(base*1.17+.13,0,1);dark=base*.81
  c.ellipse(x+1.8,y+2.5,rx*.95,ry*.98,tuple(dark*.84),angle=angle)
  c.ellipse(x,y,rx,ry,gradient=((x-rx*.48,y-ry*.45,1,x,y,max(rx,ry)*1.18),[(0,tuple(hi)),(.40,tuple(base)),(1,tuple(dark))],True),angle=angle)
 else:c.ellipse(x,y,rx,ry,col,angle=angle)

def flower(c,x,y,size=18,col='#ec28b6',rot=0,petals=6):
 c.ellipse(x+2,y+4,size*.85,size*.6,'#509719')
 for i in range(petals):
  a=rot+i*math.pi*2/petals;px=x+math.cos(a)*size*.65;py=y+math.sin(a)*size*.65
  base=np.array(rgb(col));hi=tuple(np.clip(base+.15,0,1))
  c.ellipse(px,py,size*.48,size*.27,gradient=((px-3,py-3,0,px,py,size*.55),[(0,hi),(.6,col),(1,tuple(base*.8))],True),angle=a)
 c.ellipse(x,y,size*.30,size*.28,gradient=((x-2,y-3,1,x,y,size*.4),[(0,'#ffeb77'),(.6,'#edc452'),(1,'#b39a30')],True))

@functools.lru_cache(maxsize=16)
def cloud_sprite(seed=0,w=320,h=180):
 rng=np.random.default_rng(seed);yy,xx=np.mgrid[:h,:w].astype(np.float32)
 density=np.zeros((h,w),np.float32)
 for i in range(50):
  x=rng.uniform(w*.15,w*.87);y=h*.52+rng.normal(0,h*.13);r=rng.uniform(9,31)
  density+=rng.uniform(.25,.9)*np.exp(-(((xx-x)/r)**2+((yy-y)/(r*.85))**2)*1.7)
 noise=np.zeros_like(density)
 for scale,amp in [(5,.10),(12,.09),(32,.06),(90,.045)]:noise+=cv2.resize(rng.random((max(2,h//scale),max(2,w//scale))).astype(np.float32),(w,h),interpolation=cv2.INTER_CUBIC)*amp
 density+=noise-.18+.4*np.exp(-(((xx-w*.5)/(w*.30))**2+((yy-h*.55)/(h*.20))**2))
 al=np.clip((density-.10)*4,0,1)
 blurred=cv2.GaussianBlur(density,(0,0),3)
 gy,gx=np.gradient(blurred);normal=np.clip(-gx*1.5-gy*2,-.15,.14)
 shade=np.clip(.96+normal*.85-yy/h*.065+noise*.04,.80,1)
 rgba=np.dstack([np.uint8(shade*255),np.uint8(np.clip(shade+.003,0,1)*255),np.uint8(np.clip(shade+.01,0,1)*255),np.uint8(al*255)])
 return rgba

class Garden:
 def __init__(self,cfg):
  self.cfg=cfg;self.objects=__import__('json').loads((ROOT/'objects.json').read_text());self.paths={k:sample_curve(v) for k,v in cfg['curves'].items()};self.data={}
  for j,name in enumerate(['small','large']):
   rng=np.random.default_rng(self.objects['garden']['seed_'+name]);pts=self.paths[name]
   plants=[]
   # Three rows on each side; each planted form remains independently parameterized.
   for side in [-1,1]:
    for row in range(3):
     for i in range(230 if name=='large' else 180):
      u=(i+rng.random())/(230 if name=='large' else 180);offset=side*(35+row*11+rng.uniform(-6,8));plants.append([u,offset,rng.uniform(5.5,10),rng.uniform(11,21),rng.uniform(-.8,.8),rng.uniform(.75,1.1)])
   plants.sort(key=lambda p:abs(p[1]),reverse=True)
   flowers=[]
   for i in range(48 if name=='large' else 37):flowers.append([rng.uniform(.01,.98),rng.choice([-1,1])*rng.uniform(45,69),rng.uniform(12,23),int(rng.integers(0,6)),rng.uniform(0,6.28)])
   self.data[name]=(plants,flowers)
 def active(self,name,f):
  if name=='small':return float(np.interp(f,[202,204,208,212,216,218,220],[0,.02,.22,.48,.76,.93,1])),ease((f-175)/17)
  return float(np.interp(f,[204,208,212,216,220,222,224,225],[0,.20,.34,.50,.72,.90,.992,1])),ease((f-184)/17)
 def path_layer(self,f):
  c=Canvas();cols=['#f22aab','#af70fa','#32bfee','#ff942a','#ed2e43','#be8af0']
  for name in ['small','large']:
   pts=self.paths[name];lo,hi=self.active(name,f)
   if hi<=lo+.001:continue
   c.c.set_line_cap(0);c.line(poly_segment(pts,lo,hi),'#3d8a1b',113)
   c.line([(x+4,y+10) for x,y in poly_segment(pts,lo,hi)],'#52ab19',106);c.c.set_line_cap(1)
   plants,flowers=self.data[name]
   for u,off,rx,ry,rot,v in plants:
    if not lo<=u<=hi:continue
    q,d=curve_at(pts,u);n=np.array([-d[1],d[0]])
    g=min(1,(hi-u)*35,(u-lo)*35+.3);p=q+n*off
    a=math.atan2(n[1],n[0])-math.pi/2+rot
    # A small oscillation is assigned to every leaf, rather than moving a flattened garden image.
    a+=.07*math.sin(f*.17+u*40+off)
    base=np.array(rgb(self.objects['garden']['leaf_color']))*v;base=np.clip(base,0,1)
    leaf(c,*p,rx*g,ry*g,a,tuple(base))
   # Dense planted end caps conceal the round tube profile, and advance with the wipe.
   for endu in [lo,hi]:
    q,d=curve_at(pts,endu);rngcap=np.random.default_rng(71 if name=='small' else 83)
    shrink=min(1,(hi-lo)*25)
    for jj in range(80):
     theta=rngcap.uniform(0,math.pi*2);rad=math.sqrt(rngcap.random())*43*shrink
     xx=q[0]+math.cos(theta)*rad;yy=q[1]+math.sin(theta)*rad
     leaf(c,xx,yy,rngcap.uniform(5,10)*shrink,rngcap.uniform(10,20)*shrink,theta,'#79df24')
   # Individual transverse oak planks and their beveled end grain.
   count=self.objects['garden']['board_count_'+name]
   for i in range(count):
    u=(i+.5)/count
    if not lo<=u<=hi:continue
    q,d=curve_at(pts,u);n=np.array([-d[1],d[0]]);half=11.4 if name=='large' else 11.3
    wid=self.objects['garden']['board_half_width']+2*math.sin(i*1.9)
    p=[tuple(q-d*half-n*wid),tuple(q+d*half-n*wid),tuple(q+d*(half+1)+n*wid),tuple(q-d*(half+1)+n*wid),'z']
    edge=[tuple(q-d*half+n*wid),tuple(q+d*half+n*wid),tuple(q+d*half+n*(wid+5)+[0,4]),tuple(q-d*half+n*(wid+5)+[0,4]),'z']
    c.shape(edge,'#864018')
    light=mixcol('#df8e4a','#f6ad6a',(.5+.5*math.sin(i*5.3)))
    c.shape(p,stroke='#9e4d20',sw=.7,gradient=((*(q-n*wid),*(q+n*wid)),[(0,'#f7bf86'),(.18,light),(.66,'#c5763c'),(1,'#efaa69')]))
    for g in [-8,-5.5,-3,-.3,2.5,4.4,7,9]:
     p1=q+d*g-n*(wid-3);p2=q+d*(g+.9*math.sin(i))+n*(wid-3)
     c.line([tuple(p1),tuple(p2)],'#b36e35' if g>0 else '#ebad6c',.6)
    if i%3==0:
     for side in [-1,1]:
      pp=q+n*wid*.77*side;c.ellipse(*pp,1,1,'#795833')
   # A few plants overlap the edges of the boards for a rounded, irregular silhouette.
   for j,(u,off,rx,ry,rot,v) in enumerate(plants):
    if j%11 or not lo<=u<=hi:continue
    q,d=curve_at(pts,u);n=np.array([-d[1],d[0]]);p=q+n*np.sign(off)*34
    leaf(c,*p,rx*.65,ry*.72,math.atan2(n[1],n[0])-math.pi/2+rot,'#76e624')
   for u,off,size,co,rot in flowers:
    if not lo<=u<=hi:continue
    q,d=curve_at(pts,u);p=q+np.array([-d[1],d[0]])*off
    g=min(1,(hi-u)*20+.2,(u-lo)*25+.2);flower(c,*p,size*g,cols[co],rot+.05*math.sin(f*.14+u*17))
  # Leaves shed during the growth and exit; each particle follows a small ballistic arc.
  rng=np.random.default_rng(938)
  for i in range(70):
   name='large' if i%2 else 'small';pts=self.paths[name];u=rng.random();q,d=curve_at(pts,u);n=np.array([-d[1],d[0]])
   lo,hi=self.active(name,f)
   if not lo-.05<u<hi+.02 or f>=224:continue
   drift=rng.uniform(65,110);s=rng.choice([-1,1]);phase=(f*.04+i*.51)%1
   pos=q+n*s*(drift+phase*24)+np.array([math.sin(i)*phase*15,phase*30])
   leaf(c,*pos,3.2,7.5,rng.uniform(0,6.28)+f*.06,'#76cb27')
  return c
 def rider(self,c,x,y,angle=0,scale=1,phase=0,wave=True):
  if scale<=.0001:return
  c.c.save();c.c.translate(x,y);c.c.rotate(angle);c.c.scale(scale,scale)
  # The bicycle has separate spinning spokes, frame, crank, pedals and tyres.
  for wx in [-62,64]:
   c.ellipse(wx,0,28,28,None,'#211145',7)
   c.ellipse(wx,0,24,24,None,'#746d8b',1)
   for j in range(12):
    a=j*math.pi/6+phase;c.line([(wx,0),(wx+24*math.cos(a),24*math.sin(a))],'#94959a',.7)
   c.ellipse(wx,0,4,4,'#333546')
  for p in [[(-62,0),(-29,-48),(6,0),(-62,0)],[(-29,-48),(49,-43),(6,0)],[(-29,-48),(-33,-60)],[(49,-43),(64,0)],[(49,-43),(42,-65),(33,-70)]]:
   c.line(p,'#231442',5);c.line([(a-1,b-1) for a,b in p],'#c8c3d0',1.4)
  c.line([(-48,-60),(-22,-60)],'#1e133a',7);c.line([(33,-70),(53,-69)],'#141522',4)
  c.ellipse(6,0,7,7,'#998da6','#211440',1)
  pedal=(6+16*math.cos(phase),16*math.sin(phase));c.line([(6,0),pedal],'#d1ccd5',3);c.line([(pedal[0]-6,pedal[1]),(pedal[0]+6,pedal[1])],'#151825',3)
  # Articulated legs and white trainers.
  knee=(-17+10*math.sin(phase),-34+10*math.cos(phase));foot=(pedal[0]-4,pedal[1]-5)
  c.line([(-11,-82),(-35,-55),(-22,-9)],'#3a1d9a',20);c.line([(-16,-82),knee,foot],'#542ac5',22)
  c.line([(-16,-79),(knee[0]-3,knee[1]-3),(foot[0]-3,foot[1]-4)],'#714bdd',7)
  c.ellipse(-21,-5,17,7,'#e8e7ee',angle=-.12);c.ellipse(foot[0]+7,foot[1]+1,18,8,'#f6f2f1',angle=-.12)
  # Puffy orange-red jacket and raised sleeve.
  body=[(-31,-132),(0,-146,29,-133,32,-112),(39,-92,25,-75,14,-73),(-25,-69),(-36,-84,-33,-105,-31,-132),'z']
  c.shape(body,stroke='#b52f23',sw=1,gradient=((-34,-131,35,-74),[(0,'#ff5f30'),(.6,'#f13c24'),(1,'#cd2823')]))
  c.line([(-22,-124),(-40,-101),(-58,-81)],'#ed3c2b',23)
  c.line([(-24,-127),(-40,-105),(-59,-84)],'#ff643d',9)
  c.ellipse(-62,-76,12,10,'#c9a5fa',angle=-.35)
  c.line([(-63,-73),(-57,-66)],'#b58bec',5)
  if wave:
   arm=[(25,-124),(49,-155),(73,-202)]
  else:arm=[(24,-125),(44,-98),(47,-76)]
  c.line(arm,'#d82f24',27);c.line([(a-4,b-3) for a,b in arm],'#f44a2d',17)
  # Seeded embroidery marks follow the coat and sleeve surfaces.
  rng=np.random.default_rng(203)
  for i in range(65):
   bx=rng.uniform(-27,26);by=rng.uniform(-126,-79);c.ellipse(bx,by,1.8,2.7,'#ff8750',angle=rng.uniform(-2,2))
  for j in range(18):
   u=j/18;p=np.array(arm[0])*(1-u)+np.array(arm[-1])*u;c.ellipse(p[0]+3*math.sin(j*4),p[1],2,3,'#ff8050',angle=.4)
  hx,hy=arm[-1];c.ellipse(hx,hy-9,12,16,gradient=((hx-5,hy-20,1,hx,hy,26),[(0,'#eed6ff'),(1,'#a977e1')],True),angle=.25)
  if wave:
   for i in range(4):c.line([(hx-9+i*6,hy-16),(hx-10+i*7,hy-32-(i in (1,2))*5)],'#cbb0f8',7)
   c.line([(hx-9,hy-8),(hx-20,hy-20)],'#c3a2f4',7)
  # Lavender character with big ears, open smile, a tuft, and a small cap.
  c.ellipse(-2,-148,29,17,'#ff542d')
  c.ellipse(-8,-163,27,27,gradient=((-20,-179,1,-4,-160,37),[(0,'#f3dcff'),(.5,'#d5b3ff'),(1,'#a276e1')],True))
  for ex in [-34,18]:c.ellipse(ex,-162,10,11,'#d6b4f6')
  c.ellipse(-12,-168,2.8,3.3,'#2c1750');c.ellipse(1,-169,2.8,3.3,'#2c1750')
  c.ellipse(-5,-159,5,3,'#c091e9')
  c.shape([(-16,-155),(8,-157),(7,-135,-14,-131,-16,-155),'z'],'#29174d')
  c.shape([(-13,-154),(5,-155),(4,-148),(-12,-147),'z'],'#ffffff');c.ellipse(-2,-140,6,4,'#f060b1')
  c.rect(-18,-197,24,16,'#342270',r=3);c.ellipse(-5,-181,20,5,'#5c3a9e',angle=-.12)
  c.rect(-9,-194,6,6,'#8e68d2',r=1)
  c.c.restore()
 def riders(self,f):
  c=Canvas()
  if not 179<=f<=223:return c
  defs=self.objects['garden']['riders'];tracks=[(o['path'],float(np.interp(f,o['keyframes'],o['positions'])),o['scale'],o['wave']) for o in defs]
  for i,(name,u,scale,wave) in enumerate(tracks):
   start,stop=defs[i]['frames']
   if f<start or f>stop:continue
   lo,hi=self.active(name,f)
   if not lo-.08<=u<=hi+.10:continue
   q,d=curve_at(self.paths[name],u)
   direction=-d if i<2 else d;n=np.array([-direction[1],direction[0]])
   pos=q-n*29;angle=math.atan2(direction[1],direction[0])
   grow=ease((f-start)/4)*(1-ease((f-stop+2)/3))
   self.rider(c,*pos,angle,scale*grow,f*.43+i,wave)
  return c
