This is the stage-one silent reconstruction: 1920×1080, 24 fps, 240 frames, 10 seconds, H.264/yuv420p, with no audio stream. All six treatments are reconstructed from editable graphics. The supplied live-action portrait is the only video layer; its background is removed with a recurrent soft alpha matte.

To render after copying this entire submission folder into a clean directory, with the dependencies in `project/DEPENDENCIES.md` available:

```bash
cd /path/to/copied/submission
/usr/bin/python3 render.py --mode reconstruction --config project/config.json --output reconstruction.mp4
```

The renderer also works from an unrelated current directory:

```bash
/usr/bin/python3 /path/to/copied/submission/render.py \
  --mode reconstruction \
  --config /path/to/copied/submission/project/config.json \
  --output /path/to/output/reconstruction.mp4
```

The saved portrait RGBA derivatives are included, so normal rendering needs neither the ONNX model nor the original reference. Rendering takes a few minutes on the provided CPU environment. The process is deterministic and requires no network access.

The project entry is `project/timeline.py`; `project/EDITING.md` explains the editable layers and asset workflow. Edit the two Bézier centerlines and portrait placement in `project/config.json`, sticker transforms and color-slice keyframes in `project/objects.json`, and custom letter contours in `project/glyphs.json`. The remaining surfaces, shapes, and articulated actors have named functions in `scenes_graphic.py`, `scenes_portrait.py`, `scenes_collage.py`, and `nature.py`. Independent leaves, flowers, boards, clouds, boats, controls, and riders are generated as separate editable instances. `edit_map.json` records object IDs, source entries, the full portrait frame mapping, and mask/occlusion relationships. `project/vector_library/` provides standalone editable SVG versions of the illustration stickers and curved letter outlines.

Portrait output frames 108–150 use successive source indices 24–66, beginning at source PTS 1.001 seconds (the sample at the requested 1.0-second start). The face is approximately 200 pixels wide. Its moving hair, face, and shirt retain a true soft matte; the logo aperture and foreground glass/color strips apply additional occlusion. `diagnostics/portrait_alpha.mp4` and `diagnostics/portrait_checker.mp4` cover exactly these 43 source frames, at 960×540 and 24 fps. The optional matte rebuilding command is:

```bash
/usr/bin/python3 project/scripts/matte_portrait.py \
  --model /tool_assets/rvm_mobilenetv3_fp32.onnx
```

To inspect selected frames without encoding a movie:

```bash
/usr/bin/python3 render.py --mode reconstruction --config project/config.json \
  --output previews --preview-frames 24,56,80,112,128,168,200,216,224
```

The original reference frames were used only for visual inspection, timing, and drawing guidance. No reference frames, reference clips, or reference-derived raster layers are used by this project. Hands, architecture, and cyclists are authored graphical approximations. This reconstruction is not commissioned or endorsed by the depicted brand. No audio or later-stage revision assumptions are included.
