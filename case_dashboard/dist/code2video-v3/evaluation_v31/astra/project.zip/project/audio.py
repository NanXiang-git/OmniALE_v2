"""Offline, reproducible centered-STFT analysis and audio-derived animation clocks.

No cached event times participate in rendering: changing audio_path reanalyses audio.
The PCM supplied to the muxer is never resampled or filtered by this module.
"""
from pathlib import Path
import hashlib
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly, windows


class AudioDrive:
    sample_rate = 48000
    n_fft = 2048
    hop = 480
    source_anchors = np.array([0, 1.25, 3.50, 5.50, 6.25, 8, 10.])

    def __init__(self, path):
        self.path = Path(path).resolve()
        sr, pcm = wavfile.read(self.path)
        if np.issubdtype(pcm.dtype, np.integer):
            if pcm.dtype == np.uint8:
                x = (pcm.astype(np.float64) - 128) / 128
            else:
                x = pcm.astype(np.float64) / (2 ** (pcm.dtype.itemsize * 8 - 1))
        else:
            x = pcm.astype(np.float64)
        self.input_sample_rate = sr
        self.input_samples = len(x)
        self.input_peak = float(np.max(np.abs(x)))
        self.input_rms = float(np.sqrt(np.mean(x*x)))
        if x.ndim == 2:
            x = x.mean(axis=1)
        if sr != self.sample_rate:
            from math import gcd
            g = gcd(sr, self.sample_rate)
            x = resample_poly(x, self.sample_rate//g, sr//g)
        padded = np.pad(x, (self.n_fft//2, self.n_fft//2), mode='constant')
        frames = np.lib.stride_tricks.sliding_window_view(padded, self.n_fft)[::self.hop]
        z = np.fft.rfft(frames * windows.hann(self.n_fft, sym=False), axis=1)
        hz = np.fft.rfftfreq(self.n_fft, 1/self.sample_rate)
        self.times = np.arange(len(z)) * self.hop / self.sample_rate
        self.low = np.sqrt(np.mean(np.abs(z[:, (hz >= 40) & (hz <= 250)])**2, axis=1))
        self.mid = np.sqrt(np.mean(np.abs(z[:, (hz >= 250) & (hz <= 2500)])**2, axis=1))
        self.events = {}
        for label, bounds, energy, source, action in [
            ('A', (.65, 1.25), self.low, 1.25, 'Printed grid, swatches and ink assembly reaches source 1.25 s'),
            ('B', (2.25, 2.90), self.low, 3.50, 'Curved CREATE ON ribbons and individual folded stickers reach source 3.50 s'),
            ('C', (3.95, 4.65), self.mid, 5.50, 'Continuous portrait finishes its local row reveal, with foreground glass retained'),
        ]:
            valid = np.flatnonzero((self.times >= bounds[0]-1e-10) & (self.times <= bounds[1]+1e-10))
            idx = int(valid[np.argmax(energy[valid])])
            self.events[label] = dict(time_s=float(self.times[idx]), stft_index=idx,
                                      band_hz=[40,250] if label != 'C' else [250,2500],
                                      search_window_s=list(bounds), energy=float(energy[idx]),
                                      source_time_s=source, visual_action=action,
                                      nearest_output_frame=int(np.floor(self.times[idx]*24+.5)),
                                      first_output_frame_at_or_after_event=int(np.ceil(self.times[idx]*24-1e-10)))
        self.output_anchors = np.array([0, *[self.events[k]['time_s'] for k in 'ABC'], 6.25, 8, 10.])
        self.normalized = self.low / max(float(self.low.max()), 1e-15)
        self.envelope = np.zeros_like(self.normalized)
        previous = 0.
        for i, target in enumerate(self.normalized):
            tau = .030 if target > previous else .180
            a = np.exp(-(self.hop/self.sample_rate)/tau)
            previous = a*previous + (1-a)*target
            self.envelope[i] = previous

    def source_time(self, output_time):
        return float(np.interp(output_time, self.output_anchors, self.source_anchors))

    def pulse(self, output_time):
        return float(np.interp(output_time, self.times, self.envelope))

    def overflow(self, output_time, amount):
        """Six output-frame smoothstep attack, six-frame smoothstep release."""
        u = (output_time-self.events['C']['time_s']) * 24
        if not 0 < u < 12:
            return 0.
        q = u/6 if u <= 6 else (12-u)/6
        return float(amount*q*q*(3-2*q))

    def report(self):
        return dict(
            algorithm=dict(mono='arithmetic mean of channels', sample_rate_hz=48000,
                           fft_size=2048, window='periodic Hann', hop_samples=480,
                           centered=True, boundary='zero padding by 1024 samples on both sides',
                           spectrum='unscaled numpy rfft',
                           energy='sqrt(mean(abs(STFT[frequency bins in inclusive band])**2))',
                           event='maximum band energy in inclusive time window; earliest tie',
                           normalization='low band divided by its maximum over the entire track',
                           envelope='y=a*y_previous+(1-a)*x; a=exp(-0.010/tau); attack tau=.030 s when x>y_previous, release tau=.180 s otherwise',
                           sampling='linear interpolation of the 100 Hz envelope at output frame PTS'),
            events=self.events, source_anchors_s=self.source_anchors.tolist(),
            output_anchors_s=self.output_anchors.tolist(),
            audio=dict(path=str(self.path.name), sha256=hashlib.sha256(self.path.read_bytes()).hexdigest(),
                       sample_rate_hz=self.input_sample_rate, samples=self.input_samples,
                       peak=self.input_peak, rms=self.input_rms,
                       mux='original file, t=0, rate=1, gain=1; AAC encoding only'))
