#!/usr/bin/env python3
"""Plot the measured STFT energies, envelope, windows and event centers offline."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import cairo,numpy as np
from scipy.io import wavfile
from project.audio import AudioDrive
ROOT=Path(__file__).resolve().parents[1]

def draw(c,a):
 c.set_source_rgb(1,1,1);c.paint()
 def text(s,x,y,size=18,color=(.1,.13,.2)):
  c.set_source_rgb(*color);c.select_font_face('DejaVu Sans',0,0);c.set_font_size(size);c.move_to(x,y);c.show_text(s)
 def line(xs,ys,color,width=2):
  c.set_source_rgb(*color);c.set_line_width(width);c.new_path()
  for i,(x,y) in enumerate(zip(xs,ys)):
   (c.move_to if i==0 else c.line_to)(float(x),float(y))
  c.stroke()
 def panel(y,title):
  text(title,100,y-22,20)
  for sec in range(11):
   x=100+sec*136;c.set_source_rgb(.9,.92,.94);c.set_line_width(1);c.move_to(x,y);c.line_to(x,y+175);c.stroke();text(str(sec),x-5,y+199,15)
  line([100,1460],[y+175,y+175],(.5,.54,.6),1)
  return lambda val:y+175-np.asarray(val)*175
 text('New track / measured energy and animation drive',100,45,27)
 text('48 kHz · 2048-point periodic Hann · 480-sample hop · centered zero-padded STFT',100,76,16)
 sr,wav=wavfile.read(a.path);wav=wav.astype(np.float64)/(2**31);wav=wav.mean(axis=1)
 y=panel(135,'Stereo-mean waveform (original audio, unchanged in the final mux)')
 blocks=wav.reshape(2000,-1);tt=np.arange(2000)/200
 for i in range(2000):line([100+tt[i]*136]*2,[y(.5+blocks[i].min()/2),y(.5+blocks[i].max()/2)],(.33,.38,.45),.6)
 for yy,title,signal in [(410,'Low band 40–250 Hz: raw energy (blue), 30/180 ms envelope (orange)',a.normalized),(685,'Mid band 250–2500 Hz: energy / track maximum',a.mid/max(a.mid))]:
  y=panel(yy,title)
  for k,v in a.events.items():
   if (k=='C') != (yy==685):continue
   lo,hi=v['search_window_s'];c.set_source_rgba(.15,.39,.92,.07);c.rectangle(100+lo*136,yy,(hi-lo)*136,175);c.fill()
  line(100+a.times*136,y(signal),(.14,.39,.92),1.8)
  if yy==410:line(100+a.times*136,y(a.envelope),(.93,.40,.08),2.6)
  for k,v in a.events.items():
   if (k=='C') != (yy==685):continue
   x=100+v['time_s']*136;line([x,x],[yy-7,yy+175],(.13,.16,.24),1);text(f"{k}  {v['time_s']:.2f} s",x+9,yy+20,18)
 text('Event windows include both endpoints. Event centers use the raw band energy; pulse uses the smoothed low band.',100,934,16)
 text('The small envelope rises in the visible UI interval are retained without gain changes or extra beats.',100,960,16)

def main():
 a=AudioDrive(ROOT/'assets/brand_B_10s.wav');out=ROOT.parent/'diagnostics';out.mkdir(exist_ok=True)
 for ext in ['svg','png']:
  s=cairo.SVGSurface(str(out/'audio_analysis.svg'),1560,1000) if ext=='svg' else cairo.ImageSurface(cairo.FORMAT_RGB24,1560,1000)
  draw(cairo.Context(s),a)
  if ext=='png':s.write_to_png(str(out/'audio_analysis.png'))
  s.finish()
if __name__=='__main__':main()
