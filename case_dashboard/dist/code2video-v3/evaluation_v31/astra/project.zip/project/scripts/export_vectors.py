#!/usr/bin/env python3
"""Export code-authored illustration objects and glyphs to editable SVG files."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import cairo
from project.drawing import Canvas,ROOT,sample_curve
from project.scenes_graphic import GraphicScenes

def canvas(path,w=1920,h=1080):
 c=Canvas(w,h);c.surface=cairo.SVGSurface(str(path),w,h);c.c=cairo.Context(c.surface);c.c.set_line_cap(cairo.LINE_CAP_ROUND);c.c.set_line_join(cairo.LINE_JOIN_ROUND);return c

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['reconstruction','revision'],default='reconstruction');args=ap.parse_args()
 out=ROOT/'vector_library';cfg=json.loads((ROOT/('revision.json' if args.mode=='revision' else 'config.json')).read_text())
 if args.mode=='revision':cfg['_revision']=True;out=out/'revision'
 out.mkdir(exist_ok=True);g=GraphicScenes(cfg)
 for kind in sorted(set(v['kind'] for v in g.objects['illustration_stickers'])):
  c=canvas(out/(kind+'.svg'),400,400);g.sticker(c,kind,200,200,1,0,88);c.surface.finish()
 paper_small=sample_curve(g.cfg['curves']['small'][:-1]+[[808,818,865,851,909,849]])
 c=canvas(out/'letters_small.svg');g.bubble_text(c,'DRAW TOGETHER',paper_small[::-1],96,.11,.98);c.surface.finish()
 c=canvas(out/'letters_large.svg');g.bubble_text(c,'DRAW TOGETHER',g.big,96,.015,.672);g.bubble_text(c,'DRAW',g.big,96,.775,.985);c.surface.finish()
 if args.mode=='revision':
  for name,pts in [('large',g.big),('small',g.small[::-1])]:
   c=canvas(out/f'monochrome_{name}.svg');g.warped_text(c,'MOVE TOGETHER',pts,51,.01,.99,'#ffffff','plain');c.surface.finish()
 print('Exported editable vector library.')
if __name__=='__main__':main()
