#!/usr/bin/env python3
"""Offline image/audio checks; run after rendering all three movies in README.

This reads rendered pixels, independently computes event peaks with scipy STFT,
checks AAC timing/gain, and exercises the editable controls with fresh renders.
"""
import sys,json,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import cv2,numpy as np
from scipy.io import wavfile
from scipy.signal import stft,correlate,correlation_lags
from project.timeline import Project
from project.drawing import Canvas,curve_at
from project.revision_graphics import blue_cursor
ROOT=Path(__file__).resolve().parents[2]

def probe(path):
 return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
def frame(path,n):
 cap=cv2.VideoCapture(str(path));cap.set(cv2.CAP_PROP_POS_FRAMES,n);ok,bgr=cap.read();cap.release()
 if not ok:raise RuntimeError(f'Cannot decode frame {n} of {path}')
 return cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
def img(a):return a.array()[...,:3]
def put_panel(panels,a,label):panels.append((a.copy(),label))
def main():
 cfg=json.loads((ROOT/'project/revision.json').read_text());p=Project(cfg,'revision',ROOT/'project/revision.json')
 report={'media':{},'independent_audio':{},'pixel_parameters':{},'causal':{},'notes':[]}
 for name,path in [('revision',ROOT/'revision.mp4'),('reconstruction',ROOT/'reconstruction.mp4')]:
  m=probe(path);v=next(s for s in m['streams'] if s['codec_type']=='video');aa=[s for s in m['streams'] if s['codec_type']=='audio']
  report['media'][name]={'width':v['width'],'height':v['height'],'fps':v['avg_frame_rate'],'frames':int(v['nb_frames']),'duration_s':float(v['duration']),'pixel_format':v['pix_fmt'],'audio_streams':len(aa)}
  assert (v['width'],v['height'],v['avg_frame_rate'],int(v['nb_frames']))==(1920,1080,'24/1',240)
  assert len(aa)==(name=='revision')
 sr,pcm=wavfile.read(ROOT/'project/assets/brand_B_10s.wav');x=pcm.astype(np.float64)/(2**31)
 hz,tt,z=stft(x.mean(axis=1),sr,window='hann',nperseg=2048,noverlap=1568,boundary='zeros',padded=False)
 low=np.sqrt(np.mean(abs(z[(hz>=40)&(hz<=250)])**2,axis=0));mid=np.sqrt(np.mean(abs(z[(hz>=250)&(hz<=2500)])**2,axis=0))
 independent={}
 for label,lo,hi,en in [('A',.65,1.25,low),('B',2.25,2.90,low),('C',3.95,4.65,mid)]:
  indices=np.flatnonzero((tt>=lo-1e-10)&(tt<=hi+1e-10));k=indices[np.argmax(en[indices])];independent[label]=float(tt[k]);assert abs(independent[label]-p.audio.events[label]['time_s'])<1e-9
 decoded=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(ROOT/'revision.mp4'),'-map','0:a:0','-f','f32le','-ac','2','-ar','48000','-']),np.float32).reshape(-1,2)[:len(x)]
 xx=x.mean(axis=1);yy=decoded.mean(axis=1);corr=correlate(yy,xx,method='fft');lags=correlation_lags(len(yy),len(xx));lag=int(lags[np.argmax(corr)])
 gain=float(np.sum(decoded*x)/np.sum(x*x));err=float(np.sqrt(np.mean((decoded-x)**2)));rho=float(np.corrcoef(x.ravel(),decoded.ravel())[0,1])
 report['independent_audio']={'events_s':independent,'decoded_samples_checked':len(decoded),'offset_samples':lag,'least_squares_gain':gain,'gain_db':float(20*np.log10(gain)),'correlation':rho,'rms_codec_error':err,'decoded_peak':float(abs(decoded).max())};assert lag==0 and abs(gain-1)<.01
 panels=[]
 variants=[('pulse_amount',0,39),('cursor_delay_s',0,36),('head_overflow_px',0,109),('path_text','MAKE ART',63),('ui_gradient',['#F97316','#FACC15'],39)]
 for key,value,f in variants:
  base=img(p.render(f));c=dict(cfg);c[key]=value;q=Project(c,'revision',ROOT/'project/revision.json');changed=img(q.render(f));diff=np.any(base!=changed,axis=2)
  record={'frame':f,'value':value,'changed_pixels':int(diff.sum())};assert diff.any()
  if key=='cursor_delay_s':
   masks=[]
   for delay in [cfg[key],value]:
    cf=p.audio.source_time(f/24-delay)*24;masks.append(blue_cursor(cf).array()[...,3]>0)
   record['changed_pixels_outside_cursor_geometry']=int(np.sum(diff&~(masks[0]|masks[1])));assert record['changed_pixels_outside_cursor_geometry']==0
  if key=='pulse_amount':
   # The swept tube and its rounded terminal are the only possible changed pixels.
   mask=Canvas();mask.line([tuple(x) for x in p.graphics.big],'#ffffff',120);mask.line([(940,315),(870,379)],'#ffffff',120)
   record['changed_pixels_outside_tube']=int(np.sum(diff&(mask.array()[...,3]==0)));assert record['changed_pixels_outside_tube']==0
  if key=='head_overflow_px':
   record['zero_setting_overflow_alpha_sum']=int(q.portrait.last_overflow.sum());assert record['zero_setting_overflow_alpha_sum']==0
  report['pixel_parameters'][key]=record
  put_panel(panels,base,f'{key}: delivered / frame {f}');put_panel(panels,changed,f'{key}: {value}')
  del q
 # Width measured on the actual decoded main movie, normal to the original curve.
 point,tangent=curve_at(p.graphics.big,.25);normal=np.array([-tangent[1],tangent[0]]);offset=np.linspace(-70,70,1401)
 xy=point[None,:]+offset[:,None]*normal[None,:];widths=[]
 for f in range(32,48):
  a=frame(ROOT/'revision.mp4',f);samples=cv2.remap(a,xy[:,0].astype(np.float32)[None,:],xy[:,1].astype(np.float32)[None,:],cv2.INTER_LINEAR)[0].astype(float)
  blue=(samples[:,2]>samples[:,0]*1.35)&(samples[:,1]>samples[:,0]*1.08)&(samples[:,2]>100)
  # Select the colored run containing the centerline. A separate blue
  # selection-box stroke can intersect the sampling normal outside the tube.
  from scipy.ndimage import binary_closing, label
  closed=binary_closing(blue,iterations=3);labels,_=label(closed);center_label=labels[len(offset)//2]
  occupied=np.flatnonzero(labels==center_label) if center_label else np.array([],dtype=int)
  if len(occupied):
   width=float(offset[occupied[-1]]-offset[occupied[0]]);center=float((offset[occupied[-1]]+offset[occupied[0]])/2)
   green_occlusion=bool(np.any((samples[:,1]>samples[:,0]*1.25)&(samples[:,1]>samples[:,2]*1.1)&(samples[:,1]>100)))
   widths.append({'frame':f,'measured_width_px':width if not green_occlusion else None,'measured_center_offset_px':center if not green_occlusion else None,'expected_diameter_px':92*p.signals(f)['tube_thickness_scale'],'status':'selection handle intersects sampling line' if green_occlusion else 'measured'})
 report['decoded_tube_profiles']=widths
 # All three causal videos are decoded; events also have visible target-frame panels.
 movies={'base':ROOT/'revision.mp4','shifted':ROOT/'diagnostics/causal/shifted/revision.mp4','high':ROOT/'diagnostics/causal/high/revision.mp4'}
 captures={k:cv2.VideoCapture(str(v)) for k,v in movies.items()};stats={'high':[],'shifted_tail':[]}
 for f in range(240):
  ar={}
  for name,cap in captures.items():
   ok,a=cap.read();assert ok;ar[name]=a.astype(np.int16)
  stats['high'].append(float(np.mean(abs(ar['base']-ar['high']))))
  if f>=150:stats['shifted_tail'].append(float(np.mean(abs(ar['base']-ar['shifted']))))
 for cap in captures.values():cap.release()
 for name in ['shifted','high']:
  ev=json.loads((movies[name].parent/'audio_events.json').read_text());report['causal'][name]={'events_s':{k:v['time_s'] for k,v in ev['events'].items()}}
  for label in 'ABC':
   f=ev['events'][label]['nearest_output_frame'];put_panel(panels,frame(movies[name],f),f'{name}: {label} / frame {f}')
 report['causal']['high']['max_frame_mean_absolute_rgb_error']=max(stats['high'])
 report['causal']['high']['mean_absolute_rgb_error']=float(np.mean(stats['high']))
 report['causal']['shifted']['tail_max_frame_mean_absolute_rgb_error']=max(stats['shifted_tail'])
 report['causal']['shifted']['tail_mean_absolute_rgb_error']=float(np.mean(stats['shifted_tail']))
 report['notes']=['AAC comparisons use decoded audio with MP4 priming metadata applied.','Decoded video comparisons can include H.264 prediction/quantization differences; raw preservation is checked separately.','Tube measurements use blue-pixel outer boundaries at one unobscured normal cross-section, not signal logs.','No segmentation ground truth is available; no segmentation accuracy is claimed.']
 out=ROOT/'diagnostics';(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
 sheet=np.full((((len(panels)+1)//2)*390,1280,3),245,np.uint8)
 for i,(a,label) in enumerate(panels):
  x=i%2*640;y=i//2*390;sheet[y:y+360,x:x+640]=cv2.cvtColor(cv2.resize(a,(640,360)),cv2.COLOR_RGB2BGR);cv2.putText(sheet,label,(x+8,y+382),0,.52,(20,20,20),1,cv2.LINE_AA)
 cv2.imwrite(str(out/'parameter_and_causal_contact.jpg'),sheet)
 print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
