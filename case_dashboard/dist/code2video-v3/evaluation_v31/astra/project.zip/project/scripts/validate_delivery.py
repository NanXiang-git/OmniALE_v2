#!/usr/bin/env python3
"""Validate retained reconstruction, source mattes, and final-frame duplication."""
import json,subprocess
from pathlib import Path
import cv2,numpy as np
P=Path(__file__).resolve().parents[2]
def probe(p):
 return json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=codec_type,codec_name,width,height,pix_fmt,r_frame_rate,nb_read_frames,duration','-of','json',str(p)]))
def main():
 r={'reconstruction':probe(P/'reconstruction.mp4')}
 s=r['reconstruction']['streams'];assert len(s)==1 and s[0]['codec_type']=='video';v=s[0]
 assert (v['width'],v['height'],v['r_frame_rate'],v['pix_fmt'],v['codec_name'],v['nb_read_frames'])==(1920,1080,'24/1','yuv420p','h264','240')
 assert float(v['duration'])==10
 mapping=json.loads((P/'project/portrait_mapping.json').read_text());assert [m['source_index'] for m in mapping]==list(range(24,67));assert [m['output_frame'] for m in mapping]==list(range(108,151))
 r['portrait_source_indices']=[24,66];r['portrait_output_frames']=[108,150];r['portrait_consecutive_frames']=43
 diag=P/'diagnostics/stage1' if (P/'diagnostics/stage1/portrait_alpha.mp4').exists() else P/'diagnostics'
 for name in ['portrait_alpha','portrait_checker']:
  p=probe(diag/f'{name}.mp4');r[name]=p;assert len(p['streams'])==1 and p['streams'][0]['nb_read_frames']=='43'
 cap=cv2.VideoCapture(str(P/'reconstruction.mp4'));previous=None;delta=[];last=[]
 for f in range(240):
  ok,im=cap.read();assert ok
  small=cv2.resize(im,(480,270)).astype(np.float32)
  if previous is not None:delta.append(float(np.abs(small-previous).mean()))
  previous=small
  if f>=238:last.append(im)
 assert np.array_equal(last[0],last[1]);r['duplicate_final_frame_verified']=True
 r['mean_frame_motion_by_section']={f'{a}-{b}':float(np.mean(delta[a:b])) for a,b in [(4,32),(34,64),(64,108),(108,150),(150,178),(178,222)]}
 assert all(v>0.05 for v in r['mean_frame_motion_by_section'].values())
 # Check the saved alpha derivatives have both exact background transparency and soft hair edges.
 mat=[]
 for m in mapping:
  a=cv2.imread(str(P/m['asset']),cv2.IMREAD_UNCHANGED)[...,3]
  assert (a==0).mean()>.25 and (a>245).mean()>.1 and ((a>0)&(a<245)).sum()>200
  mat.append(dict(index=m['source_index'],transparent_fraction=float((a==0).mean()),soft_edge_pixels=int(((a>0)&(a<245)).sum())))
 r['alpha_derivative_checks']=mat;r['status']='passed'
 (diag/'validation.json').write_text(json.dumps(r,indent=2));print('Reconstruction delivery checks passed.')
if __name__=='__main__':main()
