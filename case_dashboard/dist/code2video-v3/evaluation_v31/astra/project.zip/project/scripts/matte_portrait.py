#!/usr/bin/env python3
"""Build recurrent RVM alpha and foreground derivatives from the supplied portrait."""
import argparse,json,subprocess
from pathlib import Path
import cv2,numpy as np,onnxruntime as ort
P=Path(__file__).resolve().parents[1]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--model',default='/tool_assets/rvm_mobilenetv3_fp32.onnx');a=ap.parse_args()
 opts=ort.SessionOptions();opts.intra_op_num_threads=4;opts.inter_op_num_threads=1
 sess=ort.InferenceSession(a.model,sess_options=opts,providers=['CPUExecutionProvider'])
 rec=[np.zeros((1,1,1,1),np.float32) for _ in range(4)]
 cap=cv2.VideoCapture(str(P/'assets/portrait_live_action.mp4'))
 out=P/'assets/portrait';out.mkdir(exist_ok=True)
 # Warm recurrent memory from the beginning; only frames used in the composition are retained.
 for idx in range(67):
  ok,bgr=cap.read()
  if not ok:break
  rgb=cv2.cvtColor(cv2.resize(bgr,(960,540)),cv2.COLOR_BGR2RGB).astype(np.float32)/255
  fg,alpha,*rec=sess.run(None,dict(src=rgb.transpose(2,0,1)[None],r1i=rec[0],r2i=rec[1],r3i=rec[2],r4i=rec[3],downsample_ratio=np.array([.5],np.float32)))
  if idx>=24:
   ph=alpha[0,0]
   # Retain soft hair and remove negligible network haze in definite background.
   ph=np.clip((ph-.006)/.994,0,1)
   rgba=np.dstack((fg[0].transpose(1,2,0),ph));rgba=np.clip(rgba*255,0,255).astype(np.uint8)
   cv2.imwrite(str(out/f'{idx:04}.png'),cv2.cvtColor(rgba,cv2.COLOR_RGBA2BGRA))
  if idx%12==0: print('matte source frame',idx,flush=True)
 mapping=[dict(output_frame=f,source_index=24+f-108,source_time=(24+f-108)*1001/24000,requested_source_time=1+(f-108)/24,asset=f'project/assets/portrait/{24+f-108:04}.png') for f in range(108,151)]
 (P/'portrait_mapping.json').write_text(json.dumps(mapping,indent=2))
 # Diagnostics exactly cover the 43 actual source frames, in composition order.
 d=P.parent/'diagnostics';d.mkdir(exist_ok=True)
 procs=[]
 for name in ['portrait_alpha','portrait_checker']:
  procs.append(subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-crf','16','-pix_fmt','yuv420p',str(d/(name+'.mp4'))],stdin=subprocess.PIPE))
 yy,xx=np.mgrid[:540,:960];checker=np.where(((xx//24+yy//24)%2)[...,None],.68,.88)
 for m in mapping:
  rgba=cv2.cvtColor(cv2.imread(str(P.parent/m['asset']),cv2.IMREAD_UNCHANGED),cv2.COLOR_BGRA2RGBA).astype(np.float32)/255
  al=rgba[...,3:];rgb=rgba[...,:3]
  procs[0].stdin.write(np.uint8(np.repeat(al,3,axis=2)*255).tobytes())
  procs[1].stdin.write(np.uint8(np.clip(rgb*al+checker*(1-al),0,1)*255).tobytes())
 for p in procs:p.stdin.close();assert p.wait()==0
 print('Matte derivatives and diagnostics complete.',flush=True)
if __name__=='__main__':main()
