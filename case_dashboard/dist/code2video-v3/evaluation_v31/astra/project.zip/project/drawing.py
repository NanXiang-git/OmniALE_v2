"""Editable Cairo primitives, sampled Bézier curves, and compositing utilities."""
import math,ctypes,ctypes.util
from pathlib import Path
import cairo,cv2,numpy as np
from scipy.spatial import cKDTree
W,H=1920,1080
ROOT=Path(__file__).resolve().parent
# Register bundled typefaces without modifying global font directories.
try:
 _fc=ctypes.CDLL(ctypes.util.find_library('fontconfig'));_fc.FcConfigAppFontAddFile.argtypes=[ctypes.c_void_p,ctypes.c_char_p];_fc.FcConfigAppFontAddFile.restype=ctypes.c_int
 for _font in (ROOT/'fonts').glob('*.ttf'):_fc.FcConfigAppFontAddFile(None,str(_font).encode())
except (OSError,AttributeError):pass

def rgb(c):
 if isinstance(c,str):
  c=c.lstrip('#');return tuple(int(c[i:i+2],16)/255 for i in (0,2,4))
 return tuple(c)
def clamp(x):return min(1,max(0,float(x)))
def ease(x):x=clamp(x);return x*x*(3-2*x)
def lerp(a,b,t):return a+(b-a)*t
def mixcol(a,b,t):return tuple(lerp(x,y,t) for x,y in zip(rgb(a),rgb(b)))

def path(ctx,p):
 ctx.new_path()
 for el in p:
  if isinstance(el,str):ctx.close_path()
  elif len(el)==2:
   if not ctx.has_current_point():ctx.move_to(*el)
   else:ctx.line_to(*el)
  elif len(el)==6:ctx.curve_to(*el)
  elif len(el)==4:ctx.move_to(*el[:2]);ctx.line_to(*el[2:])

def sample_curve(p,n=1500):
 pts=[];a=np.array(p[0],float)
 for seg in p[1:]:
  if len(seg)==2:
   b=np.array(seg,float);t=np.linspace(0,1,100)[:,None];q=a*(1-t)+b*t;a=b
  else:
   b,c,d=np.array(seg,float).reshape(3,2);t=np.linspace(0,1,300)[:,None];q=(1-t)**3*a+3*(1-t)**2*t*b+3*(1-t)*t*t*c+t**3*d;a=d
  pts.extend(q.tolist())
 pts=np.array(pts);dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))];u=np.linspace(0,dist[-1],n)
 out=np.array([np.interp(u,dist,pts[:,i]) for i in range(2)]).T
 return out

def curve_at(pts,u):
 u=np.asarray(u);ind=np.clip(u*(len(pts)-1),0,len(pts)-1);lo=np.floor(ind).astype(int);hi=np.minimum(lo+1,len(pts)-1);q=pts[lo]*(1-(ind-lo)[...,None])+pts[hi]*(ind-lo)[...,None]
 d=pts[np.minimum(lo+3,len(pts)-1)]-pts[np.maximum(lo-3,0)];d/=np.maximum(np.linalg.norm(d,axis=-1,keepdims=True),1e-7)
 return q,d

class Canvas:
 def __init__(self,w=W,h=H,bg=None):
  self.w,self.h=w,h;self.surface=cairo.ImageSurface(cairo.FORMAT_ARGB32,w,h);self.c=cairo.Context(self.surface)
  self.c.set_line_join(cairo.LINE_JOIN_ROUND);self.c.set_line_cap(cairo.LINE_CAP_ROUND)
  if bg:self.c.set_source_rgb(*rgb(bg));self.c.paint()
 def color(self,col,alpha=1):self.c.set_source_rgba(*rgb(col),alpha)
 def grad(self,coords,stops,radial=False):
  g=cairo.RadialGradient(*coords) if radial else cairo.LinearGradient(*coords)
  for t,col in stops:
   v=rgb(col);g.add_color_stop_rgba(t,*v[:3],v[3] if len(v)>3 else 1)
  self.c.set_source(g)
 def shape(self,p,fill=None,stroke=None,sw=1,gradient=None):
  path(self.c,p)
  if fill is not None or gradient:
   if gradient:self.grad(*gradient)
   else:self.color(fill)
   self.c.fill_preserve()
  if stroke:self.color(stroke);self.c.set_line_width(sw);self.c.stroke()
  else:self.c.new_path()
 def line(self,p,col,width=1,gradient=None):
  path(self.c,p)
  if gradient:self.grad(*gradient)
  else:self.color(col)
  self.c.set_line_width(width);self.c.stroke()
 def rect(self,x,y,w,h,col=None,stroke=None,sw=1,r=0,gradient=None):
  if w<=0 or h<=0:return
  if r:
   r=min(r,w/2,h/2);k=.5522847498;p=[(x+r,y),(x+w-r,y),(x+w-r+k*r,y,x+w,y+r-k*r,x+w,y+r),(x+w,y+h-r),(x+w,y+h-r+k*r,x+w-r+k*r,y+h,x+w-r,y+h),(x+r,y+h),(x+r-k*r,y+h,x,y+h-r+k*r,x,y+h-r),(x,y+r),(x,y+r-k*r,x+r-k*r,y,x+r,y),'z'];self.shape(p,col,stroke,sw,gradient);return
  self.c.new_path();self.c.rectangle(x,y,w,h)
  if col is not None or gradient:
   if gradient:self.grad(*gradient)
   else:self.color(col)
   self.c.fill_preserve()
  if stroke:self.color(stroke);self.c.set_line_width(sw);self.c.stroke()
  else:self.c.new_path()
 def ellipse(self,x,y,rx,ry,col=None,stroke=None,sw=1,gradient=None,angle=0):
  self.c.save();self.c.translate(x,y);self.c.rotate(angle);self.c.scale(rx,ry);self.c.new_path();self.c.arc(0,0,1,0,2*math.pi);self.c.restore()
  if col is not None or gradient:
   if gradient:self.grad(*gradient)
   else:self.color(col)
   self.c.fill_preserve()
  if stroke:self.color(stroke);self.c.set_line_width(sw);self.c.stroke()
  else:self.c.new_path()
 def text(self,txt,x,y,size,col,font='DejaVu Sans',bold=False):
  self.c.select_font_face(font,cairo.FONT_SLANT_NORMAL,cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL);self.c.set_font_size(size);self.c.move_to(x,y);self.color(col);self.c.show_text(txt)
 def image(self,img,x=0,y=0,scale=1,alpha=1,angle=0):
  if isinstance(img,Canvas):s=img.surface;keep=None
  else:
   if img.shape[2]==3:img=np.dstack([img,np.full(img.shape[:2],255,np.uint8)])
   keep=img[..., [2,1,0,3]].copy();keep[...,:3]=(keep[...,:3].astype(np.uint16)*keep[...,3:4]//255).astype(np.uint8)
   s=cairo.ImageSurface.create_for_data(keep,cairo.FORMAT_ARGB32,img.shape[1],img.shape[0])
  self.c.save();self.c.translate(x,y);self.c.rotate(angle);self.c.scale(scale,scale);self.c.set_source_surface(s,0,0);self.c.paint_with_alpha(alpha);self.c.restore()
 def array(self):
  self.surface.flush();a=np.ndarray((self.h,self.w,4),np.uint8,buffer=self.surface.get_data()).copy()[...,[2,1,0,3]]
  al=a[...,3:4].astype(np.float32)/255;a[...,:3]=np.uint8(np.clip(a[...,:3]/np.maximum(al,1e-6),0,255));return a
 def save(self,p):self.surface.write_to_png(str(p))

def poly_segment(pts,a=0,b=1):
 lo=max(0,int(a*(len(pts)-1)));hi=min(len(pts),int(b*(len(pts)-1))+1)
 return [tuple(x) for x in pts[lo:hi:3]]

def shadow_layer(layer,blur=12,offset=(7,9),opacity=.18):
 a=layer.array() if isinstance(layer,Canvas) else layer
 m=cv2.GaussianBlur(a[...,3],(0,0),blur);m=cv2.warpAffine(m,np.float32([[1,0,offset[0]],[0,1,offset[1]]]),(a.shape[1],a.shape[0]))
 return np.dstack([np.zeros((*m.shape,3),np.uint8),np.uint8(m*opacity)])

def gradient_texture(w,h,stops,axis=0,noise=0,seed=1):
 v=np.linspace(0,1,w if axis==0 else h);s=np.array([x[0] for x in stops]);colors=np.array([rgb(x[1]) for x in stops]);line=np.stack([np.interp(v,s,colors[:,i]) for i in range(3)],-1)
 out=np.tile(line[None],(h,1,1)) if axis==0 else np.tile(line[:,None],(1,w,1))
 if noise:out+=np.random.default_rng(seed).normal(0,noise,(h,w,1))
 return np.uint8(np.clip(out*255,0,255))

def mask_texture(mask,texture):
 a=mask.array()[...,3] if isinstance(mask,Canvas) else mask
 if isinstance(texture,str):texture=np.tile(np.uint8(np.array(rgb(texture))*255),(a.shape[0],a.shape[1],1))
 return np.dstack((texture,a))

def selection(c,x,y,w,h,color='#d5297d',handles=True):
 c.rect(x,y,w,h,None,color,1.4)
 if handles:
  for px,py in [(x,y),(x+w/2,y),(x+w,y),(x,y+h/2),(x+w,y+h/2),(x,y+h),(x+w/2,y+h),(x+w,y+h)]:c.rect(px-5,py-5,10,10,'#ffffff',color,1.4)

def star_points(x,y,r,n=7,inner=.42,rot=0):
 return [(x+math.cos(rot+i*math.pi/n)*r*(1 if i%2==0 else inner),y+math.sin(rot+i*math.pi/n)*r*(1 if i%2==0 else inner)) for i in range(2*n)]+['z']
