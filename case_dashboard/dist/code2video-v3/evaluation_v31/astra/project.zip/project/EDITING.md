The shared scene graph is `timeline.py`. Reconstruction mode uses the original frame clock and original `GraphicScenes`, `PortraitScene`, `Collage`, and `Garden` geometry. The frozen stage-one movie is retained byte for byte. `STAGE1_EDITING.md` and `STAGE1_README.md` preserve the original documentation.

Revision mode enables only the following branches:

| Object or control | Editable implementation | Behavior |
| --- | --- | --- |
| `audio.clock` | `audio.py:AudioDrive` | Analyze configured PCM; derive A/B/C; invert the piecewise source/output anchor mapping. |
| `interface.tube` | `revision_graphics.py:blue_tube` | Original Bézier path and terminals, blue/cyan volumetric cross-section, attached highlights, semi-transparent edge. Radius = original radius × (1 + pulse_amount × envelope). |
| `cursor.blue` | `revision_graphics.py:blue_cursor`, `timeline.py` | Evaluate the complete original cursor track at source_time(output_time − cursor_delay_s). Original green/orange cursor tracks retain the base clock. |
| `illustration.path_text` | `scenes_graphic.py:GraphicScenes.bubble_text` / `warped_text` | Replace each TOGETHER occurrence before curving and masking its glyph outlines; preserve original reading direction, outline/fill, backing and folds. |
| `portrait.source` | `revision_portrait.py:person_image` | Source sample = 24 + source_frame − 108. Interpolate adjacent RGBA samples with premultiplied alpha; never use the audio envelope for this actor. |
| `portrait.reveal` | `revision_portrait.py:local_reveal` | Independent row sweeps share the color-slice row boundaries, finish at source frame 132, and leave the actor clock untouched. |
| `portrait.head_overflow` | `audio.py:overflow`, `revision_portrait.py:person_layers` | Six output-frame smoothstep rise and six-frame fall, starting at measured C; maximum 36 px by default. One translated actor, one union mask. |
| `portrait.foreground` | `scenes_portrait.py:glass` / `slices` | Original translucent ring and color blades remain in front of the subject, including the overflow interval. |
| Later architecture and garden | `scenes_collage.py`, `nature.py` | Same original geometry and clock from output 6.25 s onward. |

For the portrait, let P be the placed source matte, W the original back window, U the upward extension of W restricted to the head region, and R the local reveal. The composed actor alpha is `P × max(W,U) × R`. The independent head-overflow alpha is `P × max(U−W,0) × R`. The RGB actor is drawn once using the union. The torso uses W, while the upper head can use U. Glass and slices are then drawn over the actor. There is no second displaced head image.

Layer order is: background; printed grid; UI rails/tube/controls; independently clocked blue cursor; illustrated ribbons and stickers; rear slices; satin and rear glass; masked live actor; foreground glass; foreground color slices; orbits; architectural collage; garden path; cyclists.

`diagnostics/control_signals.csv` is sampled at frame PTS `frame/24`. `source_time_s` is the scene clock, `low_raw_normalized` is the unsmoothed band signal, `low_control` is the specified envelope, and `tube_thickness_scale` is the actual radius multiplier. `portrait_source_index` is fractional and monotonic while active, otherwise −1. `portrait_reveal_fraction` is the fraction of the windowed actor admitted by its reveal. `portrait_visibility` measures remaining actor alpha after window, reveal, foreground glass transmission and color-slice occlusion, divided by the placed original actor alpha area; it is not a segmentation-accuracy claim. `head_overflow_px` is the requested excursion at that PTS, and `head_overflow_alpha_area_px` is the extra matte area actually admitted above the window.

The original stage-one top-level `disabled_objects` switches remain available. Revision also supports `interface.tube` and `cursor.blue`. Changing the normal configuration fields actually changes rendering; exported SVGs are editable auxiliary outlines, not image layers sampled by the renderer. `vector_library/` retains the reconstruction outlines, and `vector_library/revision/` contains the revised colored and monochrome text outlines.

The full diagnostic movies use the output timeline, including blank actor masks outside its interval. The raw source soft mattes in `assets/portrait/0024.png`–`0066.png` are independent of the logo aperture. Optional RVM matte regeneration is described in `DEPENDENCIES.md`; it is not needed to render this delivery.
