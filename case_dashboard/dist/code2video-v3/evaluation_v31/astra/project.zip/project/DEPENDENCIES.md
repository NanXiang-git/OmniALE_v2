The renderer runs entirely offline. Runtime: Python 3.12, NumPy 1.26.4, SciPy 1.11.4, PyCairo 1.25.1, OpenCV 4.6+, and FFmpeg 6.1.1 with libx264. Cairo and Fontconfig are system libraries. The DejaVu regular and bold fonts and their license are included in `fonts/`.

`assets/portrait_live_action.mp4` is the supplied real live-action source. `assets/portrait/0024.png` through `0066.png` are its straight-RGBA matte derivatives at 960×540. They are the only sequential raster assets used by the compositor. No reference movie or extracted reference frame is included in the rendering project.

The source is 24000/1001 fps. Output frame 108 begins with source index 24 (PTS 1.001 s, the sample at the requested 1.0-second start). Output frames 108–150 use 43 successive source frames through index 66. The mapping is explicit in `portrait_mapping.json`. Hair and clothing opacity come from recurrent Robust Video Matting; the separate logo aperture and graphic masks are applied after matting.

The saved RGBA files are sufficient for a clean render. Optionally rebuild them and both diagnostic movies with `scripts/matte_portrait.py --model /path/to/rvm_mobilenetv3_fp32.onnx`, using ONNX Runtime. The model was supplied at `/tool_assets/rvm_mobilenetv3_fp32.onnx`; it is not needed for ordinary rendering. The license supplied with the model is included in `assets/LICENSE_RVM.txt` (GNU GPL v3). Inference warms the recurrent state on source frames 0–23 and carries all four state tensors forward.

All other imagery is constructed from authored Bézier paths, explicit glyph contours, procedural surface shaders, and individually placed plants/boards. The hand, boat, building, and rider approximations are code-editable graphics. Static cached procedural surfaces are regenerated in memory; there are no rendered scene videos or baked frame sequences.

Stage two adds `assets/brand_B_10s.wav`, the supplied PCM24, 48 kHz stereo source. Its source is harrisonlace on Freesound (sound 828231), CC0 1.0, as described in the supplied stage-two SOURCE.md. The provided ten-second file is copied byte for byte; its earlier preparation is part of the supplied input. This project does not fetch or alter the original recording. Only FFmpeg AAC encoding is applied when muxing the revision.

`audio.py` uses NumPy and SciPy already listed above. `plot_audio.py` uses Cairo directly and does not require Matplotlib. The revision retains the original 43 RGBA assets and samples/interpolates them with the continuously mapped source clock; no new portrait model inference is needed.
