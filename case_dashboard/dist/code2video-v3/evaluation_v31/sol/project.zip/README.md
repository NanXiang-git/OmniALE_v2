Stage 2 revision is `revision.mp4`: 1920×1080, 24 fps, 240 frames, 10 seconds, H.264/yuv420p with the supplied B audio at its original start, speed and gain. `reconstruction.mp4` is the unchanged copied stage-1 movie. The shared editable project supports both modes without the reference video, `/candidate`, `/previous`, network access or `/tool_assets`.

Run with the supplied system Python and FFmpeg:

```bash
python3 render.py --mode revision --config project/revision.json --output revision.mp4 --diagnostics
python3 render.py --mode reconstruction --config project/scene.json --output reconstruction_rerender.mp4
```

The commands also work from another working directory using absolute paths. Copy `render.py` and the entire `project/` directory to relocate the renderer. Dependencies and versions are in `project/requirements.txt`; fonts, textures, original portrait footage, corrected RGBA portrait frames, new WAV and the optional offline matting model are included. Existing RGBA assets are used for normal renders. `project/prepare_portrait.py` can regenerate the original stage-1 mattes with ONNX Runtime. No installation or network is needed in this environment.

The audio analysis uses stereo arithmetic mean, 48 kHz, centered 2048-point periodic Hann STFT, 480-sample hop, and RMS of FFT magnitudes within inclusive band endpoints. Events are energy maxima, not onsets:

| Event | Output/audio time | Source scene state | Nearest output frame |
| --- | ---: | ---: | ---: |
| A | 0.90 s | Grid at 1.25 s | 22 |
| B | 2.61 s | Illustration at 3.50 s | 63 |
| C | 4.30 s | Portrait reveal at 5.50 s | 103 |

All seven anchors and their piecewise linear map are computed from the chosen WAV at render time. The existing object easing, paths, motion and occlusion use fractional mapped source frames. From 6.25 s onward, source and output time coincide, preserving the architecture, hands, growing plants, cyclists and white exit.

`project/revision.json` provides every requested control. `base_config` resolves relative to the JSON file; relative `audio_path` resolves inside `project/`, and an absolute audio path is also accepted. `path_text` replaces each original TOGETHER occurrence, preserving the existing CREATE prefix on the longer curve, so that curve reads CREATE CREATE ON. The same replacement is used during the black/white ring phase. Letter advances are recomputed along the original paths. The other controls are the two `ui_gradient` endpoints, blue-object `cursor_delay_s`, fractional `pulse_amount`, and `head_overflow_px`. An actual alternate preset is included as `project/example_variant.json`:

```bash
python3 render.py --mode revision --config project/example_variant.json --output variant.mp4
```

The blue/cyan right UI tube retains its fixed center path. Its constituent stroke widths, translucent edge and highlights respond to the normalized low-band signal, with 30 ms attack and 180 ms release before frame interpolation. Other UI elements do not pulse. The white left track and its original magenta inset guide retain their materials. A numerical silence guard prevents sub-LSB spectral leakage in a pure high-band probe from being normalized to a full pulse; it is inactive on the supplied audio. The blue cursor is a separate vector layer sampled at output time minus 0.25 s, including its visibility envelope; green and orange use undelayed mapped source time.

The keyed portrait is one continuous source layer, with premultiplied RGBA interpolation between adjacent supplied source frames. Source performance keeps advancing while reveal alpha reaches one at C. In C…C+0.50 s the head/shoulders translate upward by up to 36 pixels with six-frame smooth ease in and six-frame ease out. Only the upper rear window expands. The lower torso remains windowed, and the existing front glass rails and colored slats are drawn afterward across the shoulder and lower face. There is one head. Neither the person nor its source clock responds to the audio pulse.

The diagnostic movies are all 240 frames in output time and scene coordinates:

- `diagnostics/portrait_alpha.mp4`: exact character alpha after reveal, rear-window masking and outgoing row wipe, before front rails/slats.
- `diagnostics/portrait_checker.mp4`: the same premultiplied character layer on a checkerboard.
- `diagnostics/head_overflow.mp4`: only the added head alpha outside the original rear window, black outside the 0.50-second extension interval.
- `diagnostics/control_signals.csv`: per-frame output/source time, measured low energy, smoothed control, tube scale, blue cursor source clock/visibility, portrait source clock/visibility, alpha coverage and head extension.

`audio_events.json` documents exact analysis and events. `edit_map.json` gives object entry points, masks, composition order and the full output/source mapping. The preserved stage-1 registry and instructions are `project/stage1_edit_map.json` and `project/STAGE1_README.md`. The native layers are Python/Cairo paths and objects in `renderer.py`, `revision_renderer.py`, `drawing.py`, `motifs.py`, `nature.py` and `garden_objects.json`. Review SVG exports include separate revision interface, illustration and portrait-overflow artwork in `project/artwork/revision/`.

Verification tools:

```bash
python3 project/analyze_audio.py
python3 project/verify_controls.py
python3 project/validate_revision.py
python3 render.py --mode revision --config project/revision.json --frames 22,46,63,78,103,109,150,168,200,216 --diagnostics --output inspection
```

The final encoded movie and diagnostic movies were decoded and inspected, including event neighborhoods, head extension, hair on white/black/checker, front occlusion and the late scenes. `diagnostics/validation.json` records full decode, format and audio checks. `diagnostics/control_verification.json` records pixel tests for the six-frame cursor delay, pulse locality, measured tube thickness under independent low/high audio probes, editable config variants and retained late scenes. The 80 Hz probe changes measured tube thickness from 90.6 to 99.9 px; the 6000 Hz-only probe leaves it at 90.6 px. Adding the high probe to B leaves the tube pixels unchanged in the tested pose. Audio sample alignment is zero; the AAC decode has no clipping. AAC compression accounts for its remaining sample error.

Reconstruction mode was regenerated independently; sampled raw frames matched the frozen renderer exactly, and a full freshly encoded movie decoded at 49.19 dB PSNR against the frozen stage-1 encode. The final revision was also regenerated from a separate clean copy of only the project and entry point. Inspection evidence is under `diagnostics/decoded/`, `revision_contact_sheet.jpg`, `event_and_overflow_frames.jpg`, `portrait_edge_review.png` and `control_checks/`. Stage-1 diagnostics are retained under `diagnostics/reconstruction/`. Intermediate inspection frames remain under `diagnostics/review/`; the final decoded frames are authoritative.

The stage-1 drawn hand, architecture and rider approximations are retained. No segmentation ground truth, official benchmark score or native listening interface is claimed. RVM and font licenses are included. The new audio is the supplied harrisonlace CC0 excerpt; its WAV is copied unchanged and no other sounds are included in the final movie. The supplied reference is the BUCK / Adobe Creative Cloud ident, observed only for reconstruction; this project is not commissioned or endorsed by those brands.
