"""Editable Cairo drawing primitives, spline sampling and layered compositing."""
import math
import cairo
import numpy as np
from PIL import Image
from pathlib import Path
PI=math.pi

def _register_bundled_fonts():
    import ctypes
    try:
        fc=ctypes.CDLL('libfontconfig.so.1')
        fc.FcConfigGetCurrent.restype=ctypes.c_void_p
        cfg=fc.FcConfigGetCurrent()
        fc.FcConfigAppFontAddFile.argtypes=[ctypes.c_void_p,ctypes.c_char_p]
        for name in ['DejaVuSans.ttf','DejaVuSans-Bold.ttf']:
            fc.FcConfigAppFontAddFile(cfg,str(Path(__file__).resolve().parent/'fonts'/name).encode())
        fc.FcConfigBuildFonts.argtypes=[ctypes.c_void_p];fc.FcConfigBuildFonts(cfg)
    except (OSError,AttributeError):pass
_register_bundled_fonts()

def rgba(c):
    if isinstance(c,str):
        s=c.lstrip('#');return tuple(int(s[i:i+2],16)/255 for i in (0,2,4))+(1,)
    return tuple(c)+(1,)*(4-len(c))
def color(ctx,c):ctx.set_source_rgba(*rgba(c))
def gradient(x0,y0,x1,y1,stops):
    g=cairo.LinearGradient(x0,y0,x1,y1)
    for t,c in stops:g.add_color_stop_rgba(t,*rgba(c))
    return g
def radial(x,y,r,stops):
    g=cairo.RadialGradient(x-r*.3,y-r*.4,0,x,y,r)
    for t,c in stops:g.add_color_stop_rgba(t,*rgba(c))
    return g
def paint(ctx,c):
    if isinstance(c,cairo.Pattern):ctx.set_source(c)
    else:color(ctx,c)
def path(ctx,p):
    ctx.new_path()
    for cmd in p:
        if cmd[0]=='M':ctx.move_to(*cmd[1:])
        elif cmd[0]=='L':ctx.line_to(*cmd[1:])
        elif cmd[0]=='C':ctx.curve_to(*cmd[1:])
        elif cmd[0]=='Z':ctx.close_path()
def fill(ctx,c,outline=None,lw=1):
    paint(ctx,c)
    if outline:
        ctx.fill_preserve();paint(ctx,outline);ctx.set_line_width(lw);ctx.stroke()
    else:ctx.fill()
def stroke(ctx,c,w):
    paint(ctx,c);ctx.set_line_width(w);ctx.set_line_cap(cairo.LINE_CAP_ROUND);ctx.set_line_join(cairo.LINE_JOIN_ROUND);ctx.stroke()
def line(ctx,pts,c,w=1,close=False):
    ctx.new_path();ctx.move_to(*pts[0])
    for p in pts[1:]:ctx.line_to(*p)
    if close:ctx.close_path();fill(ctx,c)
    else:stroke(ctx,c,w)
def poly(ctx,pts,c,outline=None,lw=1):
    ctx.new_path();ctx.move_to(*pts[0])
    for p in pts[1:]:ctx.line_to(*p)
    ctx.close_path();fill(ctx,c,outline,lw)
def ellipse(ctx,x,y,rx,ry,c,outline=None,lw=1,rot=0):
    ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.scale(rx,ry);ctx.new_path();ctx.arc(0,0,1,0,2*PI);ctx.restore()
    fill(ctx,c,outline,lw)
def circle(ctx,x,y,r,c,outline=None,lw=1):ellipse(ctx,x,y,r,r,c,outline,lw)
def rect(ctx,x,y,w,h,c,outline=None,lw=1,r=0):
    ctx.new_path()
    if r:
        r=min(r,w/2,h/2);ctx.move_to(x+r,y);ctx.line_to(x+w-r,y);ctx.arc(x+w-r,y+r,r,-PI/2,0);ctx.line_to(x+w,y+h-r);ctx.arc(x+w-r,y+h-r,r,0,PI/2);ctx.line_to(x+r,y+h);ctx.arc(x+r,y+h-r,r,PI/2,PI);ctx.line_to(x,y+r);ctx.arc(x+r,y+r,r,PI,1.5*PI);ctx.close_path()
    else:ctx.rectangle(x,y,w,h)
    fill(ctx,c,outline,lw)
def text(ctx,s,x,y,size,c='#000000',font='DejaVu Sans',bold=True,center=False):
    ctx.select_font_face(font,cairo.FONT_SLANT_NORMAL,cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL);ctx.set_font_size(size)
    if center:x-=ctx.text_extents(s).x_advance/2
    ctx.move_to(x,y);ctx.text_path(s);fill(ctx,c)
def sample(p,n=60):
    pts=[];cur=np.zeros(2)
    for cmd in p:
        if cmd[0]=='M':cur=np.array(cmd[1:],float);pts.append(cur)
        elif cmd[0]=='L':
            end=np.array(cmd[1:],float)
            for t in np.linspace(0,1,max(2,int(np.linalg.norm(end-cur)/5)))[1:]:pts.append(cur*(1-t)+end*t)
            cur=end
        elif cmd[0]=='C':
            a,b,end=np.array(cmd[1:],float).reshape(3,2)
            for t in np.linspace(0,1,n)[1:]:pts.append((1-t)**3*cur+3*(1-t)**2*t*a+3*(1-t)*t*t*b+t**3*end)
            cur=end
    pts=np.array(pts);dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))]
    return pts,dist

def at(s,u):
    pts,d=s;u=np.clip(u,0,1);v=u*d[-1];i=np.clip(np.searchsorted(d,v)-1,0,len(d)-2);t=(v-d[i])/(d[i+1]-d[i]+1e-9)
    p=pts[i]*(1-t)+pts[i+1]*t;angle=math.atan2(*(pts[i+1]-pts[i])[::-1]);return p,angle

def partial(ctx,s,a,b,c,w):
    pts,d=s;i=max(0,np.searchsorted(d,a*d[-1])-1);j=min(len(d),np.searchsorted(d,b*d[-1])+1)
    if j-i>1:line(ctx,pts[i:j],c,w)
def path_type(ctx,s,words,size=86,c='#f59b00',outline='#000000',stretch=1,offset=0,tracking=-3):
    ctx.select_font_face('DejaVu Sans',cairo.FONT_SLANT_NORMAL,cairo.FONT_WEIGHT_BOLD);ctx.set_font_size(size)
    widths=[ctx.text_extents(ch).x_advance+tracking for ch in words];total=sum(widths);scale=s[1][-1]/total*stretch;cursor=offset*s[1][-1]
    for ch,w in zip(words,widths):
        p,a=at(s,(cursor+w*scale/2)/s[1][-1]);ctx.save();ctx.translate(*p);ctx.rotate(a);ctx.scale(scale,1);ctx.move_to(-w/2,size*.36);ctx.text_path(ch)
        if outline:
            ctx.set_line_join(cairo.LINE_JOIN_ROUND)
            paint(ctx,outline);ctx.set_line_width(14);ctx.stroke_preserve()
            paint(ctx,c);ctx.set_line_width(12);ctx.stroke_preserve();ctx.fill()
        else:paint(ctx,c);ctx.fill()
        ctx.restore();cursor+=w*scale

def image_surface(p):
    im=Image.open(p).convert('RGBA');a=np.array(im).astype(np.uint16);a[:,:,:3]=(a[:,:,:3]*a[:,:,3:]+127)//255
    buf=np.ascontiguousarray(a[:,:,[2,1,0,3]].astype('uint8'))
    surf=cairo.ImageSurface.create_for_data(buf,cairo.FORMAT_ARGB32,im.width,im.height)
    return surf,buf

def draw_image(ctx,im,x,y,scale=1,alpha=1):
    ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.set_source_surface(im,0,0);ctx.paint_with_alpha(alpha);ctx.restore()
def smooth(a,b,t):
    v=np.clip((t-a)/(b-a),0,1);return float(v*v*(3-2*v))
def clamp(v,a=0,b=1):return max(a,min(b,v))

def soft_stroke_surface(p,w,c,sigma=8,dx=0,dy=0):
    """Cairo path -> feathered static lighting mask, derived only from editable vectors."""
    from PIL import ImageFilter
    sf=cairo.ImageSurface(cairo.FORMAT_A8,1920,1080);cx=cairo.Context(sf);cx.translate(dx,dy);path(cx,p);stroke(cx,'#ffffff',w);sf.flush()
    mask=np.frombuffer(sf.get_data(),np.uint8).reshape(1080,sf.get_stride())[:,:1920].copy()
    mask=np.array(Image.fromarray(mask).filter(ImageFilter.GaussianBlur(sigma)))
    r,g,b,a=rgba(c);aa=(mask.astype(float)*a).astype('uint8');data=np.zeros((1080,1920,4),np.uint8)
    data[:,:,0]=(aa*b).astype('uint8');data[:,:,1]=(aa*g).astype('uint8');data[:,:,2]=(aa*r).astype('uint8');data[:,:,3]=aa
    sf=cairo.ImageSurface.create_for_data(data,cairo.FORMAT_ARGB32,1920,1080)
    return sf,data

def spot(ctx,x,y,rx,ry,c):
    rr,gg,bb,aa=rgba(c)
    # Build the elliptical path in normalized space, then its matching lighting pattern.
    ctx.save();ctx.translate(x,y);ctx.scale(rx,ry);ctx.new_path();ctx.arc(0,0,1,0,PI*2)
    g=cairo.RadialGradient(0,0,0,0,0,1);g.add_color_stop_rgba(0,rr,gg,bb,aa);g.add_color_stop_rgba(.6,rr,gg,bb,aa*.3);g.add_color_stop_rgba(1,rr,gg,bb,0)
    ctx.set_source(g);ctx.fill();ctx.restore()
