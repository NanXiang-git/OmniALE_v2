"""Inspect the actual encoded deliverables, not just the renderer settings."""
from pathlib import Path
import subprocess,json,hashlib,cv2,numpy as np
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent.parent

def probe(p):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
def main():
    report={};diag=ROOT/'diagnostics';diag.mkdir(exist_ok=True)
    for name in ['reconstruction','portrait_alpha','portrait_checker']:
        p=ROOT/'reconstruction.mp4' if name=='reconstruction' else diag/f'{name}.mp4';pr=probe(p)
        streams=pr['streams'];vs=[s for s in streams if s['codec_type']=='video'];aud=[s for s in streams if s['codec_type']=='audio'];v=vs[0]
        cap=cv2.VideoCapture(str(p));count=0;prior=None;identical=[];changes=[];chosen={};first=None
        selected=set(range(0,240,8))|{56,88,112,120,128,144,152,168,184,200,216,224}
        while True:
            ok,bgr=cap.read()
            if not ok:break
            if prior is not None:
                difference=float(np.abs(bgr.astype(np.int16)-prior.astype(np.int16)).mean());changes.append(round(difference,5))
                if difference==0:identical.append(count)
            if name=='reconstruction' and count in selected:chosen[count]=bgr.copy()
            if name!='reconstruction' and count==24:cv2.imwrite(str(diag/f'{name}_sample.jpg'),bgr)
            prior=bgr;count+=1
        cap.release()
        if name=='reconstruction':
            assert count==240 and v['width']==1920 and v['height']==1080
            assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and v['r_frame_rate']=='24/1'
            assert float(pr['format']['duration'])==10.0
            sheet=Image.new('RGB',(1920,1320),'#eeeeee');draw=ImageDraw.Draw(sheet)
            for i,f in enumerate(range(0,240,8)):
                im=Image.fromarray(cv2.cvtColor(chosen[f],cv2.COLOR_BGR2RGB));im.thumbnail((384,196));x=i%5*384;y=i//5*220;sheet.paste(im,(x,y+24));draw.text((x+7,y+6),f'{f:03d}  {f/24:.3f}s',fill='black')
            sheet.save(diag/'render_contact_sheet.jpg')
            for f in [56,88,112,120,128,144,152,168,184,200,216,224]:cv2.imwrite(str(diag/f'render_{f:03d}.jpg'),chosen[f])
        else:assert count==53
        assert len(vs)==1 and not aud
        report[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'decoded_frames':count,'width':v['width'],'height':v['height'],'codec':v['codec_name'],'pixel_format':v['pix_fmt'],'frame_rate':v['r_frame_rate'],'duration':pr['format']['duration'],'video_streams':len(vs),'audio_streams':len(aud),'identical_consecutive_frame_indices':identical,'mean_absolute_pixel_change_per_frame':changes}
    mapping=json.loads((ROOT/'project/assets/portrait/mapping.json').read_text());assert len(mapping)==53
    assert [r['source_frame'] for r in mapping]==list(range(24,77));assert [r['output_frame'] for r in mapping]==list(range(105,158))
    report['checks']={'full_decode':True,'delivery_format':True,'silent_all_movies':True,'portrait_contiguous_from_source_frame_24':True,'runtime_inputs':'project directory only; verified by invoking render.py from /workspace/scratch','reference_pixels_as_output_layers':False}
    (diag/'validation.json').write_text(json.dumps(report,indent=2));print('Verified all three movies and 53 continuous portrait source frames.')
if __name__=='__main__':main()
