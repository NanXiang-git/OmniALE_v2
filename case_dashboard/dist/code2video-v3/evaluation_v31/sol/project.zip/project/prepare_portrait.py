"""Rebuild the only video-derived scene asset, using offline recurrent RVM."""
import os,json,cv2,numpy as np,onnxruntime as ort
from pathlib import Path
from PIL import Image
from scipy.ndimage import distance_transform_edt
ROOT=Path(__file__).resolve().parent

def prepare():
    dest=ROOT/'assets/portrait';dest.mkdir(parents=True,exist_ok=True)
    opts=ort.SessionOptions();opts.intra_op_num_threads=4;opts.inter_op_num_threads=1
    session=ort.InferenceSession(str(ROOT/'assets/rvm_mobilenetv3_fp32.onnx'),opts,providers=['CPUExecutionProvider'])
    rec=[np.zeros((1,1,1,1),np.float32) for _ in range(4)]
    cap=cv2.VideoCapture(str(ROOT/'assets/portrait_live_action.mp4'))
    records=[]
    for idx in range(77):
        ok,bgr=cap.read()
        if not ok:raise RuntimeError('Portrait decode failed')
        rgb=cv2.cvtColor(cv2.resize(bgr,(960,540),interpolation=cv2.INTER_AREA),cv2.COLOR_BGR2RGB)
        src=np.transpose(rgb.astype(np.float32)/255,(2,0,1))[None]
        fgr,alpha,*rec=session.run(None,dict(src=src,r1i=rec[0],r2i=rec[1],r3i=rec[2],r4i=rec[3],downsample_ratio=np.array([.5],np.float32)))
        if idx<24:continue
        a=np.clip(alpha[0,0],0,1)
        # Suppress disconnected speckles without simplifying the actual hair silhouette.
        n,lab,stats,_=cv2.connectedComponentsWithStats((a>.12).astype(np.uint8),8)
        keep=np.zeros_like(a,np.uint8)
        for i in range(1,n):
            if stats[i,cv2.CC_STAT_AREA]>150:keep[lab==i]=1
        keep=cv2.dilate(keep,np.ones((11,11),np.uint8))
        a*=keep;a[a<.012]=0;a[a>.995]=1
        fg=np.transpose(fgr[0],(1,2,0));fg=np.clip(fg,0,1)
        # Decontaminate translucent hair RGB using the nearest opaque foreground.
        # Alpha stays unchanged, so individual strands and temporal continuity survive.
        _,nearest=distance_transform_edt(a<.92,return_indices=True)
        edgecolor=fg[nearest[0],nearest[1]]
        blend=np.where((a>0)&(a<.85),(1-a)*.85,0)[...,None]
        fg=fg*(1-blend)+edgecolor*blend
        rgba=np.dstack((np.round(fg*255).astype('uint8'),np.round(a*255).astype('uint8')))
        Image.fromarray(rgba).save(dest/f'{idx:04d}.png')
        records.append(dict(output_frame=105+idx-24,source_frame=idx,source_seconds=idx*1001/24000,alpha_asset=f'assets/portrait/{idx:04d}.png'))
        if idx%8==0:print('matting',idx,flush=True)
    (dest/'mapping.json').write_text(json.dumps(records,indent=2))
    # Diagnostics show the exact alpha and corrected foreground used by the renderer.
    import subprocess
    proc=[]
    for name in ['portrait_alpha','portrait_checker']:
        path=ROOT.parent/'diagnostics'/f'{name}.mp4'
        p=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-r','24','-i','-','-an','-c:v','libx264','-crf','17','-pix_fmt','yuv420p',str(path)],stdin=subprocess.PIPE)
        proc.append(p)
    yy,xx=np.indices((540,960));checker=np.where(((xx//24+yy//24)%2)[...,None],.72,.90)*np.ones((540,960,3))
    for r in records:
        im=np.array(Image.open(ROOT/r['alpha_asset']));a=im[:,:,3:]/255
        proc[0].stdin.write(np.repeat(im[:,:,3:],3,axis=2).tobytes())
        comp=im[:,:,:3]*a+checker*255*(1-a)
        proc[1].stdin.write(comp.clip(0,255).astype('uint8').tobytes())
    for p in proc:p.stdin.close();p.wait()
if __name__=='__main__':prepare()
