"""Pixel-based object-control checks and reproducible counterfactual audio probes."""
from pathlib import Path
import sys,tempfile,json,copy,hashlib
import numpy as np,cv2,cairo
from scipy.io import wavfile
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from render import load_config
from revision_renderer import RevisionRenderer
from renderer import Renderer
from drawing import at


def layer(renderer,name,f,t,width=1920,height=1080,offset=(0,0)):
 renderer.output_time=t
 sf=cairo.ImageSurface(cairo.FORMAT_ARGB32,width,height);ctx=cairo.Context(sf);ctx.translate(-offset[0],-offset[1]);getattr(renderer,name)(ctx,f) if name!='delayed_blue' else renderer.delayed_blue(ctx)
 sf.flush();return np.frombuffer(sf.get_data(),np.uint8).reshape(height,width,4).copy()


def main():
 cfg=load_config(ROOT/'project/revision.json');r=RevisionRenderer(cfg);diag=ROOT/'diagnostics';dest=diag/'control_checks';dest.mkdir(exist_ok=True)
 report={}
 # Exact blue object test in rendered pixel space, including entry and exit alpha.
 nd=copy.deepcopy(cfg);nd['cursor_delay_s']=0;zero=RevisionRenderer(nd)
 mismatch=[];visible=[]
 for f in range(240):
  a=layer(r,'delayed_blue',0,f/24,180,160,(990,550))
  b=layer(zero,'delayed_blue',0,(f-6)/24,180,160,(990,550)) if f>=6 else np.zeros_like(a)
  if not np.array_equal(a,b):mismatch.append(f)
  if a[:,:,3].max()>0:visible.append(f)
 assert not mismatch,mismatch
 report['blue_cursor']=dict(delay_frames=6,pixel_identical_to_zero_delay_layer_six_frames_earlier=True,visible_frames=visible)
 # Pulse on/off full-scene comparison at the same output time and source time.
 npcfg=copy.deepcopy(cfg);npcfg['pulse_amount']=0;nopulse=RevisionRenderer(npcfg)
 f=36;a=r.frame(f);b=nopulse.frame(f);difference=np.max(abs(a.astype(int)-b.astype(int)),axis=2)
 alpha=np.maximum(layer(r,'ui_tube',r.current_source_frame,f/24)[:,:,3],layer(nopulse,'ui_tube',r.current_source_frame,f/24)[:,:,3])
 allowed=cv2.dilate((alpha>0).astype('uint8'),np.ones((9,9),np.uint8))>0
 # The existing glass shader refracts the changed body beneath this panel.
 allowed[465:740,1200:1500]=True
 outside=int(((difference>0)&~allowed).sum());assert outside==0,outside
 Image.fromarray(a).save(dest/'pulse_on.png');Image.fromarray(b).save(dest/'pulse_off.png')
 heat=np.zeros_like(a);heat[:,:,0]=np.minimum(difference*12,255);Image.fromarray(heat).save(dest/'pulse_difference.png')
 report['pulse_locality']=dict(checked_output_frame=f,changed_pixels=int((difference>0).sum()),changed_pixels_outside_tube_and_existing_glass_refraction=outside,fixed_center_path=True)
 # Thickness is measured across a rendered alpha profile, perpendicular to the
 # original path. The path position is shared by all audio conditions.
 p,angle=at(r.samples['logo_right'],.65);normal=np.array([-np.sin(angle),np.cos(angle)])
 distances=np.arange(-80,80,.1);coords=p[None]+distances[:,None]*normal[None]
 def thickness(alpha):
  values=cv2.remap(alpha,coords[:,0].astype('float32')[None],coords[:,1].astype('float32')[None],cv2.INTER_LINEAR)[0]
  inside=np.flatnonzero(values>=128)
  return dict(width_px=float(distances[inside[-1]]-distances[inside[0]]+.1),center_normal_offset_px=float((distances[inside[-1]]+distances[inside[0]])/2))
 # Replace the track with independent 80 Hz and 6000 Hz Gaussian bursts. Geometry
 # and source pose remain fixed to isolate the causal audio -> width connection.
 with tempfile.TemporaryDirectory() as tmp:
  sr=48000;tt=np.arange(480000)/sr;gate=np.exp(-.5*((tt-1.8)/.06)**2)
  sr,raw=wavfile.read(r.audio_path);source=raw.astype(float)/2147483648
  probes={
   'silence':np.zeros((480000,2)),
   'low_80Hz':np.repeat((.5*np.sin(2*np.pi*80*tt)*gate)[:,None],2,axis=1),
   'high_6000Hz':np.repeat((.5*np.sin(2*np.pi*6000*tt)*gate)[:,None],2,axis=1),
   'original_plus_high':source+np.repeat((.1*np.sin(2*np.pi*6000*tt)*gate)[:,None],2,axis=1),
  }
  results={};images=[];labels=[];baseline=layer(r,'ui_tube',56,1.8)
  for name,signal in probes.items():
   path=Path(tmp)/f'{name}.wav';wavfile.write(path,sr,signal.astype('float32'))
   c=copy.deepcopy(cfg);c['audio_path']=str(path);obj=RevisionRenderer(c)
   pixels=layer(obj,'ui_tube',56,1.8);m=thickness(pixels[:,:,3]);m.update(control=obj.audio.control(1.8),maximum_raw_low_energy=float(obj.audio.bands['low'].max()))
   if name=='original_plus_high':m['max_pixel_difference_vs_original']=int(abs(pixels.astype(int)-baseline.astype(int)).max())
   results[name]=m
   rgb=pixels[:,:,[2,1,0]].astype(float)+255*(1-pixels[:,:,3:]/255);images.append(Image.fromarray(rgb.clip(0,255).astype('uint8')).crop((700,210,1430,870)));labels.append(name+f' | width {m["width_px"]:.1f}px | control {m["control"]:.5f}')
  assert results['high_6000Hz']['control']==0
  assert results['low_80Hz']['width_px']>results['silence']['width_px']+7
  assert abs(results['low_80Hz']['center_normal_offset_px']-results['silence']['center_normal_offset_px'])<.3
  assert results['original_plus_high']['max_pixel_difference_vs_original']<=1
  report['counterfactual_audio']=dict(method='48 kHz stereo float WAV probes, 0.5 peak sine, Gaussian sigma 60 ms centered at 1.8 s; same source pose 56 and same center path',results=results)
  sheet=Image.new('RGB',(1200,1150),'#eeeeee');d=ImageDraw.Draw(sheet);font=ImageFont.truetype(str(ROOT/'project/fonts/DejaVuSans.ttf'),16)
  for i,(im,label) in enumerate(zip(images,labels)):
   im.thumbnail((580,530));x=i%2*600;y=i//2*575;sheet.paste(im,(x+10,y+36));d.text((x+10,y+8),label,font=font,fill='black')
  sheet.save(dest/'audio_causality.jpg')
 # All configurable visual fields are exercised through the shared renderer.
 variant=copy.deepcopy(cfg);variant.update(path_text='MAKE IT',ui_gradient=['#EA580C','#A3E635'],cursor_delay_s=0,pulse_amount=0,head_overflow_px=0)
 v=RevisionRenderer(variant)
 differences={}
 for f in [46,63,109]:
  changed=v.frame(f);original=r.frame(f);Image.fromarray(changed).save(dest/f'variant_{f:03d}.png')
  differences[f]=int(np.any(changed!=original,axis=2).sum());assert differences[f]>100
 report['config_variant']=dict(changes={k:variant[k] for k in ['path_text','ui_gradient','cursor_delay_s','pulse_amount','head_overflow_px']},changed_pixels=differences)
 # Unmodified late architecture and garden: compare actual unencoded scene pixels.
 base=Renderer(load_config(ROOT/'project/scene.json'));late=[]
 for f in [150,158,168,184,200,216,224,239]:
  a=r.frame(f);b=base.frame(f);diff=int(abs(a.astype(int)-b.astype(int)).max());late.append(dict(frame=f,max_channel_difference=diff))
  assert diff<=1,(f,diff)
 report['late_scene_preservation']=late
 # Source parameters remain continuous, including throughout head extension.
 source_frames=[r.portrait_source_index(r.audio.source_time(f/24)*24) for f in range(82,158)]
 assert all(b>a for a,b in zip(source_frames,source_frames[1:]))
 report['portrait_source']=dict(continuous_monotonic_fractional_indices=True,first=source_frames[0],last=source_frames[-1],head_overflow_target_at_C_plus_quarter_second=r.overflow_amount(r.audio.events['C']['time_s']+.25))
 (diag/'control_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
