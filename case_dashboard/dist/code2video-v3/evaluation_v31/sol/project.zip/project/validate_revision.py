"""Decode and inspect final movies; make contact sheets from encoded pixels.

No reference footage is used in rendering. Optional clean R comparison reads
only the independently regenerated project output.
"""
from pathlib import Path
import argparse,csv,hashlib,json,subprocess
import cv2,numpy as np
from scipy.io import wavfile
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent.parent
FONT=ROOT/'project/fonts/DejaVuSans.ttf'

def probe(path):
 return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))

def sheet(images,labels,dest,cols=4,w=480,h=295):
 rows=(len(images)+cols-1)//cols;im=Image.new('RGB',(cols*w,rows*h),'#e5e7eb');d=ImageDraw.Draw(im)
 for i,(image,label) in enumerate(zip(images,labels)):
  x=i%cols*w;y=i//cols*h
  if isinstance(image,np.ndarray):image=Image.fromarray(cv2.cvtColor(image,cv2.COLOR_BGR2RGB))
  image=image.copy();image.thumbnail((w,h-26));im.paste(image,(x+(w-image.width)//2,y+26));d.text((x+7,y+5),label,font=ImageFont.truetype(str(FONT),17),fill='#172554')
 im.save(dest)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--clean-r');args=ap.parse_args()
 diag=ROOT/'diagnostics';dest=diag/'decoded';dest.mkdir(exist_ok=True)
 report={'movies':{}}
 selected={0,12,20,21,22,23,30,36,40,46,48,54,60,61,62,63,64,72,78,84,90,96,100,102,103,104,106,109,112,115,120,132,144,150,158,168,180,192,200,208,216,224,228,239}
 frames={}
 for name in ['revision','reconstruction','portrait_alpha','portrait_checker','head_overflow']:
  path=ROOT/f'{name}.mp4' if name in ['revision','reconstruction'] else diag/f'{name}.mp4'
  pr=probe(path);v=[s for s in pr['streams'] if s['codec_type']=='video'][0];a=[s for s in pr['streams'] if s['codec_type']=='audio']
  c=cv2.VideoCapture(str(path));count=0;previous=None;identical=[];changes=[];nonzero=[]
  while True:
   ok,bgr=c.read()
   if not ok:break
   if previous is not None:
    change=float(np.abs(bgr.astype(np.int16)-previous.astype(np.int16)).mean());changes.append(change)
    if change==0:identical.append(count)
   if name=='revision' and count in selected:
    frames[count]=bgr.copy();cv2.imwrite(str(dest/f'revision_{count:03d}.jpg'),bgr,[cv2.IMWRITE_JPEG_QUALITY,95])
   if name in ['portrait_alpha','head_overflow']:
    if bgr.max()>20:nonzero.append(count)
   if name not in ['revision','reconstruction'] and count in [90,103,109,115,150]:
    cv2.imwrite(str(dest/f'{name}_{count:03d}.png'),bgr)
   previous=bgr;count+=1
  c.release()
  assert count==240 and v['width']==1920 and v['height']==1080,(name,count)
  assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and v['r_frame_rate']=='24/1'
  assert abs(float(pr['format']['duration'])-10)<.001
  assert len(a)==(1 if name=='revision' else 0)
  report['movies'][name]=dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),decoded_frames=count,width=v['width'],height=v['height'],fps=v['r_frame_rate'],duration=pr['format']['duration'],codec=v['codec_name'],pixel_format=v['pix_fmt'],audio_streams=len(a),identical_consecutive_frames=identical,mean_absolute_change_per_frame=changes,nonzero_mask_frames=nonzero)
 allframes=sorted(frames);sheet([frames[f] for f in allframes],[f'{f:03d} | {f/24:.4f} s' for f in allframes],diag/'revision_contact_sheet.jpg')
 eventframes=[20,21,22,23,61,62,63,64,102,103,104,106,106,109,112,115]
 sheet([frames[f] for f in eventframes],[f'{f:03d} | {f/24:.4f} s' for f in eventframes],diag/'event_and_overflow_frames.jpg')
 # AAC decode: compare original samples at their unshifted positions.
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(ROOT/'revision.mp4'),'-map','0:a:0','-f','f32le','-acodec','pcm_f32le','-'])
 decoded=np.frombuffer(raw,np.float32).reshape(-1,2)[:480000].astype(float)
 sr,source=wavfile.read(ROOT/'project/assets/audio/brand_B_10s.wav');source=source.astype(float)/2147483648
 assert sr==48000 and len(decoded)==len(source)==480000
 gain=float(np.sum(source*decoded)/np.sum(source*source));error=decoded-source
 snr=float(10*np.log10(np.sum(source*source)/np.sum(error*error)))
 correlations={}
 for offset in range(-8,9):
  if offset<0:x=source[-offset:];y=decoded[:offset]
  elif offset>0:x=source[:-offset];y=decoded[offset:]
  else:x=source;y=decoded
  correlations[offset]=float(np.sum(x*y)/np.sqrt(np.sum(x*x)*np.sum(y*y)))
 lag=max(correlations,key=correlations.get)
 assert lag==0 and .99<gain<1.01 and snr>20
 report['audio']=dict(compared_samples_per_channel=len(source),best_lag_samples=lag,gain=gain,unshifted_correlation=correlations[0],snr_db=snr,decoded_sample_peak=float(abs(decoded).max()),source_sample_peak=float(abs(source).max()),clipped_samples=int((abs(decoded)>=1).sum()),audio_start_time=[s for s in probe(ROOT/'revision.mp4')['streams'] if s['codec_type']=='audio'][0]['start_time'])
 assert report['audio']['clipped_samples']==0
 if args.clean_r:
  clean=Path(args.clean_r);pr=probe(clean);assert not [s for s in pr['streams'] if s['codec_type']=='audio']
  a=cv2.VideoCapture(str(clean));b=cv2.VideoCapture(str(ROOT/'reconstruction.mp4'));sse=0;pixels=0;n=0
  while True:
   oka,x=a.read();okb,y=b.read()
   assert oka==okb
   if not oka:break
   sse+=float(((x.astype(float)-y.astype(float))**2).sum());pixels+=x.size;n+=1
  a.release();b.release();psnr=float(10*np.log10(255**2/(sse/pixels))) if sse else 'infinity'
  assert n==240 and (psnr=='infinity' or psnr>45)
  report['independent_reconstruction_render']=dict(decoded_frames=n,psnr_vs_frozen_mp4_db=psnr,silent=True)
 report['verification_scope']='Actual decoded pixels and decoded audio inspected. No mask ground truth or numerical visual-quality score is claimed.'
 (diag/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='movies'},indent=2))
if __name__=='__main__':main()
