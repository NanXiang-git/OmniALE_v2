#!/usr/bin/env python3
"""Reproduce audio events and an inspectable waveform/band-energy plot."""
from pathlib import Path
import argparse,json
import numpy as np
from audio_analysis import AudioAnalysis

def main():
 p=argparse.ArgumentParser();p.add_argument('--audio',default=str(Path(__file__).parent/'assets/audio/brand_B_10s.wav'));p.add_argument('--out',default=str(Path(__file__).parent.parent));args=p.parse_args()
 dest=Path(args.out);dest.mkdir(parents=True,exist_ok=True);a=AudioAnalysis(args.audio)
 (dest/'audio_events.json').write_text(json.dumps(a.report(),indent=2)+'\n')
 from PIL import Image,ImageDraw,ImageFont
 fontroot=Path(__file__).parent/'fonts'
 font=lambda size:ImageFont.truetype(str(fontroot/'DejaVuSans.ttf'),size)
 im=Image.new('RGB',(1800,1160),'white');d=ImageDraw.Draw(im)
 d.text((80,26),'New source audio B — waveform, band energy, and local tube control',font=font(28),fill='#0f172a')
 left,right=220,1740;plotw=right-left
 waveform=a.mono[:480000].reshape(-1,240)
 panels=[(waveform.min(axis=1),waveform.max(axis=1),'Mono waveform','#94a3b8',.005,-.8,.8),
         (a.low_normalized,None,'40–250 Hz\nnormalized energy','#2563eb',.01,0,1.08),
         (a.bands['mid']/a.bands['mid'].max(),None,'250–2500 Hz\nnormalized energy','#db2777',.01,0,1.08),
         (a.envelope,None,'Tube control\n30 ms attack\n180 ms release','#0891b2',.01,0,1.08)]
 for i,(v,vhi,label,col,step,ymin,ymax) in enumerate(panels):
  y0=110+i*245;y1=y0+185
  xx=lambda t:left+t/10*plotw
  yy=lambda v:y1-(v-ymin)/(ymax-ymin)*185
  d.text((25,y0+48),label,font=font(19),fill='#334155',spacing=7)
  for tick in range(11):
   x=xx(tick);d.line((x,y0,x,y1),fill='#e2e8f0');d.text((x-7,y1+9),str(tick),font=font(16),fill='#475569')
  for val in ([0,.5,1] if i else [-.5,0,.5]):
   y=yy(val);d.line((left,y,right,y),fill='#e2e8f0');d.text((left-45,y-9),f'{val:g}',font=font(16),fill='#475569')
  d.line((left,y0,left,y1,right,y1),fill='#94a3b8',width=1)
  pts=[(xx(j*step),yy(float(value))) for j,value in enumerate(v)]
  if vhi is not None:
   for j,(lo,hi) in enumerate(zip(v,vhi)):d.line((xx(j*step),yy(lo),xx(j*step),yy(hi)),fill=col)
  else:d.line(pts,fill=col,width=2)
  for name,e in a.events.items():
   if (i==1 and name in ['A','B']) or (i==2 and name=='C'):
    x=xx(e['time_s']);d.line((x,y0,x,y1),fill=col,width=2)
    d.text((x+10,y0+5),f"{name} = {e['time_s']:.2f}s",font=font(21),fill=col)
    d.text((x+10,y0+32),f"source {e['source_state_s']:.2f}s state",font=font(17),fill=col)
  if i==3:
   for t in np.arange(240)/24:
    x=xx(t);y=yy(a.control(t));d.ellipse((x-2,y-2,x+2,y+2),fill=col)
 d.text((650,1100),'Original audio / output time (seconds)',font=font(23),fill='#334155')
 (dest/'diagnostics').mkdir(exist_ok=True);im.save(dest/'diagnostics/audio_analysis.png')
 print(json.dumps(a.events,indent=2))
if __name__=='__main__':main()
