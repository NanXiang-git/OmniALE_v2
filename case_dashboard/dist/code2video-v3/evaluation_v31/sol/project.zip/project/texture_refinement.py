"""Offline procedural texture authoring. No reference pixels are used."""
from pathlib import Path
from PIL import Image
import numpy as np
from scipy.ndimage import zoom,gaussian_filter

def build(root):
    root=Path(root);root.mkdir(exist_ok=True,parents=True);rng=np.random.default_rng(902)
    h,w=280,600;yy,xx=np.indices((h,w));rgb=np.zeros((h,w,3),float);alpha=np.zeros((h,w),float)
    noise=np.zeros((h,w))
    for k,a in [(10,.18),(26,.09),(74,.05),(190,.02)]:noise+=zoom(rng.normal(size=(k,k)),(h/k,w/k),order=2)[:h,:w]*a
    # Lit overlapping puffs form a small volume with a turbulent boundary.
    puffs=[]
    for i in range(95):
        x=rng.uniform(80,520);cen=135-35*np.sin((x-60)/500*np.pi);y=cen+rng.normal(0,23);r=rng.uniform(18,54)
        puffs.append((x,y,r))
    for x,y,r in sorted(puffs,key=lambda a:a[1]):
        dx=(xx-x)/r;dy=(yy-y)/r;d=dx*dx+dy*dy
        inside=d<1.1;nz=np.sqrt(np.clip(1-d,0,1));lit=np.clip(-dx*.25-dy*.43+nz*.7,.0,1)
        a=np.clip((1-d+noise*.45)*5,0,.95)*inside
        value=.79+.21*lit+noise*.02
        c=np.stack([value,value+.008,value+.016],axis=-1).clip(0,1)
        outa=a+alpha*(1-a)
        rgb=(c*a[:,:,None]+rgb*alpha[:,:,None]*(1-a[:,:,None]))/(outa[:,:,None]+1e-10);alpha=outa
    out=np.dstack((rgb*255,alpha*255)).clip(0,255).astype('uint8');Image.fromarray(out).save(root/'cloud.png')
    h=w=800;yy,xx=np.indices((h,w));noise=np.zeros((h,w));small=np.zeros((h,w))
    for k,a in [(8,.6),(22,.4),(57,.25),(144,.12),(400,.05)]:noise+=zoom(rng.normal(size=(k,k)),(h/k,w/k),order=2)[:h,:w]*a
    v=(noise-noise.min())/(noise.max()-noise.min())
    caustic=np.clip((np.sin(xx*.12+noise*12)*np.sin(yy*.10+noise*8)-.77)*3.0,0,1)
    tex=np.stack([7+v*30+caustic*16,31+v*96+caustic*27,43+v*112+caustic*30],axis=-1)
    Image.fromarray(tex.clip(0,255).astype('uint8')).save(root/'water.png')
if __name__=='__main__':build(Path(__file__).resolve().parent/'assets/procedural')
