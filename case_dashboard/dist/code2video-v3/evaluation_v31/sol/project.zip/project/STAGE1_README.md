# Silent reconstruction — stage 1

`reconstruction.mp4` is the complete 10-second, 240-frame, 1920×1080, 24 fps H.264/yuv420p reconstruction. It contains one video stream and no audio.

Re-render after copying this entire submission into a clean directory:

```bash
cd /path/to/submission
python3 render.py --mode reconstruction --config project/scene.json --output reconstruction.mp4
```

The command also works from another working directory with absolute paths. No network, reference movie, `/candidate`, or `/tool_assets` is needed. Use the system `python3`. Dependencies are Python 3.12, NumPy, SciPy, Pillow, pycairo, OpenCV, FFmpeg, and the DejaVu Sans font; versions are recorded in `project/requirements.txt`. Font copies are included in `project/fonts/` and are registered locally through Fontconfig.

The native project is Python/Cairo with independently drawn objects, editable cubic paths, vector lettering, gradient materials, and seeded procedural detail. It is not a reference-frame playback project. The hand, staircase, boats, observer, and cyclists are drawn approximations. Water, clouds, and stars are original procedural static textures. Their transforms and the geometry around them are separate.

- `project/scene.json`: canvas, central paths, source placement, stage ranges, object IDs.
- `project/renderer.py`: composition order, frame-specific transitions, UI, portrait window and colored slats.
- `project/drawing.py`: Bézier sampling, curved type, gradients, lighting and compositing primitives.
- `project/motifs.py`: individual illustration stickers, selection guides, cursors and glass controls.
- `project/nature.py`: separate anatomical hand shapes, pencils, tentacle, stairs, dock, boats, observer, growing plants and articulated riders.
- `project/garden_objects.json`: IDs and editable per-object parameters for every leaf, flower and plank. Set `visible` to false to remove an individual element. Parameter order is included in the file.
- `edit_map.json`: source-to-output frame mapping, layer relationships, object entry points and occlusion order.

The portrait is the supplied real footage, separated with the included offline recurrent RVM model. Translucent hair colors are decontaminated toward nearby opaque hair while retaining the original soft alpha. Source frames 24–76 run continuously, in order, beginning at approximately source time 1.0 s. Head and shoulder proportions are retained; only the lower shirt is extended inside the logo window to fill its lower bowl. The face is roughly 200–220 pixels wide. The foreground glass rails and color slats occlude the keyed person. The upper glass rail is behind the head.

`project/assets/portrait/` contains the exact premultiplied-at-composite-time RGBA derivatives. `diagnostics/portrait_alpha.mp4` and `diagnostics/portrait_checker.mp4` contain those same 53 source frames at 24 fps, before scene transforms. Their first frame corresponds to output frame 105; no timing padding is added. To regenerate the mattes and diagnostics from the supplied source and model copies:

```bash
python3 project/prepare_portrait.py
```

`project/texture_refinement.py` authors the water and cloud textures. `project/export_artwork.py` produces SVG artwork review exports; the JSON/Python sources remain the canonical editable project. Existing procedural texture assets are included for deterministic re-rendering.

For individual frame inspection:

```bash
python3 render.py --mode reconstruction --config project/scene.json --frames 24,56,88,128,168,200,216 --output inspection
```

`diagnostics/validation.json` records stream checks and decoded-frame continuity. `diagnostics/render_contact_sheet.jpg` and the selected decoded JPEG frames were inspected after encoding. The final white interval follows the reference exit.

RVM's license is in `project/assets/LICENSE_RVM.txt`. The portrait source is Mixkit's supplied street portrait (clip 4815). The reference is the supplied BUCK / Adobe Creative Cloud ident, used for observation only. This reconstruction is not commissioned or endorsed by those brands. This delivery contains no music, audio work, or later-stage revision.
