"""Editable collage and growing garden. All imagery here is drawn or procedural."""
from drawing import *
from motifs import flower
import random
from scipy.ndimage import gaussian_filter,zoom


def make_textures(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(52)
    if not (root/'water.png').exists():
        H=W=700
        z=np.zeros((H,W),float)
        for k,amp in [(9,1),(25,.6),(70,.3),(220,.12)]:
            a=rng.normal(size=(k,k));a=zoom(a,(H/k,W/k),order=2);z+=a[:H,:W]*amp
        z=(z-z.min())/(z.max()-z.min());yy,xx=np.indices((H,W))
        z=np.clip(z*.8+.1*np.sin(xx*.12+z*14)*np.sin(yy*.12+z*17),0,1)
        a=np.zeros((H,W,3),np.uint8);a[:,:,0]=8+z*26;a[:,:,1]=39+z*98;a[:,:,2]=50+z*118
        # Sunlit caustics and small sea foam flecks.
        for _ in range(2200):
            x,y=rng.integers(0,W,2);r=rng.integers(1,3);a[max(0,y-r):y+r,max(0,x-r):x+r]=np.array([72,157,170])
        Image.fromarray(a).save(root/'water.png')
    if not (root/'cloud.png').exists():
        H,W=240,560;yy,xx=np.indices((H,W));field=np.zeros((H,W))
        for _ in range(58):
            x=rng.uniform(90,W-80);y=rng.uniform(90,160);rx=rng.uniform(25,72);ry=rng.uniform(23,54)
            field+=np.exp(-((xx-x)/rx)**2-((yy-y)/ry)**2)*rng.uniform(.3,1)
        noise=np.zeros((H,W))
        for k,amp in [(10,.7),(35,.4),(100,.18)]:
            n=zoom(rng.normal(size=(k,k)),(H/k,W/k),order=2)[:H,:W];noise+=n*amp
        alpha=np.clip((field+noise*.7-.85)*2.3,0,1)
        alpha=gaussian_filter(alpha,.75)
        shade=np.clip(.91+(noise*.04)-(yy/H)*.06,.75,1)
        rgba=np.zeros((H,W,4),np.uint8);rgba[:,:,:3]=np.clip(shade[:,:,None]*255+np.array([0,2,3]),0,255).astype('uint8');rgba[:,:,3]=(alpha*240).astype('uint8')
        Image.fromarray(rgba).save(root/'cloud.png')
    if not (root/'stars.png').exists():
        H=W=600;yy,xx=np.indices((H,W));z=np.zeros((H,W));
        for k,a in [(9,1),(32,.6),(100,.25)]:z+=zoom(rng.normal(size=(k,k)),(H/k,W/k),order=2)[:H,:W]*a
        glow=np.exp(-((xx-300)**2+(yy-330)**2)/(140**2))
        rgb=np.zeros((H,W,3));rgb[:,:,0]=5+np.maximum(z,0)*4;rgb[:,:,1]=10+glow*42+np.maximum(z,0)*10;rgb[:,:,2]=22+glow*60+np.maximum(z,0)*17
        for _ in range(2600):
            x,y=rng.integers(0,W,2);v=rng.uniform(65,255);rgb[y,x]=[v*.8,v*.95,v]
        Image.fromarray(rgb.clip(0,255).astype('uint8')).save(root/'stars.png')

def boat(ctx,x,y,rot,s=1,turquoise=True):
    ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.scale(s,s)
    path(ctx,[['M',0,-85],['C',31,-66,40,-12,30,39],['C',25,67,9,84,0,92],['C',-24,71,-36,39,-34,-3],['C',-34,-44,-20,-74,0,-85],['Z']]);fill(ctx,'#204248','#152b30',2)
    ctx.translate(-3,-4)
    path(ctx,[['M',0,-85],['C',31,-66,40,-12,30,39],['C',25,67,9,84,0,92],['C',-24,71,-36,39,-34,-3],['C',-34,-44,-20,-74,0,-85],['Z']]);fill(ctx,gradient(-30,0,30,0,[(0,'#53d7e9' if turquoise else '#7f4e39'),(.3,'#bbecdf' if turquoise else '#c38c66'),(1,'#32a6c3' if turquoise else '#493a30')]),'#315b63',1.2)
    path(ctx,[['M',0,-67],['C',20,-45,23,0,21,41],['C',14,63,5,74,0,77],['C',-24,58,-28,8,-25,-9],['C',-21,-45,-15,-64,0,-67],['Z']]);fill(ctx,'#5e665d','#38525a',1)
    for j in range(9):
        yy=-53+j*13;ww=21*(1-abs(yy/95)*.35)
        rect(ctx,-ww,yy,ww*2,8,gradient(-ww,yy,ww,yy,[(0,'#d9c7a6'),(.7,'#a99c81'),(1,'#e4ceb0')]),'#665a4a',.5)
    for yy in [-39,24]:rect(ctx,-28,yy,56,9,'#53b3c4' if turquoise else '#a4774f','#2e545d',1)
    line(ctx,[(0,-73),(0,73)],'#cbbba0',1)
    ctx.restore()

def dock(ctx):
    ctx.save();ctx.translate(834,670);ctx.rotate(-.73)
    rect(ctx,-76,-130,157,288,(0,0,0,.22),r=28)
    path(ctx,[['M',-74,143],['L',-74,-103],['C',-70,-148,60,-151,76,-101],['L',76,143],['Z']]);fill(ctx,'#d2c4a3','#7a7364',1)
    ctx.clip_preserve() if False else None
    for i in range(32):
        y=-127+i*8.5
        wid=75 if y>-105 else math.sqrt(max(0,1-((y+100)/35)**2))*75
        if wid>0:
            line(ctx,[(-wid,y),(wid,y)],'#4c4941',1.3)
            line(ctx,[(-wid,y+1.6),(wid,y+1.6)],'#f2e4c6',.8)
            for x in [-60,60]:
                if abs(x)<wid:circle(ctx,x,y+4,.9,'#675e4e')
    ctx.restore()

def hand_left(ctx,f):
    ctx.save();ctx.translate(0,math.sin(f*.1)*1.5)
    # Continuous anatomical outline; fingers, thumb and knuckle planes remain separate.
    p=[['M',820,345],['C',783,341,731,358,686,371],['C',644,384,598,380,557,388],['C',529,390,524,406,515,427],['C',499,445,469,474,464,493],['C',457,510,477,529,493,532],['C',499,550,520,574,536,582],['C',546,590,563,584,563,569],['C',568,581,584,584,598,578],['C',622,561,626,548,640,538],['C',666,529,687,493,705,460],['C',730,435,761,414,789,409],['L',835,390],['Z']]
    path(ctx,p);fill(ctx,gradient(528,568,740,350,[(0,'#654435'),(.25,'#a4765c'),(.5,'#bd9579'),(.8,'#a77b63'),(1,'#dfb394')]))
    path(ctx,[['M',821,349],['C',770,353,715,375,670,391],['C',623,405,594,418,579,454],['C',568,481,553,512,552,551],['C',557,574,580,580,598,568],['C',621,553,629,534,640,532],['C',663,516,682,487,702,460],['C',737,425,766,420,791,411],['Z']]);fill(ctx,gradient(570,540,730,380,[(0,'#a6795b'),(.4,'#bf987c'),(1,'#bf9072')]))
    for pp in [
        [['M',487,488],['C',510,477,537,487,548,504]],
        [['M',507,463],['C',527,453,548,466,557,482]],
        [['M',529,435],['C',542,433,565,448,574,462]],
        [['M',501,527],['C',516,513,530,524,538,543]],
        [['M',563,551],['C',583,536,599,528,611,535]],
        [['M',637,413],['C',623,432,620,457,622,471]]]:path(ctx,pp);stroke(ctx,(.27,.15,.10,.35),2)
    ellipse(ctx,580,551,14,21,gradient(570,540,590,565,[(0,'#d5b09b'),(1,'#a37960')]),'#8a6049',.7,rot=.6)
    # Soft broad anatomical highlights and self-shadow, clipped to the same editable hand.
    ctx.save();path(ctx,p);ctx.clip()
    spot(ctx,673,399,158,70,(1,.85,.65,.27));spot(ctx,608,479,50,72,(1,.84,.65,.28))
    spot(ctx,514,496,37,42,(.19,.09,.04,.26));spot(ctx,551,434,39,35,(1,.88,.70,.19))
    spot(ctx,568,538,29,34,(.28,.13,.06,.24));ctx.restore()
    # Fine skin pores are procedural detail inside the vector silhouette.
    ctx.save();path(ctx,p);ctx.clip();rng=random.Random(33)
    for _ in range(2100):
        x=rng.uniform(460,835);y=rng.uniform(345,585);circle(ctx,x,y,rng.uniform(.25,.8),(.24,.13,.09,rng.uniform(.025,.10)))
    ctx.restore()
    ctx.save();ctx.translate(601,458);ctx.rotate(.45)
    rect(ctx,-6,-134,13,274,gradient(-6,0,7,0,[(0,'#03070b'),(.5,'#172329'),(1,'#070c10')]),None,r=2)
    poly(ctx,[(-6,140),(7,140),(0,167)],'#bda48a');poly(ctx,[(-2,158),(2,158),(0,167)],'#10151a')
    ellipse(ctx,0,-134,6.5,4,'#5f5044');ellipse(ctx,0,-134,3.8,2,'#101218');ctx.restore()
    ctx.restore()

def hand_right(ctx):
    p=[['M',904,717],['C',948,740,1007,754,1061,750],['C',1112,746,1149,729,1178,706],['C',1208,685,1233,649,1260,619],['C',1277,600,1294,609,1293,630],['C',1297,612,1312,611,1321,625],['C',1332,640,1332,676,1321,706],['C',1315,746,1303,787,1278,823],['C',1256,844,1227,842,1187,842],['C',1091,856,1009,850,944,822],['L',866,775],['Z']]
    path(ctx,p);fill(ctx,gradient(940,830,1260,670,[(0,'#51332d'),(.35,'#6e4a3d'),(.7,'#8c6852'),(1,'#a68165')]))
    path(ctx,[['M',926,757],['C',1050,803,1144,790,1200,744],['C',1240,714,1261,663,1276,637],['C',1290,619,1293,627,1288,655],['C',1272,704,1261,757,1226,781],['C',1148,833,1029,838,950,811],['Z']]);fill(ctx,gradient(950,840,1160,740,[(0,(.12,.07,.07,.3)),(1,(.75,.54,.4,.4))]))
    for x in [1282,1300,1316]:
        path(ctx,[['M',x,650],['C',x-5,688,x-13,710,x-29,732]]);stroke(ctx,(.22,.12,.10,.35),1.4)
    ctx.save();path(ctx,p);ctx.clip()
    spot(ctx,1194,768,145,66,(1,.78,.58,.19));spot(ctx,1279,671,34,68,(1,.82,.64,.22));spot(ctx,1040,827,153,40,(.12,.05,.02,.2))
    ctx.restore()
    ctx.save();path(ctx,p);ctx.clip();rng=random.Random(23)
    for _ in range(2500):circle(ctx,rng.uniform(890,1330),rng.uniform(615,845),rng.uniform(.25,.8),(.1,.05,.03,rng.uniform(.03,.12)))
    ctx.restore()
    ctx.save();ctx.translate(1253,738);ctx.rotate(.42)
    rect(ctx,-4,-150,9,288,gradient(-4,0,5,0,[(0,'#d69600'),(.5,'#ffd933'),(1,'#ad6e00')]))
    poly(ctx,[(-4,-150),(5,-150),(0,-178)],'#c9a681');poly(ctx,[(-1,-168),(2,-168),(0,-178)],'#424044')
    rect(ctx,-4,138,9,19,'#b49c63');rect(ctx,-4,158,9,17,'#ed82a6',r=2)
    for j in range(5):line(ctx,[(-4,140+j*3),(5,140+j*3)],'#e7ce9f',.5)
    ctx.restore()

def tentacle(ctx,f):
    pts=[]
    for t in np.linspace(0,1,100):
        if t<.7:
            q=t/.7;x=677+143*q;y=478-125*q+24*math.sin(q*PI)
        else:
            q=(t-.7)/.3;a=q*PI*2.0;x=821+27*(1-q)*math.sin(a);y=350-25*(1-q)*math.cos(a)
        pts.append((x+math.sin(f*.15+t*3)*5,y))
    for i in range(len(pts)-1):
        w=40*(1-i/len(pts))**.65+5
        line(ctx,pts[i:i+2],gradient(670,470,820,340,[(0,'#d58e91'),(.4,'#b76172'),(1,'#692c49')]),w)
    for i in range(0,len(pts),3):
        x,y=pts[i];r=7*(1-i/len(pts))+.8;circle(ctx,x-2,y+8*(1-i/len(pts)),r,'#f4b1ad','#89404e',.65);circle(ctx,x-2,y+8*(1-i/len(pts)),r*.45,'#b46b73')

def staircase(ctx):
    cx,cy=1084,560
    # Stone exterior rim and an independently editable fan of steps.
    for width,col in [(244,'#b5ad98'),(237,'#d0c5ac'),(228,'#8e8c85')]:
        ctx.new_path();ctx.arc(cx,cy,width,-2.15,2.28);ctx.arc_negative(cx,cy,104,2.28,-2.15);ctx.close_path();fill(ctx,col)
    for i in range(39):
        a=-2.15+i*4.43/39;b=a+4.43/39
        out1=(cx+224*math.cos(a),cy+224*math.sin(a));out2=(cx+224*math.cos(b),cy+224*math.sin(b));inn1=(cx+107*math.cos(a),cy+107*math.sin(a));inn2=(cx+107*math.cos(b),cy+107*math.sin(b))
        shade=.62+.12*math.sin(a-1)
        poly(ctx,[inn1,out1,out2,inn2],gradient(*out1,*out2,[(0,(shade+.15,shade+.15,shade+.17)),(.14,(shade+.02,shade+.02,shade+.04)),(1,(shade-.07,shade-.07,shade-.04))]),(0.34,.34,.36,.5),.6)
        line(ctx,[inn1,out1],(.9,.9,.87,.4),1.1)
    ctx.new_path();ctx.arc(cx,cy,233,-2.15,2.28);stroke(ctx,'#777667',4)

def hiker(ctx):
    # Small seated explorer silhouette with articulated limbs, pack and binoculars.
    ctx.save();ctx.translate(1242,217);ctx.rotate(.12);ctx.scale(.9,.9)
    ellipse(ctx,51,10,38,58,gradient(20,0,90,20,[(0,'#52412e'),(1,'#8d7753')]),'#1e2521',2,rot=-.15)
    for dx in [30,60]:line(ctx,[(dx,-38),(dx+8,49)],'#282e27',5)
    path(ctx,[['M',10,-39],['C',-8,-20,-20,8,-20,30],['L',32,57],['L',53,19],['L',40,-29],['Z']]);fill(ctx,'#733b41','#242626',2)
    line(ctx,[(10,40),(-47,17),(-73,18)],'#253733',24);line(ctx,[(-43,17),(-80,-2),(-111,0)],'#263c37',23)
    line(ctx,[(-79,-4),(-111,-3)],'#c1a658',8);line(ctx,[(-74,19),(-98,32)],'#b79f55',8)
    circle(ctx,18,-66,20,'#a86a49');ellipse(ctx,23,-80,25,15,'#142c35',rot=.2);rect(ctx,8,-97,33,23,'#19323a',r=8)
    line(ctx,[(2,-22),(-10,-44),(7,-83)],'#8d4d32',12);line(ctx,[(29,-23),(12,-42),(22,-77)],'#9d5937',12)
    line(ctx,[(4,-82),(27,-82)],'#111c23',11);rect(ctx,-2,-93,8,17,'#151f25');rect(ctx,13,-93,8,17,'#151f25')
    ctx.restore()

class Garden:
    def __init__(self,paths,seed=48):
        self.samples=[sample(paths['logo_left']),sample(paths['logo_right'])];rng=random.Random(seed);self.leaves=[];self.flowers=[];self.planks=[]
        for k,sm in enumerate(self.samples):
            length=sm[1][-1]
            for i in range(int(length/19)):
                u=(i+.5)/(length/19);self.planks.append((k,u,rng.random()))
            for j in range(3100 if k else 2500):
                u=rng.random();offset=rng.uniform(-50,50);sz=rng.uniform(4,13);ang=rng.uniform(-PI,PI);c=rng.uniform(0,1)
                self.leaves.append((k,u,offset,sz,ang,c,rng.random()))
            for j in range(45 if k else 34):
                self.flowers.append((k,rng.random(),rng.choice([-1,1])*rng.uniform(30,52),rng.uniform(10,21),rng.randrange(6),rng.random()*6))
        import json
        dest=Path(__file__).resolve().parent/'garden_objects.json'
        if dest.exists():
            data=json.loads(dest.read_text())
            self.leaves=[o['parameters'] for o in data['leaves'] if o.get('visible',True)]
            self.flowers=[o['parameters'] for o in data['flowers'] if o.get('visible',True)]
            self.planks=[o['parameters'] for o in data['planks'] if o.get('visible',True)]
        else:
            data={}
            for name in ['leaves','flowers','planks']:
                data[name]=[{'id':f'garden.{name}.{i:04d}','visible':True,'parameters':[round(v,5) if isinstance(v,float) else v for v in item]} for i,item in enumerate(getattr(self,name))]
            data['parameter_order']={'leaves':['path_index','path_fraction','normal_offset','size','rotation','color_variation','sway_phase'],'flowers':['path_index','path_fraction','normal_offset','radius','palette_index','rotation'],'planks':['path_index','path_fraction','wood_variation']}
            dest.write_text(json.dumps(data,separators=(',',':')))

    def reveal(self,k,f):
        return smooth(176 if k==0 else 183,193 if k==0 else 198,f)
    def visible(self,k,u,f):
        rev=self.reveal(k,f)
        if k==0:return u<rev and u>clamp((f-202)/18)
        return u>1-rev and u<clamp((225-f)/18)
    def draw(self,ctx,f):
        palettes=['#f537c2','#b2a2ff','#37b8f2','#ffb83d','#f92d62','#f2f4ff']
        for k,sm in enumerate(self.samples):
            r=self.reveal(k,f)
            a=clamp((f-202)/18) if k==0 else 1-r
            r=min(1,clamp((225-f)/18)) if k==1 else r
            if r>a:
                pts,ds=sm;i=max(0,np.searchsorted(ds,a*ds[-1]));j=min(len(ds),np.searchsorted(ds,r*ds[-1])+1)
                if j-i>1:
                    ctx.new_path();ctx.move_to(*pts[i])
                    for p in pts[i+1:j]:ctx.line_to(*p)
                    paint(ctx,'#6fa52a');ctx.set_line_width(88);ctx.set_line_cap(cairo.LINE_CAP_BUTT);ctx.stroke()
        for k,u,off,sz,ang,cv,phase in self.leaves:
            if not self.visible(k,u,f):continue
            # Full leaf coverage remains underneath the independent planks.
            p,a=at(self.samples[k],u);nx=-math.sin(a);ny=math.cos(a)
            x=p[0]+nx*off;y=p[1]+ny*off
            z=1+.04*math.sin(f*.12+phase*8)
            base=(.2+cv*.23,.56+cv*.36,.03+cv*.07)
            g=radial(x-1,y-2,sz*1.5,[(0,(base[0]+.23,min(1,base[1]+.14),base[2]+.05)),(.6,base),(1,(base[0]*.6,base[1]*.72,base[2]*.6))])
            ellipse(ctx,x,y,sz*z,sz*.56,g,rot=ang+a)
        for k,u,v in self.planks:
            if not self.visible(k,u,f):continue
            p,a=at(self.samples[k],u);ctx.save();ctx.translate(*p);ctx.rotate(a)
            rect(ctx,-10,-24,19,48,gradient(-10,-20,10,20,[(0,'#e8a16b'),(.25,'#d68c4d'),(.65,'#b56c36'),(1,'#f4af77')]),'#81512c',.8,r=2)
            for j in range(4):
                xx=-7+j*4+v;line(ctx,[(xx,-22),(xx+math.sin(v*8)*2,22)],(0.42,.20,.08,.25),.65)
            ctx.restore()
        for k,u,off,r,c,phase in self.flowers:
            if not self.visible(k,u,f):continue
            p,a=at(self.samples[k],u);x=p[0]-math.sin(a)*off;y=p[1]+math.cos(a)*off
            flower(ctx,x+1,y+2,r,(.2,.25,.1,.18),n=7)
            flower(ctx,x,y,r,palettes[c],n=7,tilt=phase+math.sin(f*.1)*.05)
        # A few loose leaves trail the growth front and exit.
        if 179<f<227:
            rng=random.Random(381)
            for i in range(45):
                k=i%2;u=rng.random()
                p,a=at(self.samples[k],u);off=rng.choice([-1,1])*rng.uniform(62,110);x=p[0]-math.sin(a)*off+math.sin(f*.16+i)*8;y=p[1]+math.cos(a)*off+(f%24)*.5
                if self.visible(k,u,f):ellipse(ctx,x,y,5+rng.random()*5,3,'#82cf26',rot=f*.03+i)

def cyclist(ctx,x,y,angle,f,scale=1,wave=True):
    ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.scale(scale,scale)
    # Steel bicycle with independent spoke rotation and crank phase.
    for xx in [-49,49]:
        circle(ctx,xx,-2,31,'#24113e');circle(ctx,xx,-2,24,'#e5dbeb');circle(ctx,xx,-2,21,'#ffffff')
        for j in range(12):
            a=j*PI/6+f*.22;line(ctx,[(xx,-2),(xx+23*math.cos(a),-2+23*math.sin(a))],'#746977',.75)
        circle(ctx,xx,-2,4,'#8d8496')
    line(ctx,[(-49,-2),(-23,-48),(8,-3),(-49,-2),(24,-47),(49,-2),(8,-3)],'#e7dce8',4)
    line(ctx,[(-49,-2),(-23,-48),(8,-3),(24,-47)],'#7e6383',1)
    line(ctx,[(-23,-48),(-26,-58)],'#544452',4);line(ctx,[(-40,-58),(-17,-58)],'#211e2c',6)
    line(ctx,[(24,-47),(21,-67),(7,-70)],'#9e8fa2',4);line(ctx,[(7,-70),(1,-76)],'#352735',5)
    # Pedalling legs, boot soles and back leg.
    phase=f*.23
    knee=(5+17*math.sin(phase),-53);foot=(9+17*math.cos(phase),-4+11*math.sin(phase))
    line(ctx,[(-14,-75),(-6,-47),(-20,0)],'#271c68',17);line(ctx,[(-19,1),(-34,2)],'#f4e8ee',11)
    line(ctx,[(-13,-76),knee,foot],gradient(-20,-70,20,0,[(0,'#4937b2'),(1,'#27237e')]),19)
    line(ctx,[(foot[0]-8,foot[1]+3),(foot[0]+10,foot[1]+3)],'#ffffff',11)
    circle(ctx,8,-3,7,'#9e94ae');line(ctx,[(8,-3),foot],'#584766',3)
    jacket=[['M',-31,-120],['C',-37,-104,-39,-91,-30,-75],['C',-17,-64,6,-68,14,-79],['L',15,-106],['L',-2,-125],['Z']]
    path(ctx,jacket);fill(ctx,gradient(-39,-95,18,-100,[(0,'#d31f29'),(.5,'#f8542c'),(1,'#c5163c')]),'#ba2631',1)
    # One hand holds the handlebar; the other waves during the upper arc.
    line(ctx,[(-23,-111),(-40,-97),(-4,-76)],'#e93637',20)
    circle(ctx,-2,-76,9,'#c9a4f3')
    if wave:
        a=-.8+math.sin(f*.14)*.18;el=(18,-139);hand=(44+8*math.sin(f*.14),-185)
        line(ctx,[(0,-114),el,hand],gradient(0,-110,40,-180,[(0,'#ed382c'),(1,'#da173c')]),21)
        # Purple glove and separate waving fingers.
        circle(ctx,hand[0],hand[1]-2,11,'#b696e4')
        for j in range(4):line(ctx,[(hand[0]-7+j*5,hand[1]-5),(hand[0]-12+j*6,hand[1]-22-3*math.sin(j))],'#baa2e7',6)
    else:line(ctx,[(0,-114),(25,-100),(19,-73)],'#f24632',20);circle(ctx,19,-73,9,'#c9a4f3')
    ctx.save();path(ctx,jacket);ctx.clip();rng=random.Random(89)
    for _ in range(110):
        xx=rng.uniform(-40,15);yy=rng.uniform(-126,-69);ellipse(ctx,xx,yy,1.5,2.4,(1,.56,.16,.65),rot=.4)
    ctx.restore()
    circle(ctx,-6,-133,10,'#c9a5eb');circle(ctx,17,-136,10,'#d3b5ee')
    ellipse(ctx,6,-142,23,26,radial(6,-142,28,[(0,'#ecdaff'),(1,'#b29ae0')]))
    # Cap, eyes and joyful mouth.
    ctx.save();ctx.translate(5,-165);ctx.rotate(-.25);rect(ctx,-13,-10,27,14,'#3e2390',r=4);rect(ctx,-14,1,35,6,'#261551',r=2);ctx.restore()
    circle(ctx,0,-145,2.1,'#261743');circle(ctx,12,-145,2.1,'#261743')
    path(ctx,[['M',-2,-135],['L',17,-135],['C',16,-119,2,-119,-2,-135],['Z']]);fill(ctx,'#291244')
    rect(ctx,0,-135,15,5,'#ffffff',r=1);ellipse(ctx,10,-125,5,3,'#f173af')
    ctx.restore()
