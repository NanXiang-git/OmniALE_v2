"""Export native vector artwork for review in an SVG editor."""
from pathlib import Path
import json,cairo
from renderer import Renderer
ROOT=Path(__file__).resolve().parent

def main():
    config=json.loads((ROOT/'scene.json').read_text());ren=Renderer(config)
    dest=ROOT/'artwork';dest.mkdir(exist_ok=True)
    for name,f,method in [('grid',24,'grid'),('interface',56,'ui'),('illustration',88,'illustration'),('portrait',128,'portrait'),('collage',168,'collage'),('garden',200,'draw_garden')]:
        surface=cairo.SVGSurface(str(dest/f'{name}.svg'),1920,1080);ctx=cairo.Context(surface)
        ctx.set_source_rgb(1,1,1);ctx.paint();getattr(ren,method)(ctx,f);surface.finish()
    print(dest)
if __name__=='__main__':main()
