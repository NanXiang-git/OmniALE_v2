"""Deterministic, offline analysis of the supplied unmodified stereo audio.

All times refer to original WAV sample zero. No audio processing is used by
the muxer. The envelope affects only the tube's cross section.
"""
from pathlib import Path
import hashlib
import numpy as np
from scipy.io import wavfile
from scipy.signal.windows import hann
from scipy.signal import resample_poly


class AudioAnalysis:
    def __init__(self, path):
        self.path = Path(path)
        self.sample_rate, pcm = wavfile.read(self.path)
        if np.issubdtype(pcm.dtype, np.integer):
            pcm = pcm.astype(np.float64) / (2 ** (np.iinfo(pcm.dtype).bits - 1))
        else:
            pcm = pcm.astype(np.float64)
        self.pcm = pcm
        mono = pcm.mean(axis=1) if pcm.ndim == 2 else pcm
        if self.sample_rate != 48000:
            from math import gcd
            g = gcd(self.sample_rate, 48000)
            mono = resample_poly(mono, 48000 // g, self.sample_rate // g)
        self.mono = mono
        self.n_fft, self.hop, self.sr = 2048, 480, 48000
        padded = np.pad(mono, (1024, 1024), mode='constant')
        frames = np.lib.stride_tricks.sliding_window_view(padded, 2048)[::480]
        spectrum = np.fft.rfft(frames * hann(2048, sym=False), axis=1)
        self.times = np.arange(len(spectrum)) * .01
        self.frequencies = np.fft.rfftfreq(2048, 1 / 48000)
        self.bands = {}
        for name, (lo, hi) in {'low': (40, 250), 'mid': (250, 2500),
                                'high': (2500, 16000)}.items():
            bins = (self.frequencies >= lo) & (self.frequencies <= hi)
            self.bands[name] = np.sqrt(np.mean(np.abs(spectrum[:, bins]) ** 2, axis=1))
        self.events = {}
        for name, band, lo, hi, source, action in [
            ('A', 'low', .65, 1.25, 1.25, 'grid assembly reaches the source 1.25 s state'),
            ('B', 'low', 2.25, 2.90, 3.50, 'full illustration reaches the source 3.50 s state'),
            ('C', 'mid', 3.95, 4.65, 5.50, 'portrait reveal reaches the source 5.50 s state'),
        ]:
            indices = np.flatnonzero((self.times >= lo - 1e-10) & (self.times <= hi + 1e-10))
            index = int(indices[np.argmax(self.bands[band][indices])])
            self.events[name] = dict(time_s=float(self.times[index]), stft_index=index,
                                     band=band, search_window_s=[lo, hi],
                                     peak_energy=float(self.bands[band][index]),
                                     source_state_s=source, visual_action=action,
                                     nearest_output_frame=int(np.floor(self.times[index] * 24 + .5)))
        # Floating PCM / window leakage from a pure high-band signal must not
        # be amplified to a full pulse. This is below a 24-bit PCM LSB after
        # FFT gain; the supplied track's low-band maximum is ~107, not near it.
        self.numerical_floor = 1e-5
        low_max = self.bands['low'].max()
        self.low_normalized = (self.bands['low'] / low_max if low_max > self.numerical_floor
                               else np.zeros_like(self.bands['low']))
        self.envelope = np.zeros_like(self.low_normalized)
        prev = 0.
        for i, value in enumerate(self.low_normalized):
            tau = .030 if value > prev else .180
            coefficient = np.exp(-.01 / tau)
            prev = coefficient * prev + (1 - coefficient) * value
            self.envelope[i] = prev
        self.source_anchors = np.array([0, 1.25, 3.5, 5.5, 6.25, 8, 10])
        self.output_anchors = np.array([0, self.events['A']['time_s'], self.events['B']['time_s'],
                                        self.events['C']['time_s'], 6.25, 8, 10])

    def source_time(self, output_time):
        return float(np.interp(output_time, self.output_anchors, self.source_anchors))

    def control(self, output_time):
        return float(np.interp(output_time, self.times, self.envelope))

    def report(self):
        return dict(
            audio_path='project/assets/audio/' + self.path.name,
            audio_sha256=hashlib.sha256(self.path.read_bytes()).hexdigest(),
            input_sample_rate=self.sample_rate, input_samples=len(self.pcm),
            input_channels=1 if self.pcm.ndim == 1 else self.pcm.shape[1],
            algorithm=dict(mono='arithmetic mean of both channels', sample_rate_hz=48000,
                stft=dict(n_fft=2048, hop_samples=480, centered=True, pad_mode='constant',
                          window='periodic Hann (scipy.signal.windows.hann(sym=False))',
                          fft_scaling='unnormalized numpy rfft'),
                band_energy='sqrt(mean(abs(STFT bins)**2)); inclusive band endpoints',
                bands_hz=dict(low=[40,250], mid=[250,2500]),
                peak_selection='argmax over inclusive search endpoints; earliest index breaks ties',
                envelope=dict(normalization='low band divided by full 10 s maximum BEFORE smoothing',
                    numerical_silence_floor_raw_fft=self.numerical_floor,
                    attack_s=.030, release_s=.180, initial_value=0,
                    recurrence='a=exp(-0.01/tau); y=a*y_previous+(1-a)*x',
                    frame_interpolation='linear at output_frame / 24')),
            events=self.events, source_anchors_s=self.source_anchors.tolist(),
            output_anchors_s=self.output_anchors.tolist(),
            mapping='piecewise linear; source time = interp(output time, output anchors, source anchors)',
            audio_output='original WAV at t=0, speed=1, gain=1, AAC 320 kb/s; no added sound')
