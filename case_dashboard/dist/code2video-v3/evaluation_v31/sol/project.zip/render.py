#!/usr/bin/env python3
"""Shared offline renderer: original reconstruction or audio-driven revision."""
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'project'))
from renderer import Renderer
from revision_renderer import RevisionRenderer


def load_config(path):
    path = Path(path).resolve()
    config = json.loads(path.read_text())
    if 'base_config' in config:
        base = load_config(path.parent / config['base_config'])
        base.update({k:v for k,v in config.items() if k != 'base_config'})
        return base
    return config


def encoder(out, audio=None, diagnostic=False):
    args = ['ffmpeg','-y','-v','error','-threads','2','-f','rawvideo','-pix_fmt','rgb24',
            '-s','1920x1080','-r','24','-i','-']
    if audio:
        args += ['-i',str(audio),'-map','0:v:0','-map','1:a:0','-c:a','aac','-b:a','320k','-ar','48000']
    else:
        args += ['-an']
    args += ['-c:v','libx264','-threads','2','-preset','medium','-crf','12' if diagnostic else '16',
             '-pix_fmt','yuv420p','-t','10','-movflags','+faststart',
             '-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',str(out)]
    return subprocess.Popen(args,stdin=subprocess.PIPE)


def close_encoder(p):
    p.stdin.close()
    if p.wait():
        raise RuntimeError('FFmpeg encoding failed')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode',choices=['reconstruction','revision'],default='reconstruction')
    ap.add_argument('--config',help='JSON configuration, relative to current directory')
    ap.add_argument('--output',help='Output MP4, or inspection directory with --frames')
    ap.add_argument('--frames',help='Comma-separated zero-based PNG inspection frame indices')
    ap.add_argument('--diagnostics',action='store_true',help='Write scene-space revision masks, CSV and audio events')
    args=ap.parse_args()
    config=load_config(args.config or ROOT/'project'/('revision.json' if args.mode=='revision' else 'scene.json'))
    ren=RevisionRenderer(config) if args.mode=='revision' else Renderer(config)
    output=Path(args.output or ROOT/f'{args.mode}.mp4')
    if args.frames:
        output.mkdir(parents=True,exist_ok=True)
        for f in map(int,args.frames.split(',')):
            Image.fromarray(ren.frame(f)).save(output/f'frame_{f:03d}.png')
            if args.mode=='revision' and args.diagnostics:
                a,h,rgb=ren.portrait_diagnostics(ren.current_source_frame)
                Image.fromarray(a).save(output/f'portrait_alpha_{f:03d}.png')
                Image.fromarray(h).save(output/f'head_overflow_{f:03d}.png')
            print('inspection frame',f,flush=True)
        return
    output.parent.mkdir(parents=True,exist_ok=True)
    p=encoder(output,ren.audio_path if args.mode=='revision' else None)
    diagnostics=args.diagnostics and args.mode=='revision'
    procs={};rows=[]
    if diagnostics:
        dest=ROOT/'diagnostics';dest.mkdir(exist_ok=True)
        for name in ['portrait_alpha','portrait_checker','head_overflow']:
            procs[name]=encoder(dest/f'{name}.mp4',diagnostic=True)
        yy,xx=np.indices((1080,1920))
        checker=np.where(((xx//32+yy//32)%2)[:,:,None],184.,230.)
        (ROOT/'audio_events.json').write_text(json.dumps(ren.audio.report(),indent=2)+'\n')
    for f in range(240):
        p.stdin.write(ren.frame(f).tobytes())
        if diagnostics:
            a,h,rgb=ren.portrait_diagnostics(ren.current_source_frame)
            procs['portrait_alpha'].stdin.write(np.repeat(a[:,:,None],3,axis=2).tobytes())
            procs['head_overflow'].stdin.write(np.repeat(h[:,:,None],3,axis=2).tobytes())
            comp=np.clip(rgb+checker*(1-a[:,:,None]/255),0,255).astype('uint8')
            procs['portrait_checker'].stdin.write(comp.tobytes())
            t=f/24;sf=ren.current_source_frame;dt=t-config['cursor_delay_s'];bs=ren.audio.source_time(dt)*24
            row=dict(frame=f,output_time_s=t,source_time_s=sf/24,
                     low_energy=float(np.interp(t,ren.audio.times,ren.audio.bands['low'])),
                     low_normalized=float(np.interp(t,ren.audio.times,ren.audio.low_normalized)),
                     low_control=ren.audio.control(t),tube_width_scale=1+config['pulse_amount']*ren.audio.control(t),
                     ui_visibility=ren.ui_opacity(sf),blue_cursor_source_time_s=bs/24,
                     blue_cursor_visibility=ren.ui_opacity(bs) if dt>=0 else 0,
                     portrait_source_frame=ren.portrait_source_index(sf) if ren.visibility(sf)>0 else '',
                     portrait_source_time_s=ren.portrait_source_index(sf)*1001/24000 if ren.visibility(sf)>0 else '',
                     portrait_visibility=ren.visibility(sf),portrait_alpha_sum_pixels=float(a.sum()/255),
                     head_overflow_px=ren.overflow_amount(),head_overflow_alpha_sum_pixels=float(h.sum()/255))
            rows.append(row)
        if f%12==0:print(f'{args.mode} {f}/240',flush=True)
    close_encoder(p)
    for dp in procs.values():close_encoder(dp)
    if diagnostics:
        with (ROOT/'diagnostics/control_signals.csv').open('w',newline='') as handle:
            writer=csv.DictWriter(handle,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(output,flush=True)


if __name__=='__main__':
    main()
